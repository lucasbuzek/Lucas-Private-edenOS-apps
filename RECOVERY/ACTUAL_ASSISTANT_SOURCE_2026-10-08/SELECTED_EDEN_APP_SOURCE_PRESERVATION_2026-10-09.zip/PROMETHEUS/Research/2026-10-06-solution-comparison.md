# Actions and professional-tool integration — preliminary comparison

Status: RESEARCHED, NOT SELECTED. No prototype or runtime evidence yet. Findings are new engineering research, not recovered schema decisions.

| Candidate | Reuse potential | Cost / unresolved issue | Current disposition |
|---|---|---|---|
| doit | Python/cmd tasks, dependency graph, task parameters, file targets, change checks and reusable task loaders | Not installed; cancellation/process trees, crash recovery and domain evidence still need thin adapter. Default change checks are not authoritative engineering integrity. | ADAPT candidate for compact local deterministic composition |
| Snakemake | Local file-based rules, dependencies, parameterized scientific workflows, executor plugins | Broader dependency surface; prove fit for interactive tool/manual candidate work before selecting | REUSE candidate for heavier analysis pipelines |
| Prefect | Tasks/flows, retries, states, timeout and lifecycle hooks; self-hosted server available | Additional orchestration/control-plane configuration; do not duplicate BIFROST routing. Offline behavior must be tested for selected configuration | Alternative; not rejected merely because cloud offering exists |
| Native tool scripts/macros plus OS process/file APIs | Blender bpy and FreeCAD scripting perform real specialist operations; AppKit opens the precise artifact | Does not supply project/candidate evidence semantics or cross-tool composition alone | REUSE tool APIs; ADAPT project association |
| New general-purpose workflow engine | Can be tailored | Would recreate mature graph/dependency machinery without proven need | REJECT as default; build only missing domain state/validation/reconciliation gap |

Sources inspected:
- https://pydoit.org/ — task runner overview.
- https://pydoit.org/dependencies.html — file/task dependencies, target and up-to-date behavior.
- https://pydoit.org/task-creation.html — task loaders and reuse boundary.
- https://github.com/pydoit/doit/blob/master/LICENSE — licensing source; capture exact selected release license before adoption.
- https://snakemake.readthedocs.io/en/v9.26.1/executing/executors.html — local default and optional executor plugins.
- https://snakemake.readthedocs.io/en/stable/executing/cli.html — execution/re-execution options.
- https://reference.prefect.io/prefect/ — flow configuration and state hooks.
- https://github.com/PrefectHQ/prefect/blob/main/docs/v3/how-to-guides/self-hosted/server-cli.mdx — local server configuration.
- https://docs.blender.org/manual/en/5.1/advanced/command_line/arguments.html — background, Python and Python exception exit behavior. Installed bundle reports 5.2.2; verify version-matched API before execution.
- https://github.com/FreeCAD/FreeCAD-documentation/blob/main/wiki/Headless_FreeCAD.md — supported headless paths.
- https://github.com/FreeCAD/FreeCAD-documentation/blob/main/wiki/Python_scripting_tutorial.md — native scripting.
- https://developer.apple.com/documentation/AppKit/NSWorkspace — open specific artifact in specified application.

Proposed minimal boundary to test: mature runner composes implementation-neutral capabilities; tool adapters invoke existing CLI/API/macros. PROMETHEUS owns candidate isolation, input/output identities and hashes, domain validation, failure/partial-result records, recovery and manual save association. It owns no new CAD kernel, solver, connection manager or Codex router. Sidecars hold project semantics; native artifacts stay ordinary files. No final ABI chosen yet.

Manual continuity needs a real probe: open candidate working copy with explicit project/revision context, observe completed saves (including atomic replacement), hash settled results, record tool/version/provenance and reconcile as a candidate revision. File notifications are hints; reconcile on focus/restart as well. A changed file proves a saved artifact, not engineering validity. Tool-specific event hooks may enrich context but must not be required for manual work.

Selection gate: compare dependency/license/privacy/platform cost, repeatable parameter composition, structured outputs, isolated failed/interrupted runs and offline execution. Then select and document exact release/contract from observed behavior. Python arithmetic is calculation, not a specialist engineering solver. Baseline must remain immutable throughout probes; output validation is independent of process exit.
