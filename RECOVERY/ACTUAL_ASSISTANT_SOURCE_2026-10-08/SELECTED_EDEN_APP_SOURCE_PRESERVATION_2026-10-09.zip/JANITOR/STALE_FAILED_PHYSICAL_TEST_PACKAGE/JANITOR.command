#!/bin/bash
# JANITOR v0.9.0 — script-only standalone terminal page (macOS)
set -u
ROOT="$(cd "$(dirname "$0")" && pwd -P)"
CORE="$ROOT/core/janitor-macos.sh"
if [ ! -f "$CORE" ]; then
  printf 'JANITOR core is missing:\n%s\n' "$CORE"
  read -r -p 'Press Return to close…' _
  exit 2
fi
# Present this Terminal window as JANITOR rather than a generic shell session.
printf '\033]0;JANITOR — Maintenance & Recovery\007'
printf '\033[?1049h\033[?25h'
cleanup(){ printf '\033[?25h\033[?1049l'; }
trap cleanup EXIT HUP INT TERM
exec /bin/bash "$CORE" "$@"
