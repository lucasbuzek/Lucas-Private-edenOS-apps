JANITOR v0.11.0 — MAC PHYSICAL TEST PACKAGE

LAUNCH
Double-click JANITOR.command. The standalone Terminal interface opens in the
STANDARD / DEVELOPER / MEDIA / FULL CREW menu. Choose X to exit.

If macOS blocks the first launch, Control-click JANITOR.command, choose Open,
then confirm Open. No installation, daemon, background service, network access,
or third-party dependency is required.

PHYSICAL CHECKS
- Confirm the launcher opens and exits cleanly.
- Review Quick Scan and Full Scan results; do not choose Delete during testing.
- Review Developer Quick and Project Discovery results.
- Confirm provider-managed iCloud paths are skipped and labeled as deferred.
- Confirm quarantine/recovery only with a disposable test file you created.

SAFETY / LIMITS
This candidate is an on-demand Bash maintenance utility. It does not run as a
daemon. Terminal JANITOR does not inspect File Provider materialization state,
mutate cloud-provider content, or inspect Photos assets through PhotoKit.
Unknown files are not junk; scan results require review. Keep the historical
LKG and user data untouched during physical testing.

The current evidence and pending physical checks are in TEST_STATUS.txt.
