#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
# JANITOR — one-click native macOS builder
# Double-click this file. It will:
#   1. check your toolchain (Xcode or Command Line Tools)
#   2. generate the SwiftUI project  (JANITOR_Native/, opens directly in Xcode)
#   3. build it with `swift build` (no helper binaries, no third-party deps)
#   4. assemble + ad-hoc sign JANITOR.app next to this script, then launch it
#
# Flags:  --regen   rewrite the generated sources (discards your edits)
#         --xcode   open the project in Xcode after building
#         --clean   delete build products first
# ─────────────────────────────────────────────────────────────────────────────
set -u
cd "$(dirname "$0")" || exit 1
ROOT="$(pwd)"
PROJ="$ROOT/JANITOR_Native"
SRC="$PROJ/Sources/JANITOR"
LOG="$PROJ/build.log"

REGEN=0; OPEN_XCODE=0; CLEAN=0; GEN_ONLY=0
for a in "$@"; do
  case "$a" in
    --regen) REGEN=1 ;;
    --xcode) OPEN_XCODE=1 ;;
    --clean) CLEAN=1 ;;
    --generate-only) GEN_ONLY=1 ;;
  esac
done

B=$'\033[1m'; G=$'\033[32m'; Y=$'\033[33m'; R=$'\033[31m'; D=$'\033[2m'; N=$'\033[0m'
say()  { printf "%s▸%s %s\n" "$B" "$N" "$1"; }
ok()   { printf "  %s✓%s %s\n" "$G" "$N" "$1"; }
warn() { printf "  %s!%s %s\n" "$Y" "$N" "$1"; }
die()  { printf "  %s✗ %s%s\n" "$R" "$1" "$N"; echo; read -n 1 -s -r -p "Press any key to close…"; echo; exit 1; }

printf "\n%sJANITOR%s — native macOS builder  %s(Justified Analysis, Navigation, Inspection, Tidying, Optimization & Recovery)%s\n\n" "$B" "$N" "$D" "$N"

# ── 1. environment ───────────────────────────────────────────────────────────
say "Checking environment"
[ "$(uname -s)" = "Darwin" ] || die "This builder only runs on macOS."
MAJOR="$(sw_vers -productVersion | cut -d. -f1)"
[ "${MAJOR:-0}" -ge 13 ] || die "macOS 13 or newer is required (found $(sw_vers -productVersion))."
ok "macOS $(sw_vers -productVersion) · $(uname -m)"

if ! xcrun --find swift >/dev/null 2>&1; then
  warn "No Swift toolchain found. Requesting Apple's Command Line Tools install…"
  xcode-select --install >/dev/null 2>&1
  die "Finish the Command Line Tools install (a system dialog just opened), then double-click this file again. Full Xcode from the App Store also works."
fi
ok "$(swift --version 2>&1 | head -n 1)"

# ── 2. generate project ──────────────────────────────────────────────────────
if [ -f "$PROJ/Package.swift" ] && [ "$REGEN" -eq 0 ]; then
  say "Existing project found — keeping your sources (use --regen to rewrite)"
else
  say "Generating project at JANITOR_Native/"
  rm -rf "$PROJ"
  mkdir -p "$SRC" "$PROJ/Resources"

cat > "$PROJ/Package.swift" <<'JANITOR_EOF'
// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "JANITOR",
    platforms: [.macOS(.v13)],
    targets: [
        .executableTarget(name: "JANITOR", path: "Sources/JANITOR")
    ]
)
JANITOR_EOF

cat > "$PROJ/Resources/Info.plist" <<'JANITOR_EOF'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleName</key><string>JANITOR</string>
  <key>CFBundleDisplayName</key><string>JANITOR</string>
  <key>CFBundleIdentifier</key><string>com.janitor.native</string>
  <key>CFBundleExecutable</key><string>JANITOR</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleShortVersionString</key><string>0.1.0</string>
  <key>CFBundleVersion</key><string>1</string>
  <key>LSMinimumSystemVersion</key><string>13.0</string>
  <key>NSPrincipalClass</key><string>NSApplication</string>
  <key>NSHighResolutionCapable</key><true/>
  <key>LSApplicationCategoryType</key><string>public.app-category.utilities</string>
  <key>NSDownloadsFolderUsageDescription</key><string>JANITOR inspects Downloads and keeps its reviewable quarantine there.</string>
  <key>NSDocumentsFolderUsageDescription</key><string>JANITOR only reads storage metadata you ask it to inspect.</string>
  <key>NSDesktopFolderUsageDescription</key><string>JANITOR only reads storage metadata you ask it to inspect.</string>
  <key>NSRemovableVolumesUsageDescription</key><string>JANITOR only inspects volumes you choose.</string>
</dict>
</plist>
JANITOR_EOF

cat > "$PROJ/README.md" <<'JANITOR_EOF'
# JANITOR (native macOS) — v0.1.0

Justified Analysis, Navigation, Inspection, Tidying, Optimization & Recovery.
Contract: **UNKNOWN != JUNK.** Inspect → classify → review → confirm → act → verify → record.
No daemon, telemetry, scheduler, watcher, server, cloud or AI dependency.

## Capability matrix (this build)
| Area | Status |
|---|---|
| Quick Scan / Full Scan (bounded, per-root deadlines, PARTIAL on timeout) | Implemented |
| Storage Overview, Choose What to Scan | Implemented |
| Maintenance: safe clean, `brew cleanup`, `simctl delete unavailable`, quarantine aging | Implemented |
| Developer Quick, Project Identity/Versions, Build Families (first+latest kept), Build/Dependency Discovery | Implemented |
| Media Inventory + Large Media, Exact Duplicates (CryptoKit, size→partial→full hash), Similar Names, Photos footprint (read-only) | Implemented |
| Processes, Startup/Background (launchd plists), Installed Apps, Support Inventory, Broken Items, Storage Diagnostics + local snapshots | Implemented (read-only) |
| Quarantine: manifest, verified moves, restore (collision-safe), missing-tolerant, delete | Implemented |
| Reports → ~/Library/Logs/JANITOR/ | Implemented |
| File Provider / iCloud-aware actions | DEFERRED — provider roots are detected and never traversed, hashed, moved or copied |
| PhotoKit analysis | DEFERRED — Photos libraries are PROTECTED, footprint only |
| Signing/origin attribution, Quit/Force Quit, SMAppService login items, true orphan attribution | DEFERRED |
| Privacy inspection, Project consolidation actions, Deep scans other than duplicates | NOT YET IMPLEMENTED |

## Status
Compiled and exercised only on the machine that builds it. Nothing here is a PHYSICAL PASS until you run the acceptance list on your target Mac.
JANITOR_EOF

cat > "$SRC/App.swift" <<'JANITOR_EOF'
import SwiftUI
import AppKit

final class AppDelegate: NSObject, NSApplicationDelegate {
    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.regular)
        NSApp.activate(ignoringOtherApps: true)
    }
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { true }
}

@main
struct JANITORApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) private var delegate
    @StateObject private var model = Model()

    var body: some Scene {
        WindowGroup("JANITOR") {
            RootView()
                .environmentObject(model)
                .frame(minWidth: 1000, minHeight: 680)
        }
        .commands { CommandGroup(replacing: .newItem) {} }
    }
}
JANITOR_EOF

cat > "$SRC/Core.swift" <<'JANITOR_EOF'
import Foundation
import CryptoKit

let janitorVersion = "0.1.0"

func fmtBytes(_ b: Int64) -> String { ByteCountFormatter.string(fromByteCount: b, countStyle: .file) }

enum StorageClass: String, Sendable {
    case local = "LOCAL", external = "EXTERNAL", network = "NETWORK"
    case fileProvider = "FILE_PROVIDER-CLOUD", photos = "PHOTOS_LIBRARY"
    case protected = "PROTECTED", unknown = "UNKNOWN"
    var scannable: Bool { self == .local || self == .external }
}

enum ScanStatus: String, Sendable {
    case complete = "COMPLETE", partial = "PARTIAL", review = "REVIEW"
    case skipped = "SKIPPED", protected = "PROTECTED", deferred = "DEFERRED"
}

struct RootStatus: Identifiable, Sendable {
    let id = UUID()
    var path: String
    var storage: StorageClass
    var status: ScanStatus
    var bytes: Int64
    var note: String
}

struct Candidate: Identifiable, Sendable, Hashable {
    let id = UUID()
    let url: URL
    let category: String
    let bytes: Int64
    let note: String
    var preselect: Bool
    var title: String { url.lastPathComponent }
}

struct InfoSection: Identifiable, Sendable {
    let id = UUID()
    var title: String
    var rows: [String]
}

struct ScanOutput: Sendable {
    var title: String
    var lines: [String] = []
    var roots: [RootStatus] = []
    var sections: [InfoSection] = []
    var candidates: [Candidate] = []
}

struct ActionResult: Identifiable, Sendable {
    let id = UUID()
    var state: String
    var name: String
    var detail: String
    var cid: UUID? = nil
}

// MARK: - Preferences

enum Prefs {
    static let ud = UserDefaults.standard
    static var timeout: TimeInterval { let v = ud.double(forKey: "timeout"); return v >= 2 ? v : 6 }
    static var maxDepth: Int { let v = ud.integer(forKey: "maxDepth"); return (2...6).contains(v) ? v : 4 }
    static var defaultQuarantineRoot: URL {
        FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Downloads/#Review&Delete/JANITOR", isDirectory: true)
    }
    static var quarantineRoot: URL {
        if let s = ud.string(forKey: "quarantineRoot"), !s.isEmpty { return URL(fileURLWithPath: s, isDirectory: true) }
        return defaultQuarantineRoot
    }
}

// MARK: - Storage classification (conservative)

enum Storage {
    static let home = FileManager.default.homeDirectoryForCurrentUser
    static let desktop = home.appendingPathComponent("Desktop").path
    static let documents = home.appendingPathComponent("Documents").path
    static let iCloudActive = FileManager.default.fileExists(
        atPath: home.appendingPathComponent("Library/Mobile Documents/com~apple~CloudDocs").path)

    /// Conventional paths are not proof of local storage: when iCloud Drive exists,
    /// Desktop and Documents are treated as provider-managed.
    static func classify(_ url: URL) -> StorageClass {
        let u = url.resolvingSymlinksInPath()
        let p = u.path
        if u.pathComponents.contains(where: { $0.hasSuffix(".photoslibrary") }) { return .photos }
        if p.contains("/Library/CloudStorage") || p.contains("/Library/Mobile Documents") { return .fileProvider }
        for pre in ["/System", "/usr", "/bin", "/sbin", "/private/var/db", "/Library/Apple"] where p == pre || p.hasPrefix(pre + "/") {
            return .protected
        }
        if iCloudActive {
            for d in [desktop, documents] where p == d || p.hasPrefix(d + "/") { return .fileProvider }
        }
        if let v = try? u.resourceValues(forKeys: [.isUbiquitousItemKey]), v.isUbiquitousItem == true { return .fileProvider }
        guard let vol = try? u.resourceValues(forKeys: [.volumeIsLocalKey, .volumeIsInternalKey]) else { return .unknown }
        if vol.volumeIsLocal == false { return .network }
        if vol.volumeIsInternal == false { return .external }
        return vol.volumeIsLocal == true ? .local : .unknown
    }

    /// Cheap check used during traversal: never descend into these.
    static func isBoundary(_ url: URL, allowPhotos: Bool = false) -> Bool {
        let p = url.path
        if !allowPhotos && url.pathExtension == "photoslibrary" { return true }
        if p.contains("/Library/CloudStorage") || p.contains("/Library/Mobile Documents") { return true }
        if iCloudActive && (p == desktop || p == documents) { return true }
        return false
    }
}

// MARK: - Bounded process runner

enum Shell {
    static func which(_ name: String) -> String? {
        for d in ["/opt/homebrew/bin", "/usr/local/bin", "/usr/bin", "/bin", "/usr/sbin", "/sbin"] {
            let p = d + "/" + name
            if FileManager.default.isExecutableFile(atPath: p) { return p }
        }
        return nil
    }

    static func run(_ path: String, _ args: [String], timeout: TimeInterval = 15) -> (ok: Bool, out: String, timedOut: Bool) {
        let fm = FileManager.default
        guard fm.isExecutableFile(atPath: path) else { return (false, "", false) }
        let tmp = fm.temporaryDirectory.appendingPathComponent("janitor-\(UUID().uuidString).out")
        fm.createFile(atPath: tmp.path, contents: nil)
        guard let fh = try? FileHandle(forWritingTo: tmp) else { return (false, "", false) }
        defer { try? fh.close(); try? fm.removeItem(at: tmp) }
        let p = Process()
        p.executableURL = URL(fileURLWithPath: path)
        p.arguments = args
        p.standardOutput = fh
        p.standardError = fh
        p.standardInput = FileHandle.nullDevice
        do { try p.run() } catch { return (false, error.localizedDescription, false) }
        let end = Date().addingTimeInterval(timeout)
        var timedOut = false
        while p.isRunning {
            if Date() > end { timedOut = true; p.terminate(); break }
            if Task.isCancelled { p.terminate(); break }
            usleep(50_000)
        }
        p.waitUntilExit()
        let data = (try? Data(contentsOf: tmp)) ?? Data()
        return (p.terminationStatus == 0 && !timedOut, String(decoding: data, as: UTF8.self), timedOut)
    }
}

// MARK: - Name families (build numbers / versions / repeated downloads)

enum Names {
    static let verRegex = try! NSRegularExpression(
        pattern: #"(?:[\s._-]+(?:v|ver|version|build|b|rc|r))?[\s._-]*\d+"#, options: [.caseInsensitive])
    static let digitRegex = try! NSRegularExpression(pattern: #"\d+"#)

    static func parse(_ stem: String) -> (base: String, nums: [Int])? {
        let ns = stem as NSString
        let full = NSRange(location: 0, length: ns.length)
        let nums = digitRegex.matches(in: stem, range: full).compactMap { Int(String(ns.substring(with: $0.range).prefix(9))) }
        if nums.isEmpty { return nil }
        let stripped = verRegex.stringByReplacingMatches(in: stem, range: full, withTemplate: "")
        let base = stripped.trimmingCharacters(in: CharacterSet(charactersIn: " ._-")).lowercased()
        return (base.isEmpty ? stem.lowercased() : base, nums)
    }

    static func family(_ name: String) -> String { parse(name)?.base ?? name.lowercased() }

    static func less(_ a: [Int], _ b: [Int]) -> Bool {
        for (x, y) in zip(a, b) where x != y { return x < y }
        return a.count < b.count
    }
}

// MARK: - Reports

enum Report {
    static var dir: URL {
        FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Library/Logs/JANITOR", isDirectory: true)
    }

    static func write(_ title: String, lines: [String]) {
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let f = DateFormatter(); f.dateFormat = "yyyyMMdd-HHmmss"
        let safe = title.replacingOccurrences(of: " ", with: "_").replacingOccurrences(of: "/", with: "-")
        var body = ["JANITOR \(janitorVersion) — \(title)",
                    "Time: \(Quarantine.iso())",
                    "Host: macOS \(ProcessInfo.processInfo.operatingSystemVersionString)", ""]
        body += lines
        try? body.joined(separator: "\n").write(
            to: dir.appendingPathComponent("\(f.string(from: Date()))-\(safe).txt"), atomically: true, encoding: .utf8)
    }

    static func scanLines(_ o: ScanOutput) -> [String] {
        var l = o.lines
        l.append("")
        l.append("Roots / exclusions:")
        for r in o.roots { l.append("  [\(r.status.rawValue)] \(r.storage.rawValue) \(r.path) \(fmtBytes(r.bytes)) \(r.note)") }
        for s in o.sections { l.append(""); l.append("\(s.title):"); l += s.rows.prefix(200).map { "  " + $0 } }
        l.append("")
        l.append("Candidates: \(o.candidates.count)")
        for c in o.candidates.prefix(200) { l.append("  \(c.category) \(fmtBytes(c.bytes)) \(c.url.path) — \(c.note)") }
        return l
    }
}
JANITOR_EOF

cat > "$SRC/Scan.swift" <<'JANITOR_EOF'
import Foundation
import CryptoKit

/// Bounded filesystem primitives. Every traversal has a deadline, never follows symlinks,
/// never crosses a volume boundary, never enters provider/Photos roots, and continues past errors.
enum Scan {
    static func listChildren(_ dir: URL) -> [URL]? {
        try? FileManager.default.contentsOfDirectory(at: dir, includingPropertiesForKeys: nil, options: [])
    }

    static func exists(_ u: URL) -> Bool { FileManager.default.fileExists(atPath: u.path) }

    static func size(of root: URL, maxDepth: Int = 8, deadline: Date, allowPhotos: Bool = false)
        -> (bytes: Int64, files: Int, status: ScanStatus, skipped: [String]) {
        if let r0 = try? root.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey, .totalFileAllocatedSizeKey]),
           r0.isDirectory != true {
            return (r0.isSymbolicLink == true ? 0 : Int64(r0.totalFileAllocatedSize ?? 0), 1, .complete, [])
        }
        var bytes: Int64 = 0, files = 0, skipped: [String] = []
        var status = ScanStatus.complete, depthHit = false
        let keys: [URLResourceKey] = [.isDirectoryKey, .isSymbolicLinkKey, .totalFileAllocatedSizeKey, .fileAllocatedSizeKey, .volumeIdentifierKey]
        let rootVol = try? root.resourceValues(forKeys: [.volumeIdentifierKey]).volumeIdentifier
        guard let en = FileManager.default.enumerator(at: root, includingPropertiesForKeys: keys, options: [],
                                                      errorHandler: { _, _ in true }) else { return (0, 0, .skipped, []) }
        var n = 0
        while let obj = en.nextObject() {
            guard let url = obj as? URL else { continue }
            n += 1
            if n % 256 == 0, Date() > deadline || Task.isCancelled { status = .partial; break }
            guard let rv = try? url.resourceValues(forKeys: Set(keys)) else { continue }
            if rv.isSymbolicLink == true { continue }
            if rv.isDirectory == true {
                if Storage.isBoundary(url, allowPhotos: allowPhotos) { en.skipDescendants(); skipped.append(url.lastPathComponent); continue }
                if let a = rootVol, let b = rv.volumeIdentifier, !a.isEqual(b) { en.skipDescendants(); continue }
                if en.level >= maxDepth { en.skipDescendants(); depthHit = true }
            } else {
                bytes += Int64(rv.totalFileAllocatedSize ?? rv.fileAllocatedSize ?? 0)
                files += 1
            }
        }
        if depthHit && status == .complete { status = .partial }
        return (bytes, files, status, skipped)
    }

    /// Walk regular files (logical size) with depth + deadline bounds.
    static func walkFiles(_ root: URL, maxDepth: Int, deadline: Date, visit: (URL, Int64) -> Void)
        -> (status: ScanStatus, skipped: [String]) {
        var status = ScanStatus.complete
        var skipped: [String] = []
        let keys: [URLResourceKey] = [.isDirectoryKey, .isSymbolicLinkKey, .fileSizeKey, .volumeIdentifierKey]
        let rootVol = try? root.resourceValues(forKeys: [.volumeIdentifierKey]).volumeIdentifier
        guard let en = FileManager.default.enumerator(at: root, includingPropertiesForKeys: keys,
                                                      options: [.skipsPackageDescendants],
                                                      errorHandler: { _, _ in true }) else { return (.skipped, []) }
        var n = 0
        while let obj = en.nextObject() {
            guard let url = obj as? URL else { continue }
            n += 1
            if n % 128 == 0, Date() > deadline || Task.isCancelled { status = .partial; break }
            guard let rv = try? url.resourceValues(forKeys: Set(keys)) else { continue }
            if rv.isSymbolicLink == true { continue }
            if rv.isDirectory == true {
                if Storage.isBoundary(url) { en.skipDescendants(); skipped.append(url.lastPathComponent); continue }
                if let a = rootVol, let b = rv.volumeIdentifier, !a.isEqual(b) { en.skipDescendants(); continue }
                if en.level >= maxDepth { en.skipDescendants() }
            } else {
                visit(url, Int64(rv.fileSize ?? 0))
            }
        }
        return (status, skipped)
    }

    /// Measure each child of `dir` (one level), with a per-root time budget.
    static func candidates(in dir: URL, category: String, skip: Set<String> = [], budget: TimeInterval,
                           minBytes: Int64 = 100_000, limit: Int = 60,
                           rule: (URL) -> (String, Bool)?) -> (cands: [Candidate], root: RootStatus) {
        let cls = Storage.classify(dir)
        var root = RootStatus(path: dir.path, storage: cls, status: .complete, bytes: 0, note: "")
        guard cls.scannable else {
            root.status = cls == .protected ? .protected : .deferred
            root.note = "Not traversed: \(cls.rawValue)"
            return ([], root)
        }
        guard let kids = listChildren(dir) else {
            root.status = .skipped
            root.note = "Not readable (missing or permission needed)"
            return ([], root)
        }
        let dl = Date().addingTimeInterval(budget)
        var out: [Candidate] = []
        var total: Int64 = 0
        for k in kids {
            if skip.contains(k.lastPathComponent) || Storage.isBoundary(k) { continue }
            if Date() > dl || Task.isCancelled { root.status = .partial; root.note = "Time budget reached; remaining items not measured"; break }
            guard let (note, pre) = rule(k) else { continue }
            let r = size(of: k, deadline: dl)
            total += r.bytes
            if r.status == .partial { root.status = .partial; root.note = "Some items measured partially" }
            if r.bytes >= minBytes { out.append(Candidate(url: k, category: category, bytes: r.bytes, note: note, preselect: pre)) }
        }
        out.sort { $0.bytes > $1.bytes }
        if out.count > limit { out = Array(out.prefix(limit)) }
        root.bytes = total
        return (out, root)
    }

    /// One path measured as a single candidate.
    static func single(_ url: URL, category: String, note: String, pre: Bool, budget: TimeInterval) -> (Candidate?, RootStatus) {
        let cls = Storage.classify(url)
        var rs = RootStatus(path: url.path, storage: cls, status: .complete, bytes: 0, note: "")
        guard cls.scannable, !Storage.isBoundary(url) else {
            rs.status = cls == .protected ? .protected : .deferred; rs.note = "Not traversed: \(cls.rawValue)"; return (nil, rs)
        }
        let r = size(of: url, deadline: Date().addingTimeInterval(budget))
        rs.status = r.status; rs.bytes = r.bytes
        guard r.bytes > 0 else { return (nil, rs) }
        return (Candidate(url: url, category: category, bytes: r.bytes, note: note, preselect: pre), rs)
    }

    static func sha256(_ url: URL, limit: Int?, deadline: Date) -> String? {
        guard let h = try? FileHandle(forReadingFrom: url) else { return nil }
        defer { try? h.close() }
        var hasher = SHA256()
        var read = 0
        while true {
            if Date() > deadline || Task.isCancelled { return nil }
            let want = limit.map { min(1 << 20, $0 - read) } ?? (1 << 20)
            if want <= 0 { break }
            guard let d = try? h.read(upToCount: want), !d.isEmpty else { break }
            hasher.update(data: d)
            read += d.count
        }
        return hasher.finalize().map { String(format: "%02x", $0) }.joined()
    }
}
JANITOR_EOF

cat > "$SRC/Quarantine.swift" <<'JANITOR_EOF'
import Foundation

struct QItem: Codable, Identifiable, Hashable, Sendable {
    var id: String
    var original: String
    var destination: String
    var reason: String
    var timestamp: String
    var state: String      // MOVED / RESTORED / MISSING
    var bytes: Int64
}

struct QManifest: Codable, Sendable {
    var operation: String
    var created: String
    var version: String
    var items: [QItem]
}

struct QOp: Identifiable, Sendable {
    var folder: URL
    var manifest: QManifest
    var id: String { folder.lastPathComponent }
}

enum Quarantine {
    static func stamp() -> String { let f = DateFormatter(); f.dateFormat = "yyyyMMdd-HHmmss"; return f.string(from: Date()) }
    static func iso() -> String { ISO8601DateFormatter().string(from: Date()) }
    static func manifestURL(_ op: URL) -> URL { op.appendingPathComponent("manifest.json") }

    static func present(_ p: String) -> Bool {
        FileManager.default.fileExists(atPath: p) || (try? FileManager.default.destinationOfSymbolicLink(atPath: p)) != nil
    }

    static func save(_ m: QManifest, to folder: URL) {
        let enc = JSONEncoder()
        enc.outputFormatting = [.prettyPrinted, .sortedKeys]
        if let d = try? enc.encode(m) { try? d.write(to: manifestURL(folder), options: .atomic) }
    }

    static func sameVolume(_ a: URL, _ b: URL) -> Bool {
        guard let x = try? a.resourceValues(forKeys: [.volumeIdentifierKey]).volumeIdentifier,
              let y = try? b.resourceValues(forKeys: [.volumeIdentifierKey]).volumeIdentifier else { return false }
        return x.isEqual(y)
    }

    // MARK: move into quarantine (verified, per item)

    static func move(_ cands: [Candidate], label: String) -> (op: String, results: [ActionResult]) {
        let fm = FileManager.default
        let root = Prefs.quarantineRoot
        func all(_ state: String, _ detail: String) -> [ActionResult] {
            cands.map { ActionResult(state: state, name: $0.title, detail: detail, cid: $0.id) }
        }
        do { try fm.createDirectory(at: root, withIntermediateDirectories: true) }
        catch { return ("", all("FAILED", "Cannot create quarantine root: \(error.localizedDescription)")) }
        let rc = Storage.classify(root)
        guard rc.scannable else {
            return ("", all("SKIPPED", "Quarantine root is \(rc.rawValue); provider-safe quarantine is deferred"))
        }
        let opName = stamp() + "-" + label
        let opDir = root.appendingPathComponent(opName, isDirectory: true)
        let itemsDir = opDir.appendingPathComponent("items", isDirectory: true)
        do { try fm.createDirectory(at: itemsDir, withIntermediateDirectories: true) }
        catch { return ("", all("FAILED", "Cannot create operation folder: \(error.localizedDescription)")) }

        var manifest = QManifest(operation: label, created: iso(), version: janitorVersion, items: [])
        var results: [ActionResult] = []
        for (i, c) in cands.enumerated() {
            let src = c.url
            func rec(_ state: String, _ detail: String, dest: String = "") {
                results.append(ActionResult(state: state, name: c.title, detail: detail, cid: c.id))
                if state == "MOVED" {
                    manifest.items.append(QItem(id: UUID().uuidString, original: src.path, destination: dest,
                                                reason: c.category + (c.note.isEmpty ? "" : " — " + c.note),
                                                timestamp: iso(), state: "MOVED", bytes: c.bytes))
                }
            }
            guard present(src.path) else { rec("MISSING", "Source no longer exists"); continue }
            let parentClass = Storage.classify(src.deletingLastPathComponent())
            guard parentClass.scannable, !Storage.isBoundary(src) else {
                rec("SKIPPED", "\(parentClass.rawValue) — not moved by local quarantine"); continue
            }
            guard sameVolume(src.deletingLastPathComponent(), itemsDir) else {
                rec("SKIPPED", "Different volume from quarantine root (a move would copy)"); continue
            }
            let dest = itemsDir.appendingPathComponent(String(format: "%03d-", i + 1) + src.lastPathComponent)
            do { try fm.moveItem(at: src, to: dest) } catch { rec("FAILED", error.localizedDescription); continue }
            let srcGone = !present(src.path)
            let destThere = present(dest.path)
            if srcGone && destThere { rec("MOVED", fmtBytes(c.bytes), dest: dest.path) }
            else { rec("FAILED", "Verification failed (source still present: \(!srcGone), destination present: \(destThere))") }
        }
        save(manifest, to: opDir)
        return (opName, results)
    }

    // MARK: list / refresh (tolerates items removed by hand)

    static func loadOps() -> [QOp] {
        let root = Prefs.quarantineRoot
        guard let kids = try? FileManager.default.contentsOfDirectory(at: root, includingPropertiesForKeys: nil) else { return [] }
        var ops: [QOp] = []
        for k in kids.sorted(by: { $0.lastPathComponent > $1.lastPathComponent }) {
            guard let d = try? Data(contentsOf: manifestURL(k)),
                  var m = try? JSONDecoder().decode(QManifest.self, from: d) else { continue }
            var changed = false
            for i in m.items.indices where m.items[i].state == "MOVED" && !present(m.items[i].destination) {
                m.items[i].state = "MISSING"; changed = true
            }
            if changed { save(m, to: k) }
            ops.append(QOp(folder: k, manifest: m))
        }
        return ops
    }

    // MARK: restore

    static func uniqueURL(_ u: URL) -> URL {
        let base = u.deletingPathExtension().lastPathComponent
        let ext = u.pathExtension
        let dir = u.deletingLastPathComponent()
        var n = 1
        while true {
            let name = ext.isEmpty ? "\(base) (restored \(n))" : "\(base) (restored \(n)).\(ext)"
            let c = dir.appendingPathComponent(name)
            if !present(c.path) { return c }
            n += 1
        }
    }

    static func restore(_ op: QOp, ids: Set<String>?) -> [ActionResult] {
        let fm = FileManager.default
        var m = op.manifest
        var results: [ActionResult] = []
        for i in m.items.indices {
            let it = m.items[i]
            if let ids = ids, !ids.contains(it.id) { continue }
            let name = URL(fileURLWithPath: it.original).lastPathComponent
            guard it.state == "MOVED" else {
                results.append(ActionResult(state: it.state == "RESTORED" ? "SKIPPED" : it.state, name: name, detail: "Item state is \(it.state)"))
                continue
            }
            guard present(it.destination) else {
                m.items[i].state = "MISSING"
                results.append(ActionResult(state: "MISSING", name: name, detail: "No longer in quarantine (removed manually?)"))
                continue
            }
            var target = URL(fileURLWithPath: it.original)
            do { try fm.createDirectory(at: target.deletingLastPathComponent(), withIntermediateDirectories: true) }
            catch { results.append(ActionResult(state: "FAILED", name: name, detail: "Cannot recreate parent: \(error.localizedDescription)")); continue }
            var note = "Restored to original path"
            if present(target.path) { target = uniqueURL(target); note = "Original path occupied — restored as \(target.lastPathComponent)" }
            do { try fm.moveItem(at: URL(fileURLWithPath: it.destination), to: target) }
            catch { results.append(ActionResult(state: "FAILED", name: name, detail: error.localizedDescription)); continue }
            if present(target.path) && !present(it.destination) {
                m.items[i].state = "RESTORED"
                results.append(ActionResult(state: "RESTORED", name: name, detail: note))
            } else {
                results.append(ActionResult(state: "FAILED", name: name, detail: "Verification failed"))
            }
        }
        save(m, to: op.folder)
        return results
    }

    static func delete(_ op: QOp) -> (ActionResult, Int64) {
        let bytes = op.manifest.items.filter { $0.state == "MOVED" }.reduce(Int64(0)) { $0 + $1.bytes }
        do { try FileManager.default.removeItem(at: op.folder) }
        catch { return (ActionResult(state: "FAILED", name: op.id, detail: error.localizedDescription), 0) }
        if present(op.folder.path) { return (ActionResult(state: "FAILED", name: op.id, detail: "Still present after delete"), 0) }
        return (ActionResult(state: "DELETED", name: op.id, detail: "Quarantine operation removed"), bytes)
    }

    // MARK: direct delete of exact, user-selected candidates

    static func deleteCandidates(_ cands: [Candidate]) -> (results: [ActionResult], reclaimed: Int64) {
        var results: [ActionResult] = []
        var reclaimed: Int64 = 0
        for c in cands {
            func rec(_ s: String, _ d: String) { results.append(ActionResult(state: s, name: c.title, detail: d, cid: c.id)) }
            guard present(c.url.path) else { rec("MISSING", "Already gone"); continue }
            let cls = Storage.classify(c.url.deletingLastPathComponent())
            guard cls.scannable, !Storage.isBoundary(c.url), c.url.pathComponents.count >= 4 else {
                rec("SKIPPED", "\(cls.rawValue) — not deleted locally"); continue
            }
            do { try FileManager.default.removeItem(at: c.url) } catch { rec("FAILED", error.localizedDescription); continue }
            if present(c.url.path) { rec("FAILED", "Still present after delete") }
            else { reclaimed += c.bytes; rec("DELETED", fmtBytes(c.bytes)) }
        }
        return (results, reclaimed)
    }
}
JANITOR_EOF

cat > "$SRC/Modes.swift" <<'JANITOR_EOF'
import Foundation
import AppKit

/// All scan / inspection implementations. Pure functions: bounded, deadline-driven, error-tolerant.
enum Modes {
    static let home = FileManager.default.homeDirectoryForCurrentUser
    static func path(_ rel: String) -> URL { home.appendingPathComponent(rel) }
    static func abbrev(_ p: String) -> String { p.hasPrefix(home.path) ? "~" + String(p.dropFirst(home.path.count)) : p }
    static func exists(_ u: URL) -> Bool { FileManager.default.fileExists(atPath: u.path) }
    static func mtime(_ u: URL) -> Date? { (try? u.resourceValues(forKeys: [.contentModificationDateKey]))?.contentModificationDate }
    static func sum(_ c: [Candidate]) -> Int64 { c.reduce(Int64(0)) { $0 + $1.bytes } }

    static func volumeLine() -> String {
        let rv = try? URL(fileURLWithPath: "/").resourceValues(forKeys: [.volumeTotalCapacityKey, .volumeAvailableCapacityForImportantUsageKey])
        let total = Int64(rv?.volumeTotalCapacity ?? 0)
        let avail = rv?.volumeAvailableCapacityForImportantUsage ?? 0
        return "Startup volume: \(fmtBytes(total)) total · \(fmtBytes(avail)) available"
    }

    static func notTraversable(_ o: inout ScanOutput, _ root: URL, _ cls: StorageClass) {
        let st: ScanStatus = cls == .protected ? .protected : .deferred
        o.roots.append(RootStatus(path: root.path, storage: cls, status: st, bytes: 0, note: "Not traversed (\(cls.rawValue))"))
        o.lines.append("\(abbrev(root.path)) is \(cls.rawValue) — \(st.rawValue). Provider and Photos content is never crawled, hashed or moved.")
    }

    // MARK: STANDARD — Quick / Full

    struct Target { let url: URL; let category: String; let skip: Set<String>; let rule: (URL) -> (String, Bool)? }

    static func quick(full: Bool) -> ScanOutput {
        var o = ScanOutput(title: full ? "Full Scan" : "Quick Scan")
        let t = Prefs.timeout
        let global = Date().addingTimeInterval(t * (full ? 8 : 4))
        let tmp = URL(fileURLWithPath: NSTemporaryDirectory(), isDirectory: true)

        let cacheRule: (URL) -> (String, Bool)? = { u in
            u.lastPathComponent.hasPrefix("com.apple.") ? ("Apple component cache — review first", false) : ("Regenerable app cache", true)
        }
        let logRule: (URL) -> (String, Bool)? = { _ in ("Log files", true) }
        let trashRule: (URL) -> (String, Bool)? = { _ in ("Already in Trash", true) }
        let tempRule: (URL) -> (String, Bool)? = { u in
            if let d = mtime(u), Date().timeIntervalSince(d) > 14 * 86400 { return ("Stale temp data (>14 days)", true) }
            return nil
        }
        let containerRule: (URL) -> (String, Bool)? = { u in
            let comps = u.pathComponents
            let owner = comps.firstIndex(of: "Containers").map { $0 + 1 < comps.count ? comps[$0 + 1] : "?" } ?? "?"
            return ("App container cache (\(owner))", true)
        }

        var targets: [Target] = [
            Target(url: path("Library/Caches"), category: "CACHE", skip: ["Homebrew", "com.janitor.native"], rule: cacheRule),
            Target(url: path("Library/Logs"), category: "LOG", skip: ["JANITOR"], rule: logRule),
            Target(url: path(".Trash"), category: "TRASH", skip: [], rule: trashRule),
            Target(url: tmp, category: "TEMP", skip: [], rule: tempRule)
        ]
        if full, let conts = Scan.listChildren(path("Library/Containers")) {
            for c in conts.prefix(80) {
                let caches = c.appendingPathComponent("Data/Library/Caches")
                if exists(caches) { targets.append(Target(url: caches, category: "CONTAINER CACHE", skip: [], rule: containerRule)) }
            }
        }

        for tg in targets {
            if Date() > global || Task.isCancelled {
                o.roots.append(RootStatus(path: tg.url.path, storage: .unknown, status: .skipped, bytes: 0, note: "Global time budget reached"))
                continue
            }
            guard exists(tg.url) else { continue }
            let r = Scan.candidates(in: tg.url, category: tg.category, skip: tg.skip, budget: full ? t : t / 2, rule: tg.rule)
            o.candidates += r.cands
            o.roots.append(r.root)
        }

        let pre = o.candidates.filter { $0.preselect }
        o.lines.append("Safe items preselected: \(pre.count) · \(fmtBytes(sum(pre)))")
        o.lines.append("Candidates listed: \(o.candidates.count) · \(fmtBytes(sum(o.candidates)))  (unknown ≠ junk: Apple caches and anything unclassified are left unselected)")
        let notComplete = o.roots.filter { $0.status != .complete }.count
        if notComplete > 0 { o.lines.append("\(notComplete) root(s) not COMPLETE — see Roots") }
        if exists(path("Library/Caches/Homebrew")) {
            o.lines.append("Homebrew cache present — not treated as junk. Use Maintenance → Homebrew cleanup (native `brew cleanup`).")
        }

        // Shallow top-level storage + quarantine (no recursion into Downloads)
        let dl = path("Downloads")
        if Storage.classify(dl).scannable, let kids = Scan.listChildren(dl) {
            var rows: [(Int64, String)] = []
            for k in kids {
                guard let rv = try? k.resourceValues(forKeys: [.isDirectoryKey, .totalFileAllocatedSizeKey]) else { continue }
                if rv.isDirectory == true { rows.append((0, "(folder)  \(k.lastPathComponent)")) }
                else { let b = Int64(rv.totalFileAllocatedSize ?? 0); rows.append((b, "\(fmtBytes(b))  \(k.lastPathComponent)")) }
            }
            rows.sort { $0.0 > $1.0 }
            o.sections.append(InfoSection(title: "Downloads — top level only (not scanned deeper)", rows: rows.prefix(12).map { $0.1 }))
        }
        let q = Prefs.quarantineRoot
        if exists(q) {
            let r = Scan.size(of: q, deadline: Date().addingTimeInterval(min(t, 3)))
            o.lines.append("Quarantine: \(Quarantine.present(q.path) ? fmtBytes(r.bytes) : "—") on disk [\(r.status.rawValue)]")
        }
        if full {
            let ov = overview()
            o.sections += ov.sections
            o.lines.append(ov.lines.first ?? "")
        }
        return o
    }

    static func overview() -> ScanOutput {
        var o = ScanOutput(title: "Storage Overview")
        o.lines.append(volumeLine())
        let t = Prefs.timeout
        let global = Date().addingTimeInterval(t * 4)
        var rows: [(Int64, String)] = []
        var notes: [String] = []
        for k in (Scan.listChildren(home) ?? []).sorted(by: { $0.lastPathComponent < $1.lastPathComponent }) {
            let name = k.lastPathComponent
            if name == ".Trash" { continue }
            let cls = Storage.classify(k)
            if !cls.scannable || Storage.isBoundary(k) { notes.append("\(name): \(cls.rawValue) — not traversed (DEFERRED)"); continue }
            if Date() > global || Task.isCancelled { notes.append("\(name): SKIPPED — global time budget reached"); continue }
            let r = Scan.size(of: k, deadline: Date().addingTimeInterval(t / 2))
            rows.append((r.bytes, "\(fmtBytes(r.bytes))  \(name)  [\(r.status.rawValue)]"))
        }
        rows.sort { $0.0 > $1.0 }
        o.sections.append(InfoSection(title: "Home folder — largest local items", rows: rows.prefix(25).map { $0.1 }))
        if !notes.isEmpty { o.sections.append(InfoSection(title: "Not traversed", rows: notes)) }
        return o
    }

    static func chosen(_ url: URL) -> ScanOutput {
        var o = ScanOutput(title: "Scan \(url.lastPathComponent)")
        let cls = Storage.classify(url)
        guard cls.scannable, !Storage.isBoundary(url) else { notTraversable(&o, url, cls); return o }
        let r = Scan.candidates(in: url, category: "USER-SELECTED — UNKNOWN", budget: Prefs.timeout * 2, minBytes: 1) { _ in
            ("Unclassified — your decision", false)
        }
        o.candidates = r.cands
        o.roots.append(r.root)
        o.lines.append("\(abbrev(url.path)): \(fmtBytes(r.root.bytes)) [\(r.root.status.rawValue)] — nothing is preselected")
        return o
    }

    // MARK: DEVELOPER

    static func defaultDevRoot() -> URL {
        for n in ["Developer", "Projects", "Code", "dev", "src", "Xcode"] where exists(path(n)) { return path(n) }
        return path("Downloads")
    }

    static func devQuick() -> ScanOutput {
        var o = ScanOutput(title: "Developer Quick")
        let t = Prefs.timeout
        let xcodeRunning = !NSRunningApplication.runningApplications(withBundleIdentifier: "com.apple.dt.Xcode").isEmpty
        func add(_ r: (cands: [Candidate], root: RootStatus)) { o.candidates += r.cands; o.roots.append(r.root) }
        func one(_ rel: String, _ cat: String, _ note: String, _ pre: Bool) {
            let u = path(rel)
            guard exists(u) else { return }
            let r = Scan.single(u, category: cat, note: note, pre: pre, budget: t)
            if let c = r.0 { o.candidates.append(c) }
            o.roots.append(r.1)
        }
        let dd = path("Library/Developer/Xcode/DerivedData")
        if exists(dd) {
            add(Scan.candidates(in: dd, category: "BUILD OUTPUT", budget: t, minBytes: 1) { u in
                if xcodeRunning { return ("DerivedData — Xcode is running; review before removing", false) }
                if let d = mtime(u), Date().timeIntervalSince(d) < 600 { return ("Built in the last 10 minutes — treated as active", false) }
                return ("DerivedData (regenerable by rebuilding)", true)
            })
        }
        let sim = path("Library/Developer/CoreSimulator/Caches")
        if exists(sim) { add(Scan.candidates(in: sim, category: "SAFE CACHE", budget: t) { _ in ("Simulator cache", true) }) }
        one("Library/Caches/org.swift.swiftpm", "SAFE CACHE", "SwiftPM cache (re-downloaded on demand)", true)
        one(".npm", "SAFE CACHE", "npm cache (re-downloaded; `npm cache clean --force` is the native cleaner)", true)
        one(".gradle/caches", "SAFE CACHE", "Gradle cache (re-downloaded on demand)", true)
        let ar = path("Library/Developer/Xcode/Archives")
        if exists(ar) { add(Scan.candidates(in: ar, category: "PROJECT DATA", budget: t, minBytes: 1) { _ in ("Xcode archives are project data — review only", false) }) }
        let ds = path("Library/Developer/Xcode/iOS DeviceSupport")
        if exists(ds) { add(Scan.candidates(in: ds, category: "UNKNOWN", budget: t) { _ in ("Device support — regenerated on next connect; review age first", false) }) }

        let devices = path("Library/Developer/CoreSimulator/Devices")
        if exists(devices) {
            let r = Scan.size(of: devices, deadline: Date().addingTimeInterval(t))
            o.sections.append(InfoSection(title: "Simulator data (not listed for deletion)", rows: [
                "\(fmtBytes(r.bytes)) [\(r.status.rawValue)] CoreSimulator/Devices — PROJECT DATA. Use Standard → Maintenance → “Remove unavailable simulators” (native simctl)."]))
        }
        let pre = o.candidates.filter { $0.preselect }
        o.lines.append("Safe items preselected: \(pre.count) · \(fmtBytes(sum(pre)))")
        o.lines.append("Candidates listed: \(o.candidates.count) · \(fmtBytes(sum(o.candidates)))")
        if xcodeRunning { o.lines.append("Xcode is running — DerivedData left unselected so active compilation products are never removed blindly.") }
        return o
    }

    static let suppress: Set<String> = ["node_modules", "vendor", "Pods", ".build", "Carthage", ".venv", "venv",
                                        "site-packages", "dist-packages", "DerivedData", "target", ".gradle", "__pycache__"]

    static func projects(root: URL) -> ScanOutput {
        var o = ScanOutput(title: "Project Identity & Versions")
        let cls = Storage.classify(root)
        guard cls.scannable, !Storage.isBoundary(root) else { notTraversable(&o, root, cls); return o }
        let t = Prefs.timeout * 3
        let maxDepth = Prefs.maxDepth
        let dl = Date().addingTimeInterval(t)
        let markerFiles: [String: String] = [".git": "Git", "Package.swift": "SwiftPM", "package.json": "Node", "pyproject.toml": "Python",
                                             "Cargo.toml": "Rust", "build.gradle": "Gradle", "build.gradle.kts": "Gradle", "pom.xml": "Maven", "go.mod": "Go"]
        let markerExts: [String: String] = ["xcodeproj": "Xcode", "xcworkspace": "Xcode"]
        var found: [String: Set<String>] = [:]
        var archives: [URL] = []
        var partial = false
        if let en = FileManager.default.enumerator(at: root, includingPropertiesForKeys: [.isDirectoryKey, .isSymbolicLinkKey],
                                                   options: [], errorHandler: { _, _ in true }) {
            var n = 0
            while let obj = en.nextObject() {
                guard let url = obj as? URL else { continue }
                n += 1
                if n % 128 == 0, Date() > dl || Task.isCancelled { partial = true; break }
                let rv = try? url.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
                if rv?.isSymbolicLink == true { continue }
                let isDir = rv?.isDirectory == true
                let name = url.lastPathComponent
                let parent = url.deletingLastPathComponent().path
                if let k = markerFiles[name] { found[parent, default: []].insert(k) }
                if isDir, let k = markerExts[url.pathExtension] { found[parent, default: []].insert(k); en.skipDescendants(); continue }
                if isDir {
                    if Storage.isBoundary(url) || suppress.contains(name) || name == ".git" { en.skipDescendants(); continue }
                    if en.level >= maxDepth { en.skipDescendants() }
                } else if ["zip", "gz", "tgz", "xip", "tar"].contains(url.pathExtension.lowercased()) {
                    archives.append(url)
                }
            }
        }
        let entries = found.map { (path: $0.key, kinds: $0.value.sorted()) }.sorted { $0.path < $1.path }
        o.roots.append(RootStatus(path: root.path, storage: cls, status: partial ? .partial : .complete, bytes: 0,
                                  note: "depth ≤ \(maxDepth), time ≤ \(Int(t))s; dependencies/vendor/node_modules suppressed"))
        o.lines.append("\(entries.count) project(s) found under \(abbrev(root.path)) [\(partial ? "PARTIAL" : "COMPLETE")]")
        o.sections.append(InfoSection(title: "Projects", rows: entries.prefix(150).map { "\($0.kinds.joined(separator: "+"))  \(abbrev($0.path))" }))

        let groups = Dictionary(grouping: entries, by: { Names.family(URL(fileURLWithPath: $0.path).lastPathComponent) })
        let git = Shell.which("git")
        var gitCalls = 0
        var rows: [String] = []
        for (fam, members) in groups.sorted(by: { $0.key < $1.key }) where members.count > 1 {
            rows.append("Family “\(fam)” — \(members.count) locations")
            for m in members {
                var g = ""
                if m.kinds.contains("Git"), let gp = git, gitCalls < 25 {
                    gitCalls += 1
                    let r = Shell.run(gp, ["-C", m.path, "status", "--porcelain"], timeout: 3)
                    g = r.ok ? (r.out.isEmpty ? " · git: clean" : " · git: \(r.out.split(separator: "\n").count) change(s)") : " · git: unknown"
                } else if m.kinds.contains("Git") { g = " · git working copy" }
                rows.append("   working copy: \(abbrev(m.path)) [\(m.kinds.joined(separator: "+"))]\(g)")
            }
            for a in archives where Names.family(a.deletingPathExtension().lastPathComponent) == fam {
                rows.append("   archive: \(abbrev(a.path))")
            }
        }
        if rows.isEmpty { rows = ["No related copies/versions detected."] }
        o.sections.append(InfoSection(title: "Related copies / versions (review only — sources are never auto-merged)", rows: rows))
        return o
    }

    static func buildFamilies(root: URL) -> ScanOutput {
        var o = ScanOutput(title: "Build Families")
        let cls = Storage.classify(root)
        guard cls.scannable, !Storage.isBoundary(root) else { notTraversable(&o, root, cls); return o }
        if exists(root.appendingPathComponent(".git")) {
            o.lines.append("\(abbrev(root.path)) is a Git working copy — excluded. Choose the folder that holds delivered builds.")
            return o
        }
        struct Item { let url: URL; let nums: [Int]; let bytes: Int64; let date: Date }
        let exts: Set<String> = ["zip", "dmg", "ipa", "pkg", "xip", "tgz", "gz", "apk", "aab", "msi", "deb", "app", "xcarchive"]
        let maxDepth = Prefs.maxDepth
        let dl = Date().addingTimeInterval(Prefs.timeout * 3)
        var fam: [String: [Item]] = [:]
        var partial = false
        func add(_ url: URL, _ bytes: Int64) {
            let stem = url.deletingPathExtension().lastPathComponent
            guard let p = Names.parse(stem) else { return }
            fam[p.base + "|" + url.pathExtension.lowercased(), default: []]
                .append(Item(url: url, nums: p.nums, bytes: bytes, date: mtime(url) ?? .distantPast))
        }
        if let en = FileManager.default.enumerator(at: root, includingPropertiesForKeys: [.isDirectoryKey, .isSymbolicLinkKey, .totalFileAllocatedSizeKey],
                                                   options: [], errorHandler: { _, _ in true }) {
            var n = 0
            while let obj = en.nextObject() {
                guard let url = obj as? URL else { continue }
                n += 1
                if n % 128 == 0, Date() > dl || Task.isCancelled { partial = true; break }
                let rv = try? url.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey, .totalFileAllocatedSizeKey])
                if rv?.isSymbolicLink == true { continue }
                let ext = url.pathExtension.lowercased()
                if rv?.isDirectory == true {
                    let name = url.lastPathComponent
                    if Storage.isBoundary(url) || suppress.contains(name) || name == ".git" { en.skipDescendants(); continue }
                    if exists(url.appendingPathComponent(".git")) { en.skipDescendants(); continue }
                    if ext == "app" || ext == "xcarchive" {
                        en.skipDescendants()
                        add(url, Scan.size(of: url, deadline: Date().addingTimeInterval(2)).bytes)
                        continue
                    }
                    if en.level >= maxDepth { en.skipDescendants() }
                } else if exts.contains(ext) {
                    add(url, Int64(rv?.totalFileAllocatedSize ?? 0))
                }
            }
        }
        o.roots.append(RootStatus(path: root.path, storage: cls, status: partial ? .partial : .complete, bytes: 0,
                                  note: "depth ≤ \(maxDepth); Git working copies excluded"))
        var rows: [String] = []
        var interTotal = 0
        for (key, var items) in fam.sorted(by: { $0.key < $1.key }) where items.count >= 2 {
            items.sort { Names.less($0.nums, $1.nums) || ($0.nums == $1.nums && $0.date < $1.date) }
            let first = items[0], latest = items[items.count - 1]
            var inter: [Item] = items.count >= 3 ? Array(items[1..<(items.count - 1)]) : []
            let active = inter.filter { Date().timeIntervalSince($0.date) < 600 }.count
            inter = inter.filter { Date().timeIntervalSince($0.date) >= 600 }
            let size = inter.reduce(Int64(0)) { $0 + $1.bytes }
            let label = key.split(separator: "|").map(String.init)
            rows.append("\(label.first ?? key) (.\(label.last ?? "")) — \(items.count) builds · first \(first.url.lastPathComponent) · latest \(latest.url.lastPathComponent) · \(inter.count) intermediate(s) \(fmtBytes(size))\(active > 0 ? " · \(active) active, skipped" : "")")
            interTotal += inter.count
            for i in inter {
                o.candidates.append(Candidate(url: i.url, category: "BUILD FAMILY INTERMEDIATE", bytes: i.bytes,
                                              note: "family keeps first \(first.url.lastPathComponent) + latest \(latest.url.lastPathComponent)", preselect: false))
            }
        }
        o.lines.append("\(rows.count) build family(ies) · \(interTotal) intermediate candidate(s) · \(fmtBytes(sum(o.candidates)))")
        o.lines.append("First + latest are always preserved. Ordering uses version/build numbers only — verify before deleting. Nothing is preselected.")
        o.sections.append(InfoSection(title: "Families", rows: rows.isEmpty ? ["No multi-build families found."] : rows))
        return o
    }

    static func dependencies(root: URL) -> ScanOutput {
        var o = ScanOutput(title: "Build & Dependency Discovery")
        let cls = Storage.classify(root)
        guard cls.scannable, !Storage.isBoundary(root) else { notTraversable(&o, root, cls); return o }
        let eco: [String: (marker: [String], note: String, cat: String)] = [
            "node_modules": (["package.json"], "Node dependencies — restore with `npm install`", "DEPENDENCY"),
            ".build": (["Package.swift"], "SwiftPM build output — rebuilt by `swift build`", "BUILD OUTPUT"),
            "Pods": (["Podfile"], "CocoaPods dependencies — restore with `pod install`", "DEPENDENCY"),
            "target": (["Cargo.toml"], "Rust build output — `cargo clean` is the native cleaner", "BUILD OUTPUT"),
            "build": (["build.gradle", "build.gradle.kts"], "Gradle build output — `./gradlew clean`", "BUILD OUTPUT"),
            ".venv": (["pyproject.toml", "requirements.txt"], "Python virtualenv — recreate from requirements", "DEPENDENCY"),
            "venv": (["pyproject.toml", "requirements.txt"], "Python virtualenv — recreate from requirements", "DEPENDENCY"),
            "Carthage": (["Cartfile"], "Carthage checkouts — `carthage bootstrap`", "DEPENDENCY")
        ]
        let t = Prefs.timeout
        let global = Date().addingTimeInterval(t * 6)
        let maxDepth = Prefs.maxDepth
        var partial = false
        if let en = FileManager.default.enumerator(at: root, includingPropertiesForKeys: [.isDirectoryKey, .isSymbolicLinkKey],
                                                   options: [], errorHandler: { _, _ in true }) {
            var n = 0
            while let obj = en.nextObject() {
                guard let url = obj as? URL else { continue }
                n += 1
                if n % 128 == 0, Date() > global || Task.isCancelled { partial = true; break }
                let rv = try? url.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
                guard rv?.isDirectory == true, rv?.isSymbolicLink != true else { continue }
                let name = url.lastPathComponent
                if Storage.isBoundary(url) || name == ".git" { en.skipDescendants(); continue }
                if let e = eco[name] {
                    en.skipDescendants()
                    let parent = url.deletingLastPathComponent()
                    guard e.marker.contains(where: { exists(parent.appendingPathComponent($0)) }) else { continue }
                    let s = Scan.size(of: url, deadline: Date().addingTimeInterval(t))
                    if s.bytes > 0 {
                        let active = mtime(url).map { Date().timeIntervalSince($0) < 600 } ?? false
                        o.candidates.append(Candidate(url: url, category: e.cat, bytes: s.bytes,
                                                      note: e.note + (active ? " · modified in last 10 min — treated as active" : ""), preselect: false))
                    }
                    continue
                }
                if en.level >= maxDepth { en.skipDescendants() }
            }
        }
        o.candidates.sort { $0.bytes > $1.bytes }
        o.roots.append(RootStatus(path: root.path, storage: cls, status: partial ? .partial : .complete, bytes: 0, note: "depth ≤ \(maxDepth)"))
        o.lines.append("\(o.candidates.count) regenerable item(s) · \(fmtBytes(sum(o.candidates))) — a marker file (package.json, Package.swift, …) must sit beside each one. Nothing is preselected; prefer the ecosystem's native cleaner.")
        return o
    }

    // MARK: MEDIA

    static let videoExt: Set<String> = ["mp4", "mov", "m4v", "mkv", "avi", "webm"]
    static let imageExt: Set<String> = ["jpg", "jpeg", "png", "heic", "gif", "tiff", "dng", "webp", "psd"]
    static let audioExt: Set<String> = ["mp3", "m4a", "wav", "aiff", "flac", "aac"]

    static func mediaRoots(_ root: URL?) -> [URL] {
        if let r = root { return [r] }
        return ["Movies", "Music", "Pictures", "Downloads"].map { path($0) }
    }

    static func media(root: URL?) -> ScanOutput {
        var o = ScanOutput(title: "Local Media Inventory")
        let t = Prefs.timeout
        var counts: [String: (Int, Int64)] = ["Video": (0, 0), "Image": (0, 0), "Audio": (0, 0)]
        var large: [(URL, Int64, String)] = []
        for r in mediaRoots(root) where exists(r) {
            let cls = Storage.classify(r)
            guard cls.scannable, !Storage.isBoundary(r) else { notTraversable(&o, r, cls); continue }
            var total: Int64 = 0
            let w = Scan.walkFiles(r, maxDepth: 6, deadline: Date().addingTimeInterval(t * 2)) { u, size in
                let e = u.pathExtension.lowercased()
                let kind: String? = videoExt.contains(e) ? "Video" : (imageExt.contains(e) ? "Image" : (audioExt.contains(e) ? "Audio" : nil))
                guard let k = kind else { return }
                counts[k]!.0 += 1; counts[k]!.1 += size; total += size
                if size >= 50_000_000 { large.append((u, size, k)) }
            }
            o.roots.append(RootStatus(path: r.path, storage: cls, status: w.status, bytes: total,
                                      note: w.skipped.isEmpty ? "depth ≤ 6" : "Excluded: " + w.skipped.prefix(4).joined(separator: ", ") + " (PROTECTED/provider)"))
        }
        for k in ["Video", "Image", "Audio"] { o.lines.append("\(k): \(counts[k]!.0) files · \(fmtBytes(counts[k]!.1))") }
        large.sort { $0.1 > $1.1 }
        for l in large.prefix(25) {
            o.candidates.append(Candidate(url: l.0, category: "LARGE MEDIA", bytes: l.1, note: l.2 + " ≥ 50 MB — your call", preselect: false))
        }
        o.lines.append("Large Media: top \(min(25, large.count)) of \(large.count) files ≥ 50 MB listed below (nothing preselected).")
        return o
    }

    static func duplicates(root: URL?) -> ScanOutput {
        var o = ScanOutput(title: "Exact Duplicates")
        let t = Prefs.timeout
        var bySize: [Int64: [URL]] = [:]
        var walkPartial = false
        for r in mediaRoots(root) where exists(r) {
            let cls = Storage.classify(r)
            guard cls.scannable, !Storage.isBoundary(r) else { notTraversable(&o, r, cls); continue }
            let w = Scan.walkFiles(r, maxDepth: 6, deadline: Date().addingTimeInterval(t * 2)) { u, size in
                if size >= 1_000_000 { bySize[size, default: []].append(u) }
            }
            if w.status == .partial { walkPartial = true }
            o.roots.append(RootStatus(path: r.path, storage: cls, status: w.status, bytes: 0, note: "files ≥ 1 MB; depth ≤ 6"))
        }
        let hashDeadline = Date().addingTimeInterval(t * 5)
        var hashPartial = false
        var groups: [(size: Int64, urls: [URL])] = []
        for (size, urls) in bySize where urls.count > 1 {
            var byPartial: [String: [URL]] = [:]
            for u in urls {
                guard let h = Scan.sha256(u, limit: 65_536, deadline: hashDeadline) else { hashPartial = true; continue }
                byPartial[h, default: []].append(u)
            }
            for (_, us) in byPartial where us.count > 1 {
                var byFull: [String: [URL]] = [:]
                for u in us {
                    guard let h = Scan.sha256(u, limit: nil, deadline: hashDeadline) else { hashPartial = true; continue }
                    byFull[h, default: []].append(u)
                }
                for (_, fs) in byFull where fs.count > 1 {
                    groups.append((size, fs.sorted { (mtime($0) ?? .distantFuture) < (mtime($1) ?? .distantFuture) }))
                }
            }
        }
        groups.sort { $0.size * Int64($0.urls.count - 1) > $1.size * Int64($1.urls.count - 1) }
        var wasted: Int64 = 0
        var rows: [InfoSection] = []
        for (gi, g) in groups.enumerated() {
            wasted += g.size * Int64(g.urls.count - 1)
            if gi < 30 {
                rows.append(InfoSection(title: "\(g.urls.count) × \(fmtBytes(g.size)) — \(g.urls[0].lastPathComponent)",
                                        rows: g.urls.enumerated().map { ($0.offset == 0 ? "KEEP (oldest)  " : "duplicate      ") + abbrev($0.element.path) }))
            }
            for u in g.urls.dropFirst() where o.candidates.count < 300 {
                o.candidates.append(Candidate(url: u, category: "EXACT DUPLICATE", bytes: g.size,
                                              note: "same content as \(abbrev(g.urls[0].path))", preselect: false))
            }
        }
        o.sections = rows
        o.lines.append("\(groups.count) duplicate group(s) · \(fmtBytes(wasted)) reclaimable in total [\((walkPartial || hashPartial) ? "PARTIAL — time budget reached" : "COMPLETE")]")
        o.lines.append("Provider roots and Photos libraries are excluded. Method: size → first-64 KB hash → full SHA-256 (CryptoKit). Never auto-deleted.")
        return o
    }

    static func similarNames(root: URL?) -> ScanOutput {
        var o = ScanOutput(title: "Similar Names")
        let r = root ?? path("Downloads")
        let cls = Storage.classify(r)
        guard cls.scannable, !Storage.isBoundary(r) else { notTraversable(&o, r, cls); return o }
        var fam: [String: [URL]] = [:]
        let w = Scan.walkFiles(r, maxDepth: 3, deadline: Date().addingTimeInterval(Prefs.timeout * 2)) { u, _ in
            var stem = u.deletingPathExtension().lastPathComponent
            for pat in [#" \(\d+\)$"#, #" copy( \d+)?$"#] {
                stem = stem.replacingOccurrences(of: pat, with: "", options: .regularExpression)
            }
            fam[Names.family(stem) + "." + u.pathExtension.lowercased(), default: []].append(u)
        }
        o.roots.append(RootStatus(path: r.path, storage: cls, status: w.status, bytes: 0, note: "depth ≤ 3"))
        let multi = fam.filter { $0.value.count > 1 }.sorted { $0.value.count > $1.value.count }
        for (k, v) in multi.prefix(40) {
            o.sections.append(InfoSection(title: "\(k) — \(v.count) similar", rows: v.map { abbrev($0.path) }))
        }
        o.lines.append("\(multi.count) group(s) of similarly named files — likely repeated downloads or versions. Review only; similar names are not proof of duplication.")
        return o
    }

    static func photosFootprint() -> ScanOutput {
        var o = ScanOutput(title: "Photos Library Footprint")
        let t = Prefs.timeout
        let libs = (Scan.listChildren(path("Pictures")) ?? []).filter { $0.pathExtension == "photoslibrary" }
        if libs.isEmpty { o.lines.append("No .photoslibrary found in ~/Pictures (or Pictures is not readable)."); return o }
        for lib in libs {
            guard let kids = Scan.listChildren(lib) else {
                o.roots.append(RootStatus(path: lib.path, storage: .photos, status: .protected, bytes: 0, note: "Not readable — Photos data is protected; grant access in Privacy & Security if you want a footprint"))
                continue
            }
            let total = Scan.size(of: lib, maxDepth: 10, deadline: Date().addingTimeInterval(t * 3), allowPhotos: true)
            o.roots.append(RootStatus(path: lib.path, storage: .photos, status: total.status, bytes: total.bytes, note: "PROTECTED — read-only"))
            var rows: [(Int64, String)] = []
            for k in kids {
                let r = Scan.size(of: k, maxDepth: 10, deadline: Date().addingTimeInterval(t * 2), allowPhotos: true)
                rows.append((r.bytes, "\(fmtBytes(r.bytes))  \(k.lastPathComponent)  [\(r.status.rawValue)]"))
            }
            rows.sort { $0.0 > $1.0 }
            o.sections.append(InfoSection(title: "\(lib.lastPathComponent) — \(fmtBytes(total.bytes))", rows: rows.map { $0.1 }))
        }
        o.lines.append("Footprint on this Mac only. This is not authoritative about iCloud residency (PhotoKit support is DEFERRED). JANITOR never deletes originals or alters the Photos database.")
        return o
    }

    // MARK: FULL CREW

    static func classifyProc(_ p: String, _ cache: inout [String: String]) -> (String, String) {
        let apple = "APPLE/macOS SYSTEM", third = "INSTALLED APPLICATIONS / THIRD PARTY", dev = "USER / DEVELOPMENT", unk = "UNKNOWN / REVIEW"
        let exe = URL(fileURLWithPath: p).lastPathComponent
        for pre in ["/System/", "/usr/libexec", "/usr/sbin", "/usr/bin", "/sbin", "/bin", "/Library/Apple"] where p.hasPrefix(pre) { return (apple, exe) }
        if let r = p.range(of: ".app/") {
            let appPath = String(p[..<r.lowerBound]) + ".app"
            let name = URL(fileURLWithPath: appPath).deletingPathExtension().lastPathComponent
            let bid: String
            if let c = cache[appPath] { bid = c } else { bid = Bundle(path: appPath)?.bundleIdentifier ?? ""; cache[appPath] = bid }
            if bid.hasPrefix("com.apple.") { return (apple, name) }
            if p.hasPrefix("/Applications/") || p.hasPrefix(home.path + "/Applications/") { return (third, name) }
            return (unk, name)
        }
        if p.hasPrefix(home.path) || p.hasPrefix("/opt/homebrew") || p.hasPrefix("/usr/local") { return (dev, exe) }
        return (unk, exe)
    }

    static func processes() -> ScanOutput {
        var o = ScanOutput(title: "Running Processes")
        let r = Shell.run("/bin/ps", ["-axww", "-o", "pid=,pcpu=,rss=,etime=,comm="], timeout: 10)
        guard r.ok else { o.lines = ["REVIEW — could not read the process list"]; return o }
        struct P { var group: String; var name: String; var cpu: Double; var rss: Int64; var etime: String; var path: String; var count: Int }
        var apple = (n: 0, cpu: 0.0, rss: Int64(0))
        var agg: [String: P] = [:]
        var cache: [String: String] = [:]
        for line in r.out.split(separator: "\n") {
            let f = line.split(maxSplits: 4, omittingEmptySubsequences: true, whereSeparator: { $0 == " " || $0 == "\t" })
            guard f.count == 5, let cpu = Double(f[1]), let rss = Int64(f[2]) else { continue }
            let path = String(f[4]).trimmingCharacters(in: .whitespaces)
            let (group, name) = classifyProc(path, &cache)
            if group == "APPLE/macOS SYSTEM" { apple.n += 1; apple.cpu += cpu; apple.rss += rss; continue }
            let key = group + "|" + name
            if var p = agg[key] { p.cpu += cpu; p.rss += rss; p.count += 1; agg[key] = p }
            else { agg[key] = P(group: group, name: name, cpu: cpu, rss: rss, etime: String(f[3]), path: path, count: 1) }
        }
        o.lines.append("Read-only report. Quit/Force Quit and signing/origin attribution are DEFERRED.")
        o.sections.append(InfoSection(title: "APPLE/macOS SYSTEM (collapsed, protected)", rows: [
            "\(apple.n) processes · \(String(format: "%.1f", apple.cpu))% CPU · \(fmtBytes(apple.rss * 1024)) RAM"]))
        for g in ["INSTALLED APPLICATIONS / THIRD PARTY", "USER / DEVELOPMENT", "UNKNOWN / REVIEW"] {
            let items = agg.values.filter { $0.group == g }.sorted { $0.rss > $1.rss }
            let rows = items.prefix(15).map { p in
                "\(p.name)\(p.count > 1 ? " ×\(p.count)" : "") — \(String(format: "%.1f", p.cpu))% CPU · \(fmtBytes(p.rss * 1024)) · up \(p.etime) · \(abbrev(p.path))"
            }
            o.sections.append(InfoSection(title: "\(g) (\(items.count))", rows: rows.isEmpty ? ["none"] : Array(rows)))
        }
        return o
    }

    static func startup() -> ScanOutput {
        var o = ScanOutput(title: "Startup & Background Items")
        let dirs: [(URL, String)] = [(path("Library/LaunchAgents"), "user login agent"),
                                     (URL(fileURLWithPath: "/Library/LaunchAgents"), "all-user agent"),
                                     (URL(fileURLWithPath: "/Library/LaunchDaemons"), "system daemon")]
        var groups: [String: [String]] = [:]
        var apple = 0
        for (d, kind) in dirs {
            guard let files = Scan.listChildren(d) else { continue }
            for f in files where f.pathExtension == "plist" {
                guard let dict = NSDictionary(contentsOf: f) as? [String: Any] else { continue }
                let label = dict["Label"] as? String ?? f.deletingPathExtension().lastPathComponent
                if label.hasPrefix("com.apple.") { apple += 1; continue }
                let prog = dict["Program"] as? String ?? (dict["ProgramArguments"] as? [String])?.first ?? ""
                let missing = !prog.isEmpty && !Quarantine.present(prog)
                let group: String
                if missing { group = "Unknown / review (program missing)" }
                else if prog.contains(".app/") || prog.hasPrefix("/Applications/") { group = "Installed-app helpers" }
                else if prog.hasPrefix(home.path) || prog.hasPrefix("/opt/homebrew") || prog.hasPrefix("/usr/local") || label.hasPrefix("homebrew.") { group = "Developer / local services" }
                else { group = "Unknown / review" }
                groups[group, default: []].append("\(label) — \(kind) — \(prog.isEmpty ? "no program" : abbrev(prog))\(missing ? " — target not found (not proof of orphan)" : "")")
            }
        }
        o.lines.append("Inventory of launchd plists. Modern Login Items / Background Task Management (SMAppService) are not enumerated — DEFERRED.")
        o.sections.append(InfoSection(title: "Apple / macOS (collapsed)", rows: ["\(apple) item(s)"]))
        for g in ["Installed-app helpers", "Developer / local services", "Unknown / review", "Unknown / review (program missing)"] {
            let rows = (groups[g] ?? []).sorted()
            o.sections.append(InfoSection(title: "\(g) (\(rows.count))", rows: rows.isEmpty ? ["none"] : rows))
        }
        return o
    }

    struct App { let name: String; let bid: String; let version: String; let path: String }

    static func installedApps() -> [App] {
        var apps: [App] = []
        func scan(_ dir: URL, depth: Int) {
            guard let kids = Scan.listChildren(dir) else { return }
            for k in kids {
                if k.pathExtension == "app" {
                    let info = Bundle(url: k)?.infoDictionary ?? [:]
                    let name = (info["CFBundleDisplayName"] as? String) ?? (info["CFBundleName"] as? String) ?? k.deletingPathExtension().lastPathComponent
                    apps.append(App(name: name, bid: info["CFBundleIdentifier"] as? String ?? "?",
                                    version: info["CFBundleShortVersionString"] as? String ?? "?", path: k.path))
                } else if depth > 0, (try? k.resourceValues(forKeys: [.isDirectoryKey]))?.isDirectory == true {
                    scan(k, depth: depth - 1)
                }
            }
        }
        scan(URL(fileURLWithPath: "/Applications"), depth: 1)
        scan(path("Applications"), depth: 1)
        return apps.sorted { $0.name.lowercased() < $1.name.lowercased() }
    }

    static func appsInventory() -> ScanOutput {
        var o = ScanOutput(title: "Installed Apps")
        let apps = installedApps()
        o.lines.append("\(apps.count) application(s) in /Applications and ~/Applications")
        o.sections.append(InfoSection(title: "Applications", rows: apps.prefix(300).map { "\($0.name) — \($0.version) — \($0.bid)" }))
        return o
    }

    static func supportInventory() -> ScanOutput {
        var o = ScanOutput(title: "Support Inventory")
        let apps = installedApps()
        var known = Set<String>()
        for a in apps {
            known.insert(a.name.lowercased()); known.insert(a.bid.lowercased())
            if let last = a.bid.split(separator: ".").last { known.insert(String(last).lowercased()) }
        }
        let dir = path("Library/Application Support")
        let r = Scan.candidates(in: dir, category: "SUPPORT", budget: Prefs.timeout * 2, minBytes: 1_000_000, limit: 40) { _ in ("", false) }
        o.roots.append(r.root)
        o.sections.append(InfoSection(title: "~/Library/Application Support — largest 40", rows: r.cands.map { c in
            let key = c.url.lastPathComponent.lowercased()
            let match = known.contains(key) || known.contains(where: { key.contains($0) && $0.count > 4 })
            return "\(fmtBytes(c.bytes))  \(c.url.lastPathComponent)  —  \(match ? "matches an installed app" : "no installed app matched — REVIEW (not a remnant claim)")"
        }))
        o.lines.append("Support locations only. “Remnant” is never claimed without ownership evidence — robust attribution is DEFERRED.")
        return o
    }

    static func broken(root: URL) -> ScanOutput {
        var o = ScanOutput(title: "Broken Items")
        let cls = Storage.classify(root)
        guard cls.scannable, !Storage.isBoundary(root) else { notTraversable(&o, root, cls); return o }
        let fm = FileManager.default
        let maxDepth = Prefs.maxDepth
        let dl = Date().addingTimeInterval(Prefs.timeout * 3)
        var partial = false
        var inaccessible = 0
        let skipNames: Set<String> = ["Library", ".Trash", "node_modules", ".git", ".build"]
        if let en = fm.enumerator(at: root, includingPropertiesForKeys: [.isDirectoryKey, .isSymbolicLinkKey], options: [], errorHandler: { _, _ in true }) {
            var n = 0
            while let obj = en.nextObject() {
                guard let url = obj as? URL else { continue }
                n += 1
                if n % 128 == 0, Date() > dl || Task.isCancelled { partial = true; break }
                let rv = try? url.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
                if rv?.isSymbolicLink == true {
                    guard let dest = try? fm.destinationOfSymbolicLink(atPath: url.path) else { inaccessible += 1; continue }
                    let target = dest.hasPrefix("/") ? URL(fileURLWithPath: dest) : url.deletingLastPathComponent().appendingPathComponent(dest)
                    let resolved = target.standardized
                    if Storage.isBoundary(resolved) || Storage.classify(resolved.deletingLastPathComponent()) == .fileProvider { continue }
                    if fm.fileExists(atPath: resolved.path) { continue }
                    let parent = resolved.deletingLastPathComponent().path
                    if fm.fileExists(atPath: parent), !fm.isReadableFile(atPath: parent) { inaccessible += 1; continue }
                    o.candidates.append(Candidate(url: url, category: "BROKEN LINK", bytes: 0, note: "target missing: \(dest)", preselect: false))
                } else if rv?.isDirectory == true {
                    if skipNames.contains(url.lastPathComponent) || Storage.isBoundary(url) { en.skipDescendants(); continue }
                    if en.level >= maxDepth { en.skipDescendants() }
                }
            }
        }
        o.roots.append(RootStatus(path: root.path, storage: cls, status: partial ? .partial : .complete, bytes: 0,
                                  note: "depth ≤ \(maxDepth); ~/Library skipped; inaccessible ≠ broken (\(inaccessible) not judged)"))
        o.lines.append("\(o.candidates.count) broken symlink(s) in \(abbrev(root.path)) [\(partial ? "PARTIAL" : "COMPLETE")]. Items we could not read were not judged.")
        return o
    }

    static func storageGrowth() -> ScanOutput {
        var o = ScanOutput(title: "Storage Diagnostics")
        o.lines.append(volumeLine())
        let t = Prefs.timeout
        let global = Date().addingTimeInterval(t * 8)
        let areas: [(String, String)] = [
            ("Library/Developer", "Developer (Xcode, simulators)"), ("Library/Developer/CoreSimulator", "Simulators"),
            ("Library/Developer/Xcode/DerivedData", "DerivedData"), ("Library/Developer/Xcode/Archives", "Xcode Archives"),
            ("Library/Developer/Xcode/iOS DeviceSupport", "Device support"), ("Library/Caches", "Caches"),
            ("Library/Application Support", "Application Support"), ("Library/Logs", "Logs"), ("Library/Containers", "App containers"),
            ("Downloads", "Downloads"), ("Movies", "Movies"), ("Music", "Music"), ("Pictures", "Pictures"),
            (".Trash", "Trash"), (".npm", "npm cache"), (".gradle", "Gradle"), (".cargo", "Cargo")
        ]
        var rows: [(Int64, String)] = []
        var notes: [String] = []
        for (rel, label) in areas {
            let u = path(rel)
            guard exists(u) else { continue }
            let cls = Storage.classify(u)
            if !cls.scannable { notes.append("\(label): \(cls.rawValue) — not traversed"); continue }
            if Date() > global || Task.isCancelled { notes.append("\(label): SKIPPED — global time budget reached"); continue }
            let r = Scan.size(of: u, deadline: Date().addingTimeInterval(t))
            rows.append((r.bytes, "\(fmtBytes(r.bytes))  \(label)  [\(r.status.rawValue)]"))
        }
        rows.sort { $0.0 > $1.0 }
        o.sections.append(InfoSection(title: "Growth areas, largest first", rows: rows.map { $0.1 }))
        if !notes.isEmpty { o.sections.append(InfoSection(title: "Not measured", rows: notes)) }
        if let tm = Shell.which("tmutil") {
            let r = Shell.run(tm, ["listlocalsnapshots", "/"], timeout: 10)
            let snaps = r.out.split(separator: "\n").filter { $0.contains("com.apple") }.map(String.init)
            o.sections.append(InfoSection(title: "Local APFS snapshots (\(snaps.count)) — via tmutil, read-only", rows: snaps.isEmpty ? ["none reported"] : snaps))
        }
        return o
    }

    // MARK: SETTINGS / DIAGNOSTICS

    static func diagnostics() -> ScanOutput {
        var o = ScanOutput(title: "Diagnostics")
        #if arch(arm64)
        let arch = "arm64 (Apple silicon)"
        #else
        let arch = "x86_64 (Intel)"
        #endif
        o.lines = ["JANITOR \(janitorVersion)", "macOS \(ProcessInfo.processInfo.operatingSystemVersionString) · \(arch)",
                   "Reports: \(abbrev(Report.dir.path))", "iCloud Drive present: \(Storage.iCloudActive ? "yes — Desktop/Documents treated as provider-managed" : "no")"]
        o.sections.append(InfoSection(title: "Tools (optional ones are never installed for you)", rows:
            ["brew", "git", "xcrun", "tmutil", "diskutil", "ps", "launchctl", "fdupes"].map { n in
                "\(n): \(Shell.which(n).map { abbrev($0) } ?? "not found (optional)")" }))
        let fm = FileManager.default
        func access(_ rel: String) -> String {
            let u = path(rel)
            guard exists(u) else { return "\(rel): not present" }
            return "\(rel): \((try? fm.contentsOfDirectory(atPath: u.path)) != nil ? "readable" : "needs permission (Privacy & Security)")"
        }
        o.sections.append(InfoSection(title: "Access", rows: [access(".Trash"), access("Library/Containers"), access("Downloads"), access("Pictures")]))
        let q = Prefs.quarantineRoot
        let qExists = exists(q)
        var qRows = ["Root: \(abbrev(q.path))", "Exists: \(qExists ? "yes" : "not yet (created on first quarantine)")"]
        if qExists {
            qRows.append("Class: \(Storage.classify(q).rawValue)")
            qRows.append("Writable: \(fm.isWritableFile(atPath: q.path) ? "yes" : "NO")")
            let ops = Quarantine.loadOps()
            qRows.append("Operations: \(ops.count) · items MOVED \(ops.flatMap { $0.manifest.items }.filter { $0.state == "MOVED" }.count) / MISSING \(ops.flatMap { $0.manifest.items }.filter { $0.state == "MISSING" }.count)")
        }
        o.sections.append(InfoSection(title: "Quarantine health", rows: qRows))
        return o
    }
}

// MARK: - Maintenance actions (native tools only)

enum Maint {
    static func free() -> Int64 {
        (try? URL(fileURLWithPath: "/").resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey]))?
            .volumeAvailableCapacityForImportantUsage ?? 0
    }
    static func tail(_ s: String, _ n: Int) -> [String] {
        s.split(separator: "\n", omittingEmptySubsequences: true).suffix(n).map(String.init)
    }

    static func brew(dryRun: Bool) -> ScanOutput {
        var o = ScanOutput(title: dryRun ? "Homebrew cleanup preview" : "Homebrew cleanup")
        guard let b = Shell.which("brew") else { o.lines = ["Homebrew is not installed (optional). Nothing to do."]; return o }
        let before = free()
        let r = Shell.run(b, dryRun ? ["cleanup", "-n"] : ["cleanup"], timeout: dryRun ? 60 : 300)
        o.lines = [r.timedOut ? "PARTIAL — timed out" : (r.ok ? "COMPLETE" : "REVIEW — brew reported an error"),
                   dryRun ? "Dry run — nothing was removed." : "Reclaimed (approximate free-space delta): \(fmtBytes(max(0, free() - before)))"]
        o.sections = [InfoSection(title: "brew output (last lines)", rows: tail(r.out, 40))]
        return o
    }

    static func simulators(dryRun: Bool) -> ScanOutput {
        var o = ScanOutput(title: dryRun ? "Unavailable simulators preview" : "Remove unavailable simulators")
        guard let x = Shell.which("xcrun") else { o.lines = ["xcrun not found."]; return o }
        let before = free()
        let r = Shell.run(x, dryRun ? ["simctl", "list", "devices", "unavailable"] : ["simctl", "delete", "unavailable"], timeout: 120)
        o.lines = [r.timedOut ? "PARTIAL — timed out" : (r.ok ? "COMPLETE" : "REVIEW — simctl reported an error"),
                   dryRun ? "Listing only — nothing was removed." : "Reclaimed (approximate free-space delta): \(fmtBytes(max(0, free() - before)))"]
        o.sections = [InfoSection(title: "simctl output (last lines)", rows: tail(r.out, 40))]
        return o
    }
}
JANITOR_EOF

cat > "$SRC/Model.swift" <<'JANITOR_EOF'
import SwiftUI
import AppKit

@MainActor
final class Model: ObservableObject {
    enum Mode: String, CaseIterable, Identifiable, Hashable {
        case standard = "1  STANDARD"
        case developer = "2  DEVELOPER"
        case media = "3  MEDIA"
        case crew = "4  FULL CREW"
        case quarantine = "5  QUARANTINE / RECOVERY"
        case settings = "6  SETTINGS / DIAGNOSTICS"
        var id: String { rawValue }
    }

    @Published var mode: Mode = .standard { didSet { if oldValue != mode { resetOutput() } } }
    @Published var busy = false
    @Published var busyTitle = ""
    @Published var out: ScanOutput?
    @Published var selection = Set<UUID>()
    @Published var results: [ActionResult] = []
    @Published var message = ""
    @Published var ops: [QOp] = []
    @Published var openOp: String?
    @Published var opSelection = Set<String>()
    @Published var workRoot: URL? = nil { didSet { UserDefaults.standard.set(workRoot?.path ?? "", forKey: "workRoot") } }

    private var task: Task<Void, Never>?

    init() {
        if let s = UserDefaults.standard.string(forKey: "workRoot"), !s.isEmpty {
            workRoot = URL(fileURLWithPath: s, isDirectory: true)
        }
    }

    var devRoot: URL { workRoot ?? Modes.defaultDevRoot() }

    func resetOutput() { out = nil; results = []; selection = []; message = "" }

    // MARK: scans

    func run(_ title: String, work: @escaping @Sendable () -> ScanOutput) {
        guard !busy else { return }
        busy = true; busyTitle = title + "…"
        results = []; message = ""; selection = []
        task = Task.detached(priority: .userInitiated) { [weak self] in
            let o = work()
            let cancelled = Task.isCancelled
            await self?.finish(o, cancelled: cancelled)
        }
    }

    private func finish(_ o: ScanOutput, cancelled: Bool) {
        var o2 = o
        if cancelled { o2.lines.insert("Cancelled — results are PARTIAL", at: 0) }
        busy = false
        out = o2
        selection = Set(o2.candidates.filter { $0.preselect }.map { $0.id })
        Report.write(o2.title, lines: Report.scanLines(o2))
    }

    func cancel() { task?.cancel() }

    func chooseAndScan() {
        let p = NSOpenPanel()
        p.canChooseDirectories = true; p.canChooseFiles = false; p.allowsMultipleSelection = false
        p.message = "Choose a local folder to inspect"; p.prompt = "Inspect"
        if p.runModal() == .OK, let u = p.url { run("Scanning \(u.lastPathComponent)") { Modes.chosen(u) } }
    }

    func chooseWorkRoot() {
        let p = NSOpenPanel()
        p.canChooseDirectories = true; p.canChooseFiles = false; p.allowsMultipleSelection = false
        p.message = "Choose the folder to analyse"; p.prompt = "Choose"
        if p.runModal() == .OK, let u = p.url { workRoot = u }
    }

    func chooseQuarantineRoot() {
        let p = NSOpenPanel()
        p.canChooseDirectories = true; p.canChooseFiles = false; p.canCreateDirectories = true; p.allowsMultipleSelection = false
        p.message = "Choose a LOCAL folder for quarantine (not iCloud / cloud-provider storage)"; p.prompt = "Use"
        if p.runModal() == .OK, let u = p.url { UserDefaults.standard.set(u.path, forKey: "quarantineRoot") }
    }

    // MARK: actions on candidates

    func selected() -> [Candidate] { (out?.candidates ?? []).filter { selection.contains($0.id) } }

    func quarantineSelected() {
        let items = selected()
        guard !items.isEmpty, !busy else { return }
        let label = (out?.title ?? "Cleanup").replacingOccurrences(of: " ", with: "-").replacingOccurrences(of: "/", with: "-")
        busy = true; busyTitle = "Moving \(items.count) item(s) to quarantine…"
        Task.detached(priority: .userInitiated) { [weak self] in
            let r = Quarantine.move(items, label: label)
            await self?.finishAction("Quarantine", r.results, reclaimed: 0)
        }
    }

    func deleteSelected() {
        let items = selected()
        guard !items.isEmpty, !busy else { return }
        busy = true; busyTitle = "Deleting \(items.count) item(s)…"
        Task.detached(priority: .userInitiated) { [weak self] in
            let r = Quarantine.deleteCandidates(items)
            await self?.finishAction("Delete", r.results, reclaimed: r.reclaimed)
        }
    }

    private func finishAction(_ title: String, _ res: [ActionResult], reclaimed: Int64) {
        busy = false
        results = res
        let handled = Set(res.filter { ["MOVED", "DELETED", "MISSING"].contains($0.state) }.compactMap { $0.cid })
        out?.candidates.removeAll { handled.contains($0.id) }
        selection.subtract(handled)
        let counts = Dictionary(grouping: res, by: { $0.state }).mapValues { $0.count }
        var msg = counts.sorted { $0.key < $1.key }.map { "\($0.value) \($0.key)" }.joined(separator: " · ")
        if reclaimed > 0 { msg += " · reclaimed \(fmtBytes(reclaimed)) (verified gone)" }
        if (counts["MOVED"] ?? 0) > 0 { msg += " · space is freed when the quarantine is deleted" }
        message = msg
        var lines = ["Summary: \(msg)", ""]
        lines += res.map { "[\($0.state)] \($0.name) — \($0.detail)" }
        Report.write(title, lines: lines)
        refreshOps()
    }

    // MARK: quarantine manager

    func refreshOps() {
        Task.detached { [weak self] in
            let o = Quarantine.loadOps()
            await self?.setOps(o)
        }
    }

    private func setOps(_ o: [QOp]) { ops = o }

    func restore(_ op: QOp, ids: Set<String>?) {
        guard !busy else { return }
        busy = true; busyTitle = "Restoring…"
        Task.detached { [weak self] in
            let r = Quarantine.restore(op, ids: ids)
            await self?.finishRestore(r)
        }
    }

    private func finishRestore(_ r: [ActionResult]) {
        busy = false
        results = r
        message = Dictionary(grouping: r, by: { $0.state }).map { "\($0.value.count) \($0.key)" }.sorted().joined(separator: " · ")
        opSelection = []
        Report.write("Restore", lines: r.map { "[\($0.state)] \($0.name) — \($0.detail)" })
        refreshOps()
    }

    func deleteOps(_ list: [QOp]) {
        guard !busy, !list.isEmpty else { return }
        busy = true; busyTitle = "Deleting quarantine…"
        Task.detached { [weak self] in
            var res: [ActionResult] = []
            var bytes: Int64 = 0
            for op in list { let d = Quarantine.delete(op); res.append(d.0); bytes += d.1 }
            await self?.finishAction("Quarantine delete", res, reclaimed: bytes)
        }
    }

    func oldOps(days: Int) -> [QOp] {
        let cutoff = Date().addingTimeInterval(-Double(days) * 86400)
        return ops.filter { (ISO8601DateFormatter().date(from: $0.manifest.created) ?? .distantFuture) < cutoff }
    }
}
JANITOR_EOF

cat > "$SRC/Views.swift" <<'JANITOR_EOF'
import SwiftUI
import AppKit

func statusColor(_ s: ScanStatus) -> Color {
    switch s {
    case .complete: return .green
    case .partial: return .orange
    case .review: return .yellow
    case .skipped: return .gray
    case .protected: return .red
    case .deferred: return .blue
    }
}

func stateColor(_ s: String) -> Color {
    switch s {
    case "MOVED", "DELETED", "RESTORED": return .green
    case "FAILED": return .red
    case "MISSING": return .orange
    default: return .gray
    }
}

struct Pill: View {
    let text: String
    let color: Color
    var body: some View {
        Text(text).font(.caption2.bold())
            .padding(.horizontal, 6).padding(.vertical, 2)
            .background(color.opacity(0.22), in: Capsule())
            .foregroundStyle(color)
    }
}

struct Btn: View {
    let title: String
    let icon: String
    let action: () -> Void
    init(_ title: String, _ icon: String, _ action: @escaping () -> Void) { self.title = title; self.icon = icon; self.action = action }
    var body: some View {
        Button(action: action) { Label(title, systemImage: icon).frame(maxWidth: .infinity, alignment: .leading) }
            .buttonStyle(.bordered)
    }
}

struct RootBar: View {
    @EnvironmentObject var m: Model
    let hint: String
    var body: some View {
        HStack {
            Image(systemName: "scope")
            Text("Root: \(m.workRoot.map { Modes.abbrev($0.path) } ?? hint)").font(.callout)
            Button("Choose…") { m.chooseWorkRoot() }
            if m.workRoot != nil { Button("Reset") { m.workRoot = nil } }
            Spacer()
        }
    }
}

struct Scaffold<Buttons: View>: View {
    @EnvironmentObject var m: Model
    let title: String
    let subtitle: String
    let rootHint: String?
    let buttons: Buttons

    init(title: String, subtitle: String, rootHint: String? = nil, @ViewBuilder buttons: () -> Buttons) {
        self.title = title; self.subtitle = subtitle; self.rootHint = rootHint; self.buttons = buttons()
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(title).font(.title2.bold())
            Text(subtitle).font(.callout).foregroundStyle(.secondary)
            if let h = rootHint { RootBar(hint: h) }
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 200), spacing: 8)], alignment: .leading, spacing: 8) { buttons }
                .disabled(m.busy)
            Divider()
            ResultsView()
        }
        .padding([.top, .horizontal])
    }
}

struct RootView: View {
    @EnvironmentObject var m: Model
    var body: some View {
        NavigationSplitView {
            List(Model.Mode.allCases, selection: Binding<Model.Mode?>(get: { m.mode }, set: { if let v = $0 { m.mode = v } })) { mode in
                Text(mode.rawValue).tag(mode)
            }
            .navigationSplitViewColumnWidth(min: 240, ideal: 260)
            .safeAreaInset(edge: .bottom) {
                Button("0  EXIT") { NSApp.terminate(nil) }.buttonStyle(.borderless).padding()
            }
        } detail: {
            ModeView()
        }
    }
}

struct ModeView: View {
    @EnvironmentObject var m: Model
    var body: some View {
        switch m.mode {
        case .standard: StandardView()
        case .developer: DeveloperView()
        case .media: MediaView()
        case .crew: CrewView()
        case .quarantine: QuarantineView()
        case .settings: SettingsView()
        }
    }
}

// MARK: - Results

struct ResultsView: View {
    @EnvironmentObject var m: Model
    @State private var confirmQ = false
    @State private var confirmD = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 12) {
                if m.busy {
                    HStack { ProgressView().controlSize(.small); Text(m.busyTitle); Button("Cancel") { m.cancel() } }
                }
                if let o = m.out { content(o) }
                if !m.message.isEmpty { Text(m.message).font(.headline) }
                if !m.results.isEmpty { ActionResultsView(results: m.results) }
            }
            .padding(.vertical)
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    @ViewBuilder
    func content(_ o: ScanOutput) -> some View {
        Text(o.title).font(.headline)
        ForEach(Array(o.lines.enumerated()), id: \.offset) { _, l in Text(l).font(.callout) }

        if !o.roots.isEmpty {
            DisclosureGroup("Roots (\(o.roots.count))") {
                VStack(alignment: .leading, spacing: 4) {
                    ForEach(o.roots) { r in
                        HStack(alignment: .firstTextBaseline) {
                            Pill(text: r.status.rawValue, color: statusColor(r.status))
                            Text("\(r.storage.rawValue) · \(Modes.abbrev(r.path)) · \(fmtBytes(r.bytes))\(r.note.isEmpty ? "" : " · " + r.note)")
                                .font(.caption)
                        }
                    }
                }.padding(.vertical, 4)
            }
        }

        ForEach(o.sections) { s in
            DisclosureGroup("\(s.title) (\(s.rows.count))") {
                VStack(alignment: .leading, spacing: 3) {
                    ForEach(Array(s.rows.enumerated()), id: \.offset) { _, r in
                        Text(r).font(.caption.monospaced()).textSelection(.enabled)
                    }
                }.padding(.vertical, 4)
            }
        }

        if !o.candidates.isEmpty { candidateList(o) }
    }

    @ViewBuilder
    func candidateList(_ o: ScanOutput) -> some View {
        let sel = m.selected()
        let bytes = sel.reduce(Int64(0)) { $0 + $1.bytes }
        Divider()
        HStack {
            Text("Review (\(o.candidates.count))").font(.headline)
            Spacer()
            Button("Select all") { m.selection = Set(o.candidates.map { $0.id }) }
            Button("None") { m.selection = [] }
            Button("Safe only") { m.selection = Set(o.candidates.filter { $0.preselect }.map { $0.id }) }
        }
        ForEach(o.candidates) { c in
            HStack(alignment: .top) {
                Toggle("", isOn: Binding(get: { m.selection.contains(c.id) },
                                         set: { on in if on { m.selection.insert(c.id) } else { m.selection.remove(c.id) } }))
                    .labelsHidden()
                VStack(alignment: .leading, spacing: 2) {
                    HStack {
                        Text(c.title).bold().lineLimit(1)
                        Pill(text: c.category, color: c.preselect ? .green : .orange)
                        Spacer()
                        Text(c.bytes > 0 ? fmtBytes(c.bytes) : "—").monospacedDigit()
                    }
                    Text("\(Modes.abbrev(c.url.path))\(c.note.isEmpty ? "" : " — " + c.note)")
                        .font(.caption).foregroundStyle(.secondary).lineLimit(2).textSelection(.enabled)
                }
            }
        }
        HStack {
            Text("\(sel.count) selected · \(fmtBytes(bytes))").font(.callout)
            Spacer()
            Button("Quarantine selected…") { confirmQ = true }.disabled(sel.isEmpty || m.busy)
            Button("Delete selected…", role: .destructive) { confirmD = true }.disabled(sel.isEmpty || m.busy)
        }
        .confirmationDialog("Move \(sel.count) item(s) (\(fmtBytes(bytes))) to quarantine?", isPresented: $confirmQ, titleVisibility: .visible) {
            Button("Quarantine") { m.quarantineSelected() }
            Button("Cancel", role: .cancel) {}
        } message: { Text("Items stay recoverable under QUARANTINE / RECOVERY. Each move is verified.") }
        .confirmationDialog("Permanently delete \(sel.count) item(s) (\(fmtBytes(bytes)))?", isPresented: $confirmD, titleVisibility: .visible) {
            Button("Delete permanently", role: .destructive) { m.deleteSelected() }
            Button("Cancel", role: .cancel) {}
        } message: { Text("This cannot be undone. Choose Quarantine instead if you may want these back.") }
    }
}

struct ActionResultsView: View {
    let results: [ActionResult]
    var body: some View {
        DisclosureGroup("Result per item (\(results.count))", isExpanded: .constant(true)) {
            VStack(alignment: .leading, spacing: 3) {
                ForEach(results) { r in
                    HStack(alignment: .firstTextBaseline) {
                        Pill(text: r.state, color: stateColor(r.state))
                        Text("\(r.name) — \(r.detail)").font(.caption).textSelection(.enabled)
                    }
                }
            }.padding(.vertical, 4)
        }
    }
}

// MARK: - Modes

struct StandardView: View {
    @EnvironmentObject var m: Model
    @State private var confirmBrew = false
    @State private var confirmSim = false
    @State private var confirmOld = false

    var body: some View {
        Scaffold(title: "STANDARD", subtitle: "Quick Scan is shallow and time-boxed — it never crawls your home folder. Nothing changes without review and confirmation.") {
            Btn("Quick Scan", "bolt") { m.run("Quick Scan") { Modes.quick(full: false) } }
            Btn("Full Scan", "magnifyingglass") { m.run("Full Scan") { Modes.quick(full: true) } }
            Btn("Storage Overview", "internaldrive") { m.run("Storage Overview") { Modes.overview() } }
            Btn("Choose What to Scan…", "folder") { m.chooseAndScan() }
            Btn("Preview Homebrew cleanup", "eye") { m.run("Homebrew preview") { Maint.brew(dryRun: true) } }
            Btn("Run Homebrew cleanup…", "shippingbox") { confirmBrew = true }
            Btn("Preview unavailable simulators", "eye") { m.run("Simulator preview") { Maint.simulators(dryRun: true) } }
            Btn("Remove unavailable simulators…", "iphone") { confirmSim = true }
            Btn("Delete quarantine > 30 days…", "clock.arrow.circlepath") { m.refreshOps(); confirmOld = true }
        }
        .confirmationDialog("Run `brew cleanup`?", isPresented: $confirmBrew, titleVisibility: .visible) {
            Button("Run cleanup") { m.run("Homebrew cleanup") { Maint.brew(dryRun: false) } }
            Button("Cancel", role: .cancel) {}
        } message: { Text("Uses Homebrew's own cleanup. Preview first to see what it will remove.") }
        .confirmationDialog("Remove unavailable simulators?", isPresented: $confirmSim, titleVisibility: .visible) {
            Button("Run simctl delete unavailable") { m.run("Remove simulators") { Maint.simulators(dryRun: false) } }
            Button("Cancel", role: .cancel) {}
        } message: { Text("Uses Apple's simctl. Only simulators Xcode already marks unavailable are removed.") }
        .confirmationDialog("Delete \(m.oldOps(days: 30).count) quarantine operation(s) older than 30 days?", isPresented: $confirmOld, titleVisibility: .visible) {
            Button("Delete permanently", role: .destructive) { m.deleteOps(m.oldOps(days: 30)) }
            Button("Cancel", role: .cancel) {}
        } message: { Text("Their items can no longer be restored.") }
    }
}

struct DeveloperView: View {
    @EnvironmentObject var m: Model
    var body: some View {
        Scaffold(title: "DEVELOPER", subtitle: "Targeted known caches, project/version discovery and build families. Git working copies and active builds are excluded.",
                 rootHint: "auto (\(Modes.abbrev(Modes.defaultDevRoot().path)))") {
            Btn("Developer Quick", "hammer") { m.run("Developer Quick") { Modes.devQuick() } }
            Btn("Project Identity / Versions", "square.stack.3d.up") { let r = m.devRoot; m.run("Project discovery") { Modes.projects(root: r) } }
            Btn("Build Families", "list.number") { let r = m.devRoot; m.run("Build families") { Modes.buildFamilies(root: r) } }
            Btn("Build / Dependency Discovery", "shippingbox") { let r = m.devRoot; m.run("Dependency discovery") { Modes.dependencies(root: r) } }
        }
    }
}

struct MediaView: View {
    @EnvironmentObject var m: Model
    var body: some View {
        Scaffold(title: "MEDIA", subtitle: "Local media only. Cloud-provider roots and Photos libraries are never crawled or hashed; nothing is auto-deleted.",
                 rootHint: "Movies, Music, Pictures, Downloads") {
            Btn("Inventory + Large Media", "film") { let r = m.workRoot; m.run("Media inventory") { Modes.media(root: r) } }
            Btn("Exact Duplicates", "doc.on.doc") { let r = m.workRoot; m.run("Exact duplicates") { Modes.duplicates(root: r) } }
            Btn("Similar Names", "textformat") { let r = m.workRoot; m.run("Similar names") { Modes.similarNames(root: r) } }
            Btn("Photos Library Footprint", "photo.on.rectangle") { m.run("Photos footprint") { Modes.photosFootprint() } }
        }
    }
}

struct CrewView: View {
    @EnvironmentObject var m: Model
    var body: some View {
        Scaffold(title: "FULL CREW", subtitle: "Advanced diagnostics, grouped and read-only. Inaccessible is never reported as broken; “remnant” is never claimed without evidence.",
                 rootHint: "home folder (Broken Items)") {
            Btn("Running Processes", "cpu") { m.run("Processes") { Modes.processes() } }
            Btn("Startup / Background Items", "power") { m.run("Startup items") { Modes.startup() } }
            Btn("Installed Apps", "square.grid.2x2") { m.run("Installed apps") { Modes.appsInventory() } }
            Btn("Support Inventory", "tray.full") { m.run("Support inventory") { Modes.supportInventory() } }
            Btn("Broken Items", "link.badge.plus") { let r = m.workRoot ?? Storage.home; m.run("Broken items") { Modes.broken(root: r) } }
            Btn("Storage Diagnostics + Snapshots", "chart.bar") { m.run("Storage diagnostics") { Modes.storageGrowth() } }
        }
    }
}

struct QuarantineView: View {
    @EnvironmentObject var m: Model
    @State private var deleteTarget: QOp?

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("QUARANTINE / RECOVERY").font(.title2.bold())
                Spacer()
                Button("Refresh") { m.refreshOps() }
                Button("Reveal root") { reveal(Prefs.quarantineRoot) }
            }
            Text("Root: \(Modes.abbrev(Prefs.quarantineRoot.path)) — items removed by hand are marked MISSING and never block the manager.")
                .font(.callout).foregroundStyle(.secondary)
            if m.busy { HStack { ProgressView().controlSize(.small); Text(m.busyTitle) } }
            if m.ops.isEmpty { Text("No quarantine operations yet.").foregroundStyle(.secondary) }
            ScrollView {
                VStack(alignment: .leading, spacing: 8) {
                    ForEach(m.ops) { op in opView(op) }
                    if !m.message.isEmpty { Text(m.message).font(.headline) }
                    if !m.results.isEmpty { ActionResultsView(results: m.results) }
                }
            }
        }
        .padding()
        .onAppear { m.refreshOps() }
        .confirmationDialog("Delete this quarantine operation permanently?", isPresented: Binding(get: { deleteTarget != nil }, set: { if !$0 { deleteTarget = nil } }), titleVisibility: .visible) {
            Button("Delete permanently", role: .destructive) { if let t = deleteTarget { m.deleteOps([t]) }; deleteTarget = nil }
            Button("Cancel", role: .cancel) { deleteTarget = nil }
        } message: { Text("Items still inside can no longer be restored.") }
    }

    func reveal(_ u: URL) {
        if Quarantine.present(u.path) { NSWorkspace.shared.activateFileViewerSelecting([u]) }
        else { NSWorkspace.shared.activateFileViewerSelecting([u.deletingLastPathComponent()]) }
    }

    @ViewBuilder
    func opView(_ op: QOp) -> some View {
        let moved = op.manifest.items.filter { $0.state == "MOVED" }
        let missing = op.manifest.items.filter { $0.state == "MISSING" }.count
        DisclosureGroup(isExpanded: Binding(get: { m.openOp == op.id }, set: { m.openOp = $0 ? op.id : nil })) {
            VStack(alignment: .leading, spacing: 4) {
                ForEach(op.manifest.items) { it in
                    HStack(alignment: .top) {
                        Toggle("", isOn: Binding(get: { m.opSelection.contains(it.id) },
                                                 set: { on in if on { m.opSelection.insert(it.id) } else { m.opSelection.remove(it.id) } }))
                            .labelsHidden().disabled(it.state != "MOVED")
                        Pill(text: it.state, color: stateColor(it.state))
                        VStack(alignment: .leading, spacing: 1) {
                            Text(URL(fileURLWithPath: it.original).lastPathComponent).bold()
                            Text("\(Modes.abbrev(it.original)) · \(it.reason) · \(fmtBytes(it.bytes))").font(.caption).foregroundStyle(.secondary).textSelection(.enabled)
                        }
                    }
                }
                HStack {
                    Button("Restore selected") { m.restore(op, ids: m.opSelection) }
                        .disabled(m.opSelection.isEmpty || m.busy)
                    Button("Restore all") { m.restore(op, ids: nil) }.disabled(moved.isEmpty || m.busy)
                    Button("Reveal") { reveal(op.folder) }
                    Button("Delete operation…", role: .destructive) { deleteTarget = op }.disabled(m.busy)
                }
            }.padding(.vertical, 4)
        } label: {
            Text("\(op.id) — \(op.manifest.items.count) item(s), \(moved.count) in quarantine\(missing > 0 ? ", \(missing) MISSING" : "") · \(fmtBytes(moved.reduce(Int64(0)) { $0 + $1.bytes }))")
        }
    }
}

struct SettingsView: View {
    @EnvironmentObject var m: Model
    @AppStorage("timeout") private var timeout: Double = 6
    @AppStorage("maxDepth") private var maxDepth: Int = 4
    @AppStorage("quarantineRoot") private var qRoot: String = ""

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("SETTINGS / DIAGNOSTICS").font(.title2.bold())
            Stepper("Per-root time budget: \(Int(timeout)) s", value: $timeout, in: 2...60, step: 1)
            Stepper("Discovery depth: \(maxDepth)", value: $maxDepth, in: 2...6)
            HStack {
                Text("Quarantine root: \(qRoot.isEmpty ? Modes.abbrev(Prefs.defaultQuarantineRoot.path) : Modes.abbrev(qRoot))").font(.callout)
                Button("Choose…") { m.chooseQuarantineRoot() }
                if !qRoot.isEmpty { Button("Reset") { qRoot = "" } }
            }
            RootBar(hint: "auto (per mode)")
            HStack {
                Button("Run Diagnostics") { m.run("Diagnostics") { Modes.diagnostics() } }.disabled(m.busy)
                Button("Open reports folder") {
                    try? FileManager.default.createDirectory(at: Report.dir, withIntermediateDirectories: true)
                    NSWorkspace.shared.open(Report.dir)
                }
            }
            Divider()
            ResultsView()
        }
        .padding()
    }
}
JANITOR_EOF

  ok "Sources written ($(ls "$SRC" | wc -l | tr -d ' ') files)"
fi

[ "$GEN_ONLY" -eq 1 ] && { ok "Generate-only mode: done."; exit 0; }

# ── 3. build ─────────────────────────────────────────────────────────────────
cd "$PROJ" || die "Project folder missing."
[ "$CLEAN" -eq 1 ] && { say "Cleaning"; rm -rf .build; }
say "Building (first build can take a few minutes)"
if swift build -c release > "$LOG" 2>&1; then
  ok "Build succeeded"
else
  echo
  printf "%sBuild failed. Compiler errors:%s\n" "$R" "$N"
  grep -E "error:" "$LOG" | head -n 25
  echo
  printf "%sFull log:%s %s\n" "$D" "$N" "$LOG"
  printf "%sTip:%s paste the errors to Claude, or run with --regen to restore pristine sources.\n" "$D" "$N"
  die "swift build failed."
fi

# ── 4. assemble + sign .app ──────────────────────────────────────────────────
say "Assembling JANITOR.app"
BIN="$(swift build -c release --show-bin-path 2>/dev/null)/JANITOR"
[ -x "$BIN" ] || die "Built binary not found at $BIN"
APP="$ROOT/JANITOR.app"
rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
cp "$BIN" "$APP/Contents/MacOS/JANITOR"
cp "$PROJ/Resources/Info.plist" "$APP/Contents/Info.plist"
if codesign --force --deep --sign - "$APP" >/dev/null 2>&1; then ok "Ad-hoc signed (built locally, so no Gatekeeper prompt)"; else warn "codesign skipped"; fi
ok "$APP"

# ── 5. launch ────────────────────────────────────────────────────────────────
if [ "$OPEN_XCODE" -eq 1 ]; then
  say "Opening project in Xcode"; xed "$PROJ" 2>/dev/null || open -a Xcode "$PROJ"
else
  say "Launching JANITOR"
  open "$APP"
  printf "  %sPress X within 6 s to open the project in Xcode too, or just wait.%s\n" "$D" "$N"
  if read -t 6 -n 1 -s key && [ "${key:-}" = "x" -o "${key:-}" = "X" ]; then xed "$PROJ" 2>/dev/null || open -a Xcode "$PROJ"; fi
fi
echo
ok "Done. Reports go to ~/Library/Logs/JANITOR/"
