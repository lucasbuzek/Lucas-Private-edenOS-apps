import SwiftUI
import AppKit

func statusColor(_ s: ScanStatus) -> Color {
    switch s {
    case .complete: return .green
    case .partial: return .orange
    case .review: return .yellow
    case .skipped: return .gray
    case .protected: return .red
    case .deferred: return .blue
    }
}

func stateColor(_ s: String) -> Color {
    switch s {
    case "MOVED", "DELETED", "RESTORED": return .green
    case "FAILED": return .red
    case "MISSING": return .orange
    default: return .gray
    }
}

struct Pill: View {
    let text: String
    let color: Color
    var body: some View {
        Text(text).font(.caption2.bold())
            .padding(.horizontal, 6).padding(.vertical, 2)
            .background(color.opacity(0.22), in: Capsule())
            .foregroundStyle(color)
    }
}

struct Btn: View {
    let title: String
    let icon: String
    let action: () -> Void
    init(_ title: String, _ icon: String, _ action: @escaping () -> Void) { self.title = title; self.icon = icon; self.action = action }
    var body: some View {
        Button(action: action) { Label(title, systemImage: icon).frame(maxWidth: .infinity, alignment: .leading) }
            .buttonStyle(.bordered)
    }
}

struct RootBar: View {
    @EnvironmentObject var m: Model
    let hint: String
    var body: some View {
        HStack {
            Image(systemName: "scope")
            Text("Root: \(m.workRoot.map { Modes.abbrev($0.path) } ?? hint)").font(.callout)
            Button("Choose…") { m.chooseWorkRoot() }
            if m.workRoot != nil { Button("Reset") { m.workRoot = nil } }
            Spacer()
        }
    }
}

struct Scaffold<Buttons: View>: View {
    @EnvironmentObject var m: Model
    let title: String
    let subtitle: String
    let rootHint: String?
    let buttons: Buttons

    init(title: String, subtitle: String, rootHint: String? = nil, @ViewBuilder buttons: () -> Buttons) {
        self.title = title; self.subtitle = subtitle; self.rootHint = rootHint; self.buttons = buttons()
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(title).font(.title2.bold())
            Text(subtitle).font(.callout).foregroundStyle(.secondary)
            if let h = rootHint { RootBar(hint: h) }
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 200), spacing: 8)], alignment: .leading, spacing: 8) { buttons }
                .disabled(m.busy)
            Divider()
            ResultsView()
        }
        .padding([.top, .horizontal])
    }
}

struct RootView: View {
    @EnvironmentObject var m: Model
    var body: some View {
        NavigationSplitView {
            List(Model.Mode.allCases, selection: Binding<Model.Mode?>(get: { m.mode }, set: { if let v = $0 { m.mode = v } })) { mode in
                Text(mode.rawValue).tag(mode)
            }
            .navigationSplitViewColumnWidth(min: 240, ideal: 260)
            .safeAreaInset(edge: .bottom) {
                Button("0  EXIT") { NSApp.terminate(nil) }.buttonStyle(.borderless).padding()
            }
        } detail: {
            ModeView()
        }
    }
}

struct ModeView: View {
    @EnvironmentObject var m: Model
    var body: some View {
        switch m.mode {
        case .standard: StandardView()
        case .developer: DeveloperView()
        case .media: MediaView()
        case .crew: CrewView()
        case .quarantine: QuarantineView()
        case .settings: SettingsView()
        }
    }
}

// MARK: - Results

struct ResultsView: View {
    @EnvironmentObject var m: Model
    @State private var confirmQ = false
    @State private var confirmD = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 12) {
                if m.busy {
                    HStack { ProgressView().controlSize(.small); Text(m.busyTitle); Button("Cancel") { m.cancel() } }
                }
                if let o = m.out { content(o) }
                if !m.message.isEmpty { Text(m.message).font(.headline) }
                if !m.results.isEmpty { ActionResultsView(results: m.results) }
            }
            .padding(.vertical)
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    @ViewBuilder
    func content(_ o: ScanOutput) -> some View {
        Text(o.title).font(.headline)
        ForEach(Array(o.lines.enumerated()), id: \.offset) { _, l in Text(l).font(.callout) }

        if !o.roots.isEmpty {
            DisclosureGroup("Roots (\(o.roots.count))") {
                VStack(alignment: .leading, spacing: 4) {
                    ForEach(o.roots) { r in
                        HStack(alignment: .firstTextBaseline) {
                            Pill(text: r.status.rawValue, color: statusColor(r.status))
                            Text("\(r.storage.rawValue) · \(Modes.abbrev(r.path)) · \(fmtBytes(r.bytes))\(r.note.isEmpty ? "" : " · " + r.note)")
                                .font(.caption)
                        }
                    }
                }.padding(.vertical, 4)
            }
        }

        ForEach(o.sections) { s in
            DisclosureGroup("\(s.title) (\(s.rows.count))") {
                VStack(alignment: .leading, spacing: 3) {
                    ForEach(Array(s.rows.enumerated()), id: \.offset) { _, r in
                        Text(r).font(.caption.monospaced()).textSelection(.enabled)
                    }
                }.padding(.vertical, 4)
            }
        }

        if !o.candidates.isEmpty { candidateList(o) }
    }

    @ViewBuilder
    func candidateList(_ o: ScanOutput) -> some View {
        let sel = m.selected()
        let bytes = sel.reduce(Int64(0)) { $0 + $1.bytes }
        Divider()
        HStack {
            Text("Review (\(o.candidates.count))").font(.headline)
            Spacer()
            Button("Select all") { m.selection = Set(o.candidates.map { $0.id }) }
            Button("None") { m.selection = [] }
            Button("Safe only") { m.selection = Set(o.candidates.filter { $0.preselect }.map { $0.id }) }
        }
        ForEach(o.candidates) { c in
            HStack(alignment: .top) {
                Toggle("", isOn: Binding(get: { m.selection.contains(c.id) },
                                         set: { on in if on { m.selection.insert(c.id) } else { m.selection.remove(c.id) } }))
                    .labelsHidden()
                VStack(alignment: .leading, spacing: 2) {
                    HStack {
                        Text(c.title).bold().lineLimit(1)
                        Pill(text: c.category, color: c.preselect ? .green : .orange)
                        Spacer()
                        Text(c.bytes > 0 ? fmtBytes(c.bytes) : "—").monospacedDigit()
                    }
                    Text("\(Modes.abbrev(c.url.path))\(c.note.isEmpty ? "" : " — " + c.note)")
                        .font(.caption).foregroundStyle(.secondary).lineLimit(2).textSelection(.enabled)
                }
            }
        }
        HStack {
            Text("\(sel.count) selected · \(fmtBytes(bytes))").font(.callout)
            Spacer()
            Button("Quarantine selected…") { confirmQ = true }.disabled(sel.isEmpty || m.busy)
            Button("Delete selected…", role: .destructive) { confirmD = true }.disabled(sel.isEmpty || m.busy)
        }
        .confirmationDialog("Move \(sel.count) item(s) (\(fmtBytes(bytes))) to quarantine?", isPresented: $confirmQ, titleVisibility: .visible) {
            Button("Quarantine") { m.quarantineSelected() }
            Button("Cancel", role: .cancel) {}
        } message: { Text("Items stay recoverable under QUARANTINE / RECOVERY. Each move is verified.") }
        .confirmationDialog("Permanently delete \(sel.count) item(s) (\(fmtBytes(bytes)))?", isPresented: $confirmD, titleVisibility: .visible) {
            Button("Delete permanently", role: .destructive) { m.deleteSelected() }
            Button("Cancel", role: .cancel) {}
        } message: { Text("This cannot be undone. Choose Quarantine instead if you may want these back.") }
    }
}

struct ActionResultsView: View {
    let results: [ActionResult]
    var body: some View {
        DisclosureGroup("Result per item (\(results.count))", isExpanded: .constant(true)) {
            VStack(alignment: .leading, spacing: 3) {
                ForEach(results) { r in
                    HStack(alignment: .firstTextBaseline) {
                        Pill(text: r.state, color: stateColor(r.state))
                        Text("\(r.name) — \(r.detail)").font(.caption).textSelection(.enabled)
                    }
                }
            }.padding(.vertical, 4)
        }
    }
}

// MARK: - Modes

struct StandardView: View {
    @EnvironmentObject var m: Model
    @State private var confirmBrew = false
    @State private var confirmSim = false
    @State private var confirmOld = false

    var body: some View {
        Scaffold(title: "STANDARD", subtitle: "Quick Scan is shallow and time-boxed — it never crawls your home folder. Nothing changes without review and confirmation.") {
            Btn("Quick Scan", "bolt") { m.run("Quick Scan") { Modes.quick(full: false) } }
            Btn("Full Scan", "magnifyingglass") { m.run("Full Scan") { Modes.quick(full: true) } }
            Btn("Storage Overview", "internaldrive") { m.run("Storage Overview") { Modes.overview() } }
            Btn("Choose What to Scan…", "folder") { m.chooseAndScan() }
            Btn("Preview Homebrew cleanup", "eye") { m.run("Homebrew preview") { Maint.brew(dryRun: true) } }
            Btn("Run Homebrew cleanup…", "shippingbox") { confirmBrew = true }
            Btn("Preview unavailable simulators", "eye") { m.run("Simulator preview") { Maint.simulators(dryRun: true) } }
            Btn("Remove unavailable simulators…", "iphone") { confirmSim = true }
            Btn("Delete quarantine > 30 days…", "clock.arrow.circlepath") { m.refreshOps(); confirmOld = true }
        }
        .confirmationDialog("Run `brew cleanup`?", isPresented: $confirmBrew, titleVisibility: .visible) {
            Button("Run cleanup") { m.run("Homebrew cleanup") { Maint.brew(dryRun: false) } }
            Button("Cancel", role: .cancel) {}
        } message: { Text("Uses Homebrew's own cleanup. Preview first to see what it will remove.") }
        .confirmationDialog("Remove unavailable simulators?", isPresented: $confirmSim, titleVisibility: .visible) {
            Button("Run simctl delete unavailable") { m.run("Remove simulators") { Maint.simulators(dryRun: false) } }
            Button("Cancel", role: .cancel) {}
        } message: { Text("Uses Apple's simctl. Only simulators Xcode already marks unavailable are removed.") }
        .confirmationDialog("Delete \(m.oldOps(days: 30).count) quarantine operation(s) older than 30 days?", isPresented: $confirmOld, titleVisibility: .visible) {
            Button("Delete permanently", role: .destructive) { m.deleteOps(m.oldOps(days: 30)) }
            Button("Cancel", role: .cancel) {}
        } message: { Text("Their items can no longer be restored.") }
    }
}

struct DeveloperView: View {
    @EnvironmentObject var m: Model
    var body: some View {
        Scaffold(title: "DEVELOPER", subtitle: "Targeted known caches, project/version discovery and build families. Git working copies and active builds are excluded.",
                 rootHint: "auto (\(Modes.abbrev(Modes.defaultDevRoot().path)))") {
            Btn("Developer Quick", "hammer") { m.run("Developer Quick") { Modes.devQuick() } }
            Btn("Project Identity / Versions", "square.stack.3d.up") { let r = m.devRoot; m.run("Project discovery") { Modes.projects(root: r) } }
            Btn("Build Families", "list.number") { let r = m.devRoot; m.run("Build families") { Modes.buildFamilies(root: r) } }
            Btn("Build / Dependency Discovery", "shippingbox") { let r = m.devRoot; m.run("Dependency discovery") { Modes.dependencies(root: r) } }
        }
    }
}

struct MediaView: View {
    @EnvironmentObject var m: Model
    var body: some View {
        Scaffold(title: "MEDIA", subtitle: "Local media only. Cloud-provider roots and Photos libraries are never crawled or hashed; nothing is auto-deleted.",
                 rootHint: "Movies, Music, Pictures, Downloads") {
            Btn("Inventory + Large Media", "film") { let r = m.workRoot; m.run("Media inventory") { Modes.media(root: r) } }
            Btn("Exact Duplicates", "doc.on.doc") { let r = m.workRoot; m.run("Exact duplicates") { Modes.duplicates(root: r) } }
            Btn("Similar Names", "textformat") { let r = m.workRoot; m.run("Similar names") { Modes.similarNames(root: r) } }
            Btn("Photos Library Footprint", "photo.on.rectangle") { m.run("Photos footprint") { Modes.photosFootprint() } }
        }
    }
}

struct CrewView: View {
    @EnvironmentObject var m: Model
    var body: some View {
        Scaffold(title: "FULL CREW", subtitle: "Advanced diagnostics, grouped and read-only. Inaccessible is never reported as broken; “remnant” is never claimed without evidence.",
                 rootHint: "home folder (Broken Items)") {
            Btn("Running Processes", "cpu") { m.run("Processes") { Modes.processes() } }
            Btn("Startup / Background Items", "power") { m.run("Startup items") { Modes.startup() } }
            Btn("Installed Apps", "square.grid.2x2") { m.run("Installed apps") { Modes.appsInventory() } }
            Btn("Support Inventory", "tray.full") { m.run("Support inventory") { Modes.supportInventory() } }
            Btn("Broken Items", "link.badge.plus") { let r = m.workRoot ?? Storage.home; m.run("Broken items") { Modes.broken(root: r) } }
            Btn("Storage Diagnostics + Snapshots", "chart.bar") { m.run("Storage diagnostics") { Modes.storageGrowth() } }
        }
    }
}

struct QuarantineView: View {
    @EnvironmentObject var m: Model
    @State private var deleteTarget: QOp?

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("QUARANTINE / RECOVERY").font(.title2.bold())
                Spacer()
                Button("Refresh") { m.refreshOps() }
                Button("Reveal root") { reveal(Prefs.quarantineRoot) }
            }
            Text("Root: \(Modes.abbrev(Prefs.quarantineRoot.path)) — items removed by hand are marked MISSING and never block the manager.")
                .font(.callout).foregroundStyle(.secondary)
            if m.busy { HStack { ProgressView().controlSize(.small); Text(m.busyTitle) } }
            if m.ops.isEmpty { Text("No quarantine operations yet.").foregroundStyle(.secondary) }
            ScrollView {
                VStack(alignment: .leading, spacing: 8) {
                    ForEach(m.ops) { op in opView(op) }
                    if !m.message.isEmpty { Text(m.message).font(.headline) }
                    if !m.results.isEmpty { ActionResultsView(results: m.results) }
                }
            }
        }
        .padding()
        .onAppear { m.refreshOps() }
        .confirmationDialog("Delete this quarantine operation permanently?", isPresented: Binding(get: { deleteTarget != nil }, set: { if !$0 { deleteTarget = nil } }), titleVisibility: .visible) {
            Button("Delete permanently", role: .destructive) { if let t = deleteTarget { m.deleteOps([t]) }; deleteTarget = nil }
            Button("Cancel", role: .cancel) { deleteTarget = nil }
        } message: { Text("Items still inside can no longer be restored.") }
    }

    func reveal(_ u: URL) {
        if Quarantine.present(u.path) { NSWorkspace.shared.activateFileViewerSelecting([u]) }
        else { NSWorkspace.shared.activateFileViewerSelecting([u.deletingLastPathComponent()]) }
    }

    @ViewBuilder
    func opView(_ op: QOp) -> some View {
        let moved = op.manifest.items.filter { $0.state == "MOVED" }
        let missing = op.manifest.items.filter { $0.state == "MISSING" }.count
        DisclosureGroup(isExpanded: Binding(get: { m.openOp == op.id }, set: { m.openOp = $0 ? op.id : nil })) {
            VStack(alignment: .leading, spacing: 4) {
                ForEach(op.manifest.items) { it in
                    HStack(alignment: .top) {
                        Toggle("", isOn: Binding(get: { m.opSelection.contains(it.id) },
                                                 set: { on in if on { m.opSelection.insert(it.id) } else { m.opSelection.remove(it.id) } }))
                            .labelsHidden().disabled(it.state != "MOVED")
                        Pill(text: it.state, color: stateColor(it.state))
                        VStack(alignment: .leading, spacing: 1) {
                            Text(URL(fileURLWithPath: it.original).lastPathComponent).bold()
                            Text("\(Modes.abbrev(it.original)) · \(it.reason) · \(fmtBytes(it.bytes))").font(.caption).foregroundStyle(.secondary).textSelection(.enabled)
                        }
                    }
                }
                HStack {
                    Button("Restore selected") { m.restore(op, ids: m.opSelection) }
                        .disabled(m.opSelection.isEmpty || m.busy)
                    Button("Restore all") { m.restore(op, ids: nil) }.disabled(moved.isEmpty || m.busy)
                    Button("Reveal") { reveal(op.folder) }
                    Button("Delete operation…", role: .destructive) { deleteTarget = op }.disabled(m.busy)
                }
            }.padding(.vertical, 4)
        } label: {
            Text("\(op.id) — \(op.manifest.items.count) item(s), \(moved.count) in quarantine\(missing > 0 ? ", \(missing) MISSING" : "") · \(fmtBytes(moved.reduce(Int64(0)) { $0 + $1.bytes }))")
        }
    }
}

struct SettingsView: View {
    @EnvironmentObject var m: Model
    @AppStorage("timeout") private var timeout: Double = 6
    @AppStorage("maxDepth") private var maxDepth: Int = 4
    @AppStorage("quarantineRoot") private var qRoot: String = ""

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("SETTINGS / DIAGNOSTICS").font(.title2.bold())
            Stepper("Per-root time budget: \(Int(timeout)) s", value: $timeout, in: 2...60, step: 1)
            Stepper("Discovery depth: \(maxDepth)", value: $maxDepth, in: 2...6)
            HStack {
                Text("Quarantine root: \(qRoot.isEmpty ? Modes.abbrev(Prefs.defaultQuarantineRoot.path) : Modes.abbrev(qRoot))").font(.callout)
                Button("Choose…") { m.chooseQuarantineRoot() }
                if !qRoot.isEmpty { Button("Reset") { qRoot = "" } }
            }
            RootBar(hint: "auto (per mode)")
            HStack {
                Button("Run Diagnostics") { m.run("Diagnostics") { Modes.diagnostics() } }.disabled(m.busy)
                Button("Open reports folder") {
                    try? FileManager.default.createDirectory(at: Report.dir, withIntermediateDirectories: true)
                    NSWorkspace.shared.open(Report.dir)
                }
            }
            Divider()
            ResultsView()
        }
        .padding()
    }
}
