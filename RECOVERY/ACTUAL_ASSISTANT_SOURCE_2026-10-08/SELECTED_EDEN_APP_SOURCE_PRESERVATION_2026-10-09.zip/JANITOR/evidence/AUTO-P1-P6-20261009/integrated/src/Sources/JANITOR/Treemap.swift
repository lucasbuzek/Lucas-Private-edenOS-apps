import SwiftUI
import Foundation

private struct Tile: Identifiable, Sendable {
    let id = UUID()
    let name: String
    let path: String
    let bytes: Int64
    let status: ScanStatus
}

struct TreemapWindow: View {
    let root: URL
    @Environment(\.dismiss) private var dismiss
    @State private var tiles: [Tile] = []
    @State private var selected: Tile?
    @State private var busy = true
    @State private var note = "Measuring local folders…"

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack { Text("Storage treemap").font(.title2.bold()); Spacer(); Button("Close") { dismiss() } }
            Text(root.path).font(.caption).foregroundStyle(.secondary).lineLimit(1)
            if busy { ProgressView(note) }
            GeometryReader { geometry in
                let total = max(tiles.reduce(0.0) { $0 + Double(max($1.bytes, 0)) }, 1)
                let width = max(geometry.size.width, 1)
                let height = max(geometry.size.height, 1)
                // Slice-and-dice: each tile's area is proportional to measured allocated bytes.
                HStack(spacing: 2) {
                    ForEach(tiles) { tile in
                        let fraction = Double(max(tile.bytes, 0)) / total
                        Button {
                            selected = tile
                        } label: {
                            VStack(alignment: .leading, spacing: 5) {
                                Text(tile.name).font(.caption.bold()).lineLimit(2)
                                Text(fmtBytes(tile.bytes)).font(.caption2)
                                Text(tile.status.rawValue).font(.system(size: 9))
                                Spacer(minLength: 0)
                            }
                            .padding(6)
                            .frame(width: max(0, width * fraction - 2), height: height, alignment: .topLeading)
                            .background(selected?.id == tile.id ? Color.accentColor.opacity(0.65) : Color.accentColor.opacity(0.22), in: RoundedRectangle(cornerRadius: 5))
                            .clipped()
                        }.buttonStyle(.plain)
                    }
                }
            }.frame(height: 270)
            if let selected {
                Text("Selected: \(selected.name) — \(fmtBytes(selected.bytes)) [\(selected.status.rawValue)]").font(.callout)
                Button("Reveal in Finder") { NSWorkspace.shared.activateFileViewerSelecting([URL(fileURLWithPath: selected.path)]) }
            }
            Text(note).font(.caption).foregroundStyle(.secondary)
        }
        .padding(20).frame(minWidth: 700, minHeight: 430)
        .task {
            let target = root
            let result = await Task.detached(priority: .utility) { () -> ([Tile], String) in
                let cls = Storage.classify(target)
                guard cls.scannable, !Storage.isBoundary(target), !Storage.isManagedTree(target) else { return ([], "Protected or provider-managed root — refused") }
                let deadline = Date().addingTimeInterval(Prefs.timeout * 5)
                var values: [Tile] = []
                for u in (Scan.listChildren(target) ?? []).prefix(35) {
                    if Date() > deadline || Task.isCancelled { break }
                    guard Storage.classify(u).scannable, !Storage.isBoundary(u), !Storage.isManagedTree(u) else { continue }
                    let measure = Scan.size(of: u, deadline: Date().addingTimeInterval(2))
                    if measure.bytes > 0 { values.append(Tile(name: u.lastPathComponent, path: u.path, bytes: measure.bytes, status: measure.status)) }
                }
                values.sort { $0.bytes > $1.bytes }
                return (Array(values.prefix(12)), "Read-only local folder sample. Partial measurements are estimates; protected and cloud folders excluded.")
            }.value
            tiles = result.0; note = result.1; busy = false
        }
    }
}
