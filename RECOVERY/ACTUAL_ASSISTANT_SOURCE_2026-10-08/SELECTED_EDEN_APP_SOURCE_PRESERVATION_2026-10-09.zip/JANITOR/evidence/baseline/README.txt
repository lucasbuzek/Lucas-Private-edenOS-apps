JANITOR — Justified Analysis, Navigation, Inspection, Tidying, Optimization & Recovery
v0.10.1-terminal-contract-audit-repair-candidate

CURRENT MILESTONE
Apple-first terminal behavioral reference. macOS Bash only in this package.
Native order after script acceptance: macOS -> iOS/iPadOS -> Windows -> other platforms.

USER MODES
STANDARD — everyday local maintenance
DEVELOPER — local projects/builds/toolchains
MEDIA — local media and protected Photos-library footprint
FULL CREW — advanced terminal-safe inspection/recovery

TERMINAL CONTRACT
Bash performs only capabilities it can verify safely and deterministically.
Capabilities requiring Apple native frameworks/authorization are explicitly deferred rather than simulated.

NATIVE-ONLY DEFERRALS
- File Provider item/domain identity, dataless/materialized state, eviction, provider-safe mutation
- PhotoKit local-vs-iCloud asset state and supported reclaim
- reliable application-remnant ownership correlation/removal
- rich process signing/origin attribution and managed termination
- native login/background task management

SAFETY
UNKNOWN != JUNK.
Provider-managed paths are skipped by local recursive/hash scans.
.photoslibrary internals are protected.
No daemon, resident service, telemetry or mandatory AI/cloud dependency.


v0.10.1 AUDIT REPAIR
All user-selected recursive scans are provider-guarded and time/depth bounded where practical. Generic custom scan and Downloads analysis no longer perform unbounded recursion. Size walks use a deadline. Project discovery has both depth and per-root time budgets. Native-only Apple framework work remains explicitly deferred.
