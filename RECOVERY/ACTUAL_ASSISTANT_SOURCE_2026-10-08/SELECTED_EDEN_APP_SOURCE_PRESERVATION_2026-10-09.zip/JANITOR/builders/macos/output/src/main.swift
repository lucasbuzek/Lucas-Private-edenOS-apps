import SwiftUI
@main struct JanitorApp: App { var body: some Scene { WindowGroup { ContentView() } } }
struct ContentView: View {
 @State private var section="Overview"
 let sections=["Overview","Standard","Developer","Media","Full Crew","Quarantine"]
 var body: some View { NavigationView { List(sections,id:\.self,selection:$section){ Text($0) }.frame(minWidth:190); VStack(alignment:.leading,spacing:16){ Text(section).font(.largeTitle.bold()); Text("JANITOR — Justified Analysis, Navigation, Inspection, Tidying, Optimization & Recovery").foregroundStyle(.secondary); GroupBox { VStack(alignment:.leading,spacing:10){ Label("Ready",systemImage:"checkmark.circle"); Text(section == "Full Crew" ? "Processes and services: inspect; identified user/third-party services may Start, Stop, Restart, Enable or Disable. Apple system services remain protected." : "Self-contained baseline. Capability-first; installed compatible tools are optional accelerators.") } }.frame(maxWidth:.infinity,alignment:.leading); Spacer() }.padding(28) }.frame(minWidth:860,minHeight:600) }
}
