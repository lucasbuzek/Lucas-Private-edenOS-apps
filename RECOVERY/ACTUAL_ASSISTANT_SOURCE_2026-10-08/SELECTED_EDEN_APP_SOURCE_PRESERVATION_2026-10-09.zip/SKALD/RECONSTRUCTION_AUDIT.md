# Recovered-envelope audit

0.2.0 salvage: SQLite transactions/backups; safe filesystem enumeration;
loopback HTTP and same-origin safeguards; persisted user state; process locking;
fixture/browser tooling. Retain only after adaptation to corrected contract.

Rejected implementation directions: one-location/path identity; filename-first
UI; JSON-only Packs; ephemeral scan threads; loopback-only delivery as product
ceiling; GUI-owned stop-on-close runtime; package qualification as milestone.

Required reconstruction: logical titles plus physical representations/dedup;
search and artwork/media presentation; authenticated byte-range broadcast;
persistent restartable workers; sources/storage/services; prepare/verify pipeline;
tracking/Daily Episodes; metadata correction; actual verified Pack transfer and
return reconciliation; Archive/restore; backups; optional hosting lifecycle;
installer profiles; then native full GUI/menu bar. Test-controlled sidecars and
working copies must prove non-destructive behavior and clean destination media.

Audit is an implementation input, not evidence of completed functionality.
