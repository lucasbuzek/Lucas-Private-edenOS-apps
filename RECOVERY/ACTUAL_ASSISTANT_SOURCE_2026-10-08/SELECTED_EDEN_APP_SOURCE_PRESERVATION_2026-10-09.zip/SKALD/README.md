# SKALD reconstruction — recovered v0.9.4 functional envelope

The prior 0.2.0 minimal product and packages are rejected. Preserved code is
engineering salvage only. `PROJECT_BIBLE.md` records the corrected product
contract; `HANDOFF.md` records current execution continuity. Reconstruction is
in progress, not a recovered historical-source build or verified release.

One persistent Headless runtime owns SKALD's Movies/TV/Music, library/state,
Web/PWA/API, background preparation and actual delivery. Native GUI follows
Headless gates and must not stop the runtime when closed. Real Travel Packs,
verified Archive movement, Daily Episodes READY TO WATCH and clean-media rules
are required. JSON planning and filename browsing do not satisfy the product.

No current distributable package is qualified. All old 0.2.0 package directories
are rejected fixtures. See `RecoveryEvidence/REJECTED_0.2.0.json`.
