# SKALD current reconstruction position

2026-10-02 EITRIMB correction is active authority. Read PROJECT_BIBLE.md.
Canonical workspace is `/Users/lucas/edenOS/Projects/SKALD`; Git master unborn.

0.2.0 and all its minimal-product/qualification/packages are **REJECTED**.
Not LKG, product authority or current candidate. Preserved for engineering
salvage only in `RecoveryEvidence/rejected-0.2.0-source.zip` and rejection record.
Prior recovery report is superseded as product direction. Historical source
bytes are lost; reconstructed **v0.9.4 functional envelope is the floor**.

Execute reconstruction of one persistent SKALD Headless domain/runtime with
real library identity/search/dedup/offline state, authenticated byte-range
broadcast, collections/tracking/progress, persistent jobs, safe working-copy
preparation, metadata/artwork/subtitles, Daily Episodes through READY TO WATCH,
verified Archive/storage lifecycle, real offline Travel Packs/transfer/return
state, providers and reversible optional BIFROST hosting. Full media-first Web
UI over that core. Clean-media and user sidecars mandatory. No package until
Headless gates. Native full GUI/menu-bar lifecycle follows; GUI close must not
stop runtime. Pantheon follows SKALD gates.

Current implementation position: prior code audited and frozen. Reconstruction
is in progress, beginning shared runtime/state and independently testable media
adapters and filesystem delivery primitives. Installed FFmpeg/ffprobe and
Transmission CLI detected; Subler present but no adapter PASS yet.

Next executable action: implement/persist/test the reconstructed domain and
worker/API contracts, integrate real preparation/verified delivery and Web
workflows, repair failures. Do not stop at this handoff/audit or repeat broad
recovery. Do not launch/qualify the rejected 0.2.0 package as SKALD.
