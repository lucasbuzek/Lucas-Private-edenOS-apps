"""Read-only storage capability. Domain classification belongs to SKALD core."""
from dataclasses import dataclass
import os
from pathlib import Path
import stat

@dataclass(frozen=True)
class StoredFile:
    path: Path
    size: int
    modified: float

class LocalStorage:
    id = 'local'
    description = 'Local filesystem, external volumes, and already mounted shares'
    writes_media = False

    def inventory(self, base: Path, extensions: set[str]) -> list[StoredFile]:
        if not base.is_dir():
            raise OSError(f'Library folder is unavailable: {base}')
        errors = []
        records = []
        for current, dirs, files in os.walk(base, followlinks=False, onerror=lambda e: errors.append(str(e))):
            dirs[:] = [d for d in dirs if not (Path(current) / d).is_symlink()]
            for filename in files:
                full = Path(current) / filename
                if full.is_symlink() or full.suffix.lower() not in extensions:
                    continue
                try:
                    info = full.stat()
                    if stat.S_ISREG(info.st_mode):
                        records.append(StoredFile(full.resolve(strict=True), info.st_size, info.st_mtime))
                except OSError as exc:
                    errors.append(str(exc))
        if errors:
            raise OSError('Some media locations could not be read: ' + '; '.join(errors[:5]))
        return records

    def inspect(self, path: Path) -> StoredFile:
        if path.is_symlink():
            raise OSError('Symlink media locations require review')
        info = path.stat()
        if not stat.S_ISREG(info.st_mode):
            raise OSError('Not a regular media file')
        return StoredFile(path, info.st_size, info.st_mtime)

LOCAL_STORAGE = LocalStorage()
