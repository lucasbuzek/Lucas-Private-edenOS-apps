# SKALD — StoryKeeper: Archive, Lifestyle & Delivery

This project contract records the user's recovered THREAD authority and EITRIMB
correction of 2026-10-02. It supersedes the rejected minimal 0.2.0 product
assumptions. It does not claim historical source-byte or Git-history recovery.
Global AppDev/EITRIMB rules remain at their established authority locations.

**Reconstruction floor: v0.9.4 GOAL-ALIGNED PRIVATE EXPERIMENT functional envelope.**
Source bytes are lost. Reconstruct the known behavior and verify from actual
code/runtime. 0.2.0 is rejected product direction and engineering salvage only,
not LKG, authoritative product scope, release candidate or qualification floor.
Its archived records remain rejection/provenance evidence, not current canon.

One independently distributable, local-first SKALD domain/core/runtime owns
Movies, TV and Music; logical identities, representations, metadata, watched/
progress, collections/tracking, acquisition, processing, delivery, Archive,
Travel Packs, Daily Episodes and background automation. No competing database
for Web, native GUI, BIFROST, HEIMDALL or Pantheon.

Headless is the persistent functional runtime, API, Web/PWA GUI, background
jobs/automation and media delivery. Library Broadcast is a default capability:
authorized library/API and byte-range/LAN delivery without requiring Jellyfin.
Remote access must not expose public administration. Standalone operation must
remain possible without BIFROST or cloud providers. BIFROST optionally hosts
generic runtime infrastructure through compatible reversible delegation,
preventing duplicates and preserving state on standalone retake. HEIMDALL may
compose SKALD; neither owns its media domain.

The full macOS application is a native GUI/control surface for that runtime.
Closing its GUI must retreat/minimize to menu bar/background and leave SKALD
running. Menu bar: Running, Ready, Preparing, Review; Open SKALD; Open Web SKALD;
pause automation; settings/diagnostics; deliberate Quit. Implement this after
Headless gates, not as a browser launcher substitute for the native GUI.

Dark-graphite, artwork-driven, media-first UI/UIX. Normal users see media, not
raw paths, seconds or provider infrastructure. User surfaces: Home, Search,
Movies, TV Shows, Music, Collections, Continue Watching, Next Up, Upcoming,
Travel Packs, Downloads/Acquisition, Processing/Activity, Inbox/Review, Sources,
Storage, Services, Automation and Settings. Diagnostics/Development separate.
Home: Continue Watching, Next Up, Ready to Watch/new episodes, recent/new media,
Movies/TV/Music, Upcoming and Attention. UI must execute backend workflows;
no cosmetic controls for absent capabilities.

Recovered Headless envelope includes library/index/search, identity/dedup/offline
media, byte-range streaming/broadcast, watched/progress/Continue Watching,
collections/tracking, persistent jobs, backup, verified Archive movement,
Daily Episodes reaching READY TO WATCH, real Travel Pack preparation/transfer/
verification, metadata correction, installer profiles, cross-platform service
contracts and reversible optional BIFROST hosting.

Acquisition/preparation workflow:
TRACK/DISCOVER → wanted/missing/upcoming → search provider → normalize candidates
→ explicit manual Add/magnet where manual → Transmission/provider → completion
→ SAFE WORKING COPY → ffprobe/inspect → identify/match → metadata → artwork →
subtitles (historical defaults EN/SK/CS) → validate → Subler/remux when appropriate
→ verify → organize/register → READY TO WATCH → TV.app/Infuse/selected player
→ progress/watched → archive/retain/replace. Temporary quality may be replaced by
preferred quality without losing logical identity/state. Providers are modular;
no uncontrolled downloading. Reuse installed/native/mature tooling. Direct Play
first; safe remux/stream-copy next; transcode only if necessary.

Daily Episodes automation states: EXPECTED → RELEASED → AVAILABLE → ACQUIRING →
VERIFYING → PREPARING → READY TO WATCH → WATCHED. Failures enter Review. READY
episodes surface naturally in Home/TV/Next Up. Notifications alone do not meet
this workflow.

Travel Packs are real offline deliverables, not JSON plans. Context/presets:
weekend, getaway, couples retreat, holiday, vacation, road trip, or custom. Choose
target device, storage budget/title count and quality/preferences; preview;
acquire/prepare; copy/remux/transcode only as needed; transfer; VERIFY; register;
Ready Offline; reconcile watched/progress on return. Pack definitions and
operational state stay separate from physical media. Copies/transfers require
explicitly authorized destinations/operations; test with disposable fixtures.

Archive is a verified storage lifecycle preserving identity, metadata/progress
while media is archived/offline/restored. Sources describe entry/discovery;
Storage describes physical representations; Services describe capabilities/
providers (Transmission, metadata/subtitle providers, Subler, FFmpeg, players).
These are distinct concepts and UI surfaces.

Clean-media: no routine generated JPG/PNG/JSON/XML/NFO/hash/cache/bookkeeping
beside media. Operational data/artwork/cache belongs in SKALD app data. Preserve
user-provided sidecars. No destructive normalization. Tokens, credentials and
private notes remain local secure operational data, never portable library
metadata. Optional provider choice, installer profiles LEAN/RECOMMENDED/FULL/
CUSTOM, existing-capability detection/install offers and safe owned-component
management must not delete another application's media/config. Jellyfin is
optional; removal requires a separate user-authorized safe operation.

Subler and Transmission installed on this Mac are capability candidates until
adapter verification. Physical playback, real providers/NAS/BIFROST, remote
access and devices require actual environment/physical evidence. Fixtures do
not prove those gates. Pantheon follows working SKALD gates, retaining its exact
private family/friends concept and reusing the same authoritative library.

Execution: reconstruct and prove Headless envelope before regression/package
promotion; then native GUI/menu-bar lifecycle; Pantheon last. Continue safe
implementation/repair under AUTO until a real milestone or demonstrably genuine
blocker. Missing historical bytes do not lower the functional floor.
