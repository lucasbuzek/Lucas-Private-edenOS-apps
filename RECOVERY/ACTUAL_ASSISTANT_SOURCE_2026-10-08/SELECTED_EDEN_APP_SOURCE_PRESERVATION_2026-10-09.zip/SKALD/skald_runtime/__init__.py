"""New reconstruction of the recovered SKALD functional contract."""
VERSION = '0.9.4-reconstruction-dev'
