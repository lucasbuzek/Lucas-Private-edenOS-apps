"""Authenticated library broadcast, byte-range playback and shared domain API."""
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from http.cookies import SimpleCookie
import hmac
import ipaddress
import json
import mimetypes
from pathlib import Path
import re
import secrets
import sqlite3
import subprocess
import sys
from urllib.parse import urlsplit,parse_qs
from . import VERSION

WEB=Path(__file__).resolve().parent.parent/'web'

class Server(ThreadingHTTPServer):
    daemon_threads=True
    def __init__(self,address,runtime,allow_lan=False):
        self.runtime=runtime;self.allow_lan=allow_lan
        self.sessions={};self.csrf=secrets.token_urlsafe(32)
        token_file=runtime.data_dir/'broadcast-token'
        if not token_file.exists():
            token_file.write_text(secrets.token_urlsafe(48));token_file.chmod(0o600)
        self.broadcast_token=token_file.read_text().strip()
        super().__init__(address,Handler)
    def get_request(self):
        connection,address=super().get_request();connection.settimeout(30);return connection,address

class Handler(BaseHTTPRequestHandler):
    server_version='SKALD/'+VERSION
    def log_message(self,fmt,*args):pass
    @property
    def core(self):return self.server.runtime
    def json(self,value,status=200,headers=None):
        data=json.dumps(value,allow_nan=False).encode();self.send_response(status)
        self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(data)));self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
        for k,v in (headers or {}).items():self.send_header(k,v)
        self.end_headers()
        if self.command!='HEAD':self.wfile.write(data)
    def valid_host(self):
        host=self.headers.get('Host','')
        try:
            parsed=urlsplit('//'+host);name=parsed.hostname;port=parsed.port
            if port!=self.server.server_port:return False
            if name=='localhost':return True
            value=ipaddress.ip_address(name)
            if value.is_loopback:return True
            return self.server.allow_lan and value.is_private and not value.is_unspecified and not value.is_multicast
        except ValueError:return False
    def secure_request(self,mutation=False):
        if not self.valid_host():self.json({'error':'Use an authorized SKALD address'},403);return False
        origin=self.headers.get('Origin')
        if origin and origin!='http://'+self.headers['Host']:self.json({'error':'Same-origin access required'},403);return False
        if mutation and self.headers.get('Content-Type','').split(';')[0]!='application/json':self.json({'error':'JSON required'},415);return False
        return True
    def role(self):
        token=self.headers.get('Authorization','')
        if token.startswith('Bearer ') and hmac.compare_digest(token[7:],self.server.broadcast_token):return 'viewer'
        cookie=SimpleCookie()
        try:cookie.load(self.headers.get('Cookie',''))
        except Exception:return None
        session=cookie.get('skald_session')
        return self.server.sessions.get(session.value) if session else None
    def authorized(self,admin=False,mutation=False):
        role=self.role()
        if not role:self.json({'error':'Authorize this SKALD session'},401);return False
        if admin and role!='admin':self.json({'error':'Administration requires the local SKALD session'},403);return False
        if mutation and not hmac.compare_digest(self.headers.get('X-SKALD-CSRF',''),self.server.csrf):self.json({'error':'Session confirmation required'},403);return False
        return True
    def body(self):
        length=int(self.headers.get('Content-Length','0'))
        if not 0<length<=1024*1024:raise ValueError('JSON body must be between 1 byte and 1 MiB')
        value=json.loads(self.rfile.read(length),parse_constant=lambda v:(_ for _ in ()).throw(ValueError('Non-finite JSON number')))
        if not isinstance(value,dict):raise ValueError('Expected an object')
        for key in ('id','media_id','source_id','storage_id','tracking_id'):
            if key in value and not isinstance(value[key],str):raise ValueError(key+' must be text')
        return value
    def public_media(self,item):
        if self.role()=='admin':return item
        return {k:v for k,v in item.items() if k not in {'locations','metadata'}}
    def do_HEAD(self):self.do_GET()
    def do_GET(self):
        if not self.secure_request():return
        parsed=urlsplit(self.path);route=parsed.path;query=parse_qs(parsed.query)
        try:
            if route in {'/','/app.js','/style.css','/sw.js','/manifest.webmanifest','/icon.svg'}:
                path=WEB/('index.html' if route=='/' else route[1:]);data=path.read_bytes().replace(b'__VERSION__',VERSION.encode())
                self.send_response(200);self.send_header('Content-Type',{'/sw.js':'application/javascript','/app.js':'application/javascript','/manifest.webmanifest':'application/manifest+json'}.get(route,mimetypes.guess_type(path)[0] or 'application/octet-stream'));self.send_header('Content-Length',str(len(data)));self.send_header('Cache-Control','no-cache');self.send_header('X-Content-Type-Options','nosniff');self.end_headers()
                if self.command!='HEAD':self.wfile.write(data)
                return
            if route=='/api/session':
                if not ipaddress.ip_address(self.client_address[0]).is_loopback:self.json({'error':'Authorize Library Broadcast with its device token'},403);return
                session=secrets.token_urlsafe(32);self.server.sessions[session]='admin'
                self.json({'csrf':self.server.csrf,'version':VERSION,'role':'admin'},headers={'Set-Cookie':f'skald_session={session}; HttpOnly; SameSite=Strict; Path=/'})
                return
            public=route in {'/api/home','/api/library','/api/collections','/api/tracking','/api/status'} or route.startswith('/api/media/') or route.startswith('/api/artwork/')
            if not self.authorized(admin=not public):return
            if route=='/api/library':self.json({'items':[self.public_media(i) for i in self.core.library(query.get('kind',['all'])[0],query.get('q',[''])[0])['items']]});return
            if route=='/api/home':
                data=self.core.home()
                if self.role()!='admin':
                    for k in ('continue_watching','next_up','ready_to_watch','recent','movies','tv','music'):data[k]=[self.public_media(i) for i in data[k]]
                    data['attention']=[];data['upcoming']=[{k:v for k,v in i.items() if k not in {'config','source_id'}} for i in data['upcoming']]
                self.json(data);return
            match=re.fullmatch('/api/media/([a-f0-9]+)(/stream)?',route)
            if match:
                if match[2]:self.stream(self.core.playable(match[1]))
                else:self.json(self.public_media(self.core.media(match[1])))
                return
            match=re.fullmatch('/api/artwork/([a-f0-9]+)',route)
            if match:
                with self.core.db() as db:row=db.execute('SELECT artwork FROM media WHERE id=?',(match[1],)).fetchone()
                if not row or not row['artwork']:raise FileNotFoundError('Artwork unavailable')
                path=Path(row['artwork']).resolve()
                if not path.is_relative_to(self.core.data_dir/'artwork'):raise ValueError('Artwork path is invalid')
                self.stream(path);return
            values={'/api/collections':lambda:{'collections':self.core.collections()},'/api/tracking':lambda:{'items':self.core.tracking()},'/api/sources':lambda:{'sources':self.core.sources()},'/api/storage':lambda:{'storage':self.core.storages()},'/api/services':lambda:{'services':self.core.services()},'/api/jobs':lambda:{'jobs':self.core.jobs()},'/api/review':lambda:{'items':self.core.reviews()},'/api/packs':lambda:{'packs':self.core.packs()},'/api/settings':lambda:{'settings':self.core.settings()},'/api/status':lambda:{'version':VERSION,'runtime':'persistent','state':'Review' if self.core.reviews() else 'Preparing' if any(j['state']=='RUNNING' for j in self.core.jobs()) else 'Ready','count':len(self.core.library()['items'])},'/api/diagnostics':lambda:{'version':VERSION,'data_dir':str(self.core.data_dir),'jobs':self.core.jobs(),'services':self.core.services(),'settings':self.core.settings(),'broadcast':{'enabled':self.core.settings()['library_broadcast'],'lan':self.server.allow_lan,'token_file':str(self.core.data_dir/'broadcast-token')},'provenance':'reconstructed new source; no historical bytes recovered'}}
            if route in values:
                result=values[route]()
                if route=='/api/tracking' and self.role()!='admin':result['items']=[{k:v for k,v in i.items() if k not in {'config','source_id'}} for i in result['items']]
                self.json(result);return
            self.json({'error':'Not found'},404)
        except FileNotFoundError as exc:self.json({'error':str(exc)},404)
        except (ValueError,OSError,sqlite3.Error) as exc:self.json({'error':str(exc)},400)
    def stream(self,path):
        if self.role()=='viewer' and not self.core.settings()['library_broadcast']:self.json({'error':'Library Broadcast is paused'},403);return
        stream=path.open('rb')
        try:
            size=path.stat().st_size;start=0;end=size-1;partial=False
            etag='"'+str(size)+'-'+str(path.stat().st_mtime_ns)+'"'
            range_header=self.headers.get('Range')
            if range_header and self.headers.get('If-Range',etag)==etag:
                match=re.fullmatch(r'bytes=(\d*)-(\d*)',range_header)
                if not match or not any(match.groups()):self.json({'error':'Single byte range required'},416,{'Content-Range':f'bytes */{size}'});return
                a,b=match.groups()
                if a:start=int(a);end=min(int(b) if b else size-1,size-1)
                else:
                    suffix=int(b);start=max(0,size-suffix);end=size-1
                    if suffix==0:start=size
                if start>=size or end<start:self.json({'error':'Range unavailable'},416,{'Content-Range':f'bytes */{size}'});return
                partial=True
            self.send_response(206 if partial else 200);self.send_header('Content-Type',mimetypes.guess_type(path)[0] or 'application/octet-stream');self.send_header('Accept-Ranges','bytes');self.send_header('ETag',etag);self.send_header('Content-Length',str(max(0,end-start+1)));self.send_header('Cache-Control','private, no-store')
            if partial:self.send_header('Content-Range',f'bytes {start}-{end}/{size}')
            self.end_headers()
            if self.command=='HEAD':return
            stream.seek(start);remaining=end-start+1
            while remaining>0:
                block=stream.read(min(256*1024,remaining))
                if not block:break
                self.wfile.write(block);remaining-=len(block)
        except (BrokenPipeError,ConnectionResetError):pass
        finally:stream.close()
    def do_POST(self):
        if not self.secure_request(mutation=True):return
        try:
            route=urlsplit(self.path).path;data=self.body()
            if route=='/api/login':
                token=data.get('token','')
                if not isinstance(token,str) or not hmac.compare_digest(token,self.server.broadcast_token):self.json({'error':'Invalid broadcast token'},401);return
                session=secrets.token_urlsafe(32);self.server.sessions[session]='viewer'
                self.json({'csrf':self.server.csrf,'role':'viewer'},headers={'Set-Cookie':f'skald_session={session}; HttpOnly; SameSite=Strict; Path=/'})
                return
            if not self.authorized(admin=route not in {'/api/progress','/api/play'},mutation=True):return
            if route=='/api/progress':self.json(self.public_media(self.core.progress(data['id'],data['position'],data['duration'],data.get('watched'))));return
            if route=='/api/metadata':self.json(self.core.correct_metadata(data['id'],{k:v for k,v in data.items() if k!='id'}));return
            if route=='/api/sources':self.json(self.core.add_source(data['name'],data['kind'],data['path']),201);return
            if route=='/api/storage':self.json(self.core.add_storage(data['name'],data['path'],data['role']),201);return
            if route=='/api/collections':self.json(self.core.save_collection(data['name'],data['media_ids']),201);return
            if route=='/api/tracking':self.json(self.core.track(data),201);return
            if route=='/api/discover':self.json({'candidates':self.core.discover(data['tracking_id'])});return
            if route=='/api/packs':self.json(self.core.save_pack(data),201);return
            if route=='/api/packs/preview':self.json(self.core.preview_pack(data['id']));return
            if route=='/api/packs/prepare':self.json(self.core.enqueue('pack',data),202);return
            if route=='/api/packs/reconcile':self.json(self.core.reconcile_pack(data['id'],data['progress']));return
            if route=='/api/review/resolve':self.json(self.core.resolve_review(data['id'],data['action']));return
            if route=='/api/settings':self.json({'settings':self.core.update_settings(data)});return
            if route=='/api/services/config':self.json(self.core.configure_service(data['id'],{k:v for k,v in data.items() if k!='id'}));return
            if route=='/api/backup':self.json(self.core.enqueue('backup',{}),202);return
            for operation in ('scan','prepare','archive','restore','acquire'):
                if route=='/api/'+operation:self.json(self.core.enqueue(operation,data),202);return
            if route=='/api/play':
                if data.get('player','web')=='web':self.json({'stream':'/api/media/'+data['id']+'/stream'});return
                if self.role()!='admin':raise ValueError('Remote playback uses Library Broadcast')
                path=self.core.playable(data['id'])
                if sys.platform=='darwin':args=['/usr/bin/open',str(path)]
                elif sys.platform.startswith('linux'):args=['xdg-open',str(path)]
                else:raise ValueError('Choose Web playback on this platform')
                subprocess.run(args,check=True,timeout=15);self.json({'handed_off':True});return
            self.json({'error':'Not found'},404)
        except (ValueError,KeyError,TypeError,OSError,sqlite3.Error,subprocess.SubprocessError) as exc:self.json({'error':str(exc)},400)
