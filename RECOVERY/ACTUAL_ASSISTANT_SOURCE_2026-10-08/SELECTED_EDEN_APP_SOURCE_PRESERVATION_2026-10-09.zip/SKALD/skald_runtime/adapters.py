"""Local media working-copy and explicit acquisition adapters."""
import base64
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
from urllib import request, error, parse


def normalize_candidate(uri):
    uri=str(uri)
    parsed=parse.urlsplit(uri)
    if parsed.scheme=='magnet':
        query=parse.parse_qs(parsed.query)
        if not any(re.fullmatch(r'urn:btih:(?:[a-fA-F0-9]{40}|[A-Z2-7a-z]{32})',x) for x in query.get('xt',[])):
            raise ValueError('Magnet requires a valid torrent info hash')
        return {'kind':'magnet','uri':uri,'title':query.get('dn',['Manual torrent'])[0]}
    path=Path(uri).expanduser()
    if not parsed.scheme and path.is_file() and path.suffix.lower()=='.torrent':
        return {'kind':'torrent','uri':str(path.resolve()),'title':path.stem}
    raise ValueError('Choose an existing torrent file or a magnet URI')


class MediaTools:
    def __init__(self,data_dir:Path):
        self.data_dir=Path(data_dir)
        self.ffmpeg=shutil.which('ffmpeg') or '/opt/homebrew/bin/ffmpeg'
        self.ffprobe=shutil.which('ffprobe') or '/opt/homebrew/bin/ffprobe'

    def capabilities(self):
        return [{'name':name,'available':bool(shutil.which(name) or Path(path).is_file()),'verification':'runtime-validation-required'} for name,path in [('ffmpeg',self.ffmpeg),('ffprobe',self.ffprobe),('transmission-daemon','/opt/homebrew/bin/transmission-daemon')]] + [{'name':'Subler','available':Path('/Applications/Subler.app').is_dir(),'verification':'manual-review','detail':'Installed GUI is not a verified command adapter'}]

    def _run(self,args):
        result=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=300)
        if result.returncode:
            raise RuntimeError('Media tool failed: '+result.stderr.decode(errors='replace')[-2000:])
        return result.stdout

    def inspect(self,path:Path):
        data=json.loads(self._run([self.ffprobe,'-v','error','-show_format','-show_streams','-of','json',str(path)]))
        fmt=data.get('format',{})
        if not data.get('streams'): raise RuntimeError('No media streams found')
        return {'duration':float(fmt.get('duration',0)), 'streams':data['streams'],'tags':fmt.get('tags',{}),'format':fmt}

    def prepare(self,source:Path,destination:Path,mode='direct',metadata=None):
        source=Path(source); destination=Path(destination)
        if mode not in ('direct','remux','transcode'): raise ValueError('Explicit direct, remux or transcode mode required')
        if mode=='direct' and metadata: raise ValueError('Metadata correction requires remux or transcode')
        if destination.exists(): raise FileExistsError(destination)
        self.inspect(source)
        destination.parent.mkdir(parents=True,exist_ok=True)
        fd,name=tempfile.mkstemp(prefix='.skald-',suffix=destination.suffix,dir=destination.parent); os.close(fd)
        staged=Path(name)
        try:
            if mode=='direct': shutil.copyfile(source,staged)
            else:
                args=[self.ffmpeg,'-v','error','-y','-i',str(source),'-map','0','-map_metadata','0']
                args += ['-c','copy'] if mode=='remux' else ['-c:v','libx264','-c:a','aac','-c:s','copy']
                for key,value in (metadata or {}).items():
                    if any(s in key.lower() for s in ('password','token','credential','secret')): raise ValueError('Credentials are not media metadata')
                    args += ['-metadata',f'{key}={value}']
                self._run(args+[str(staged)])
            info=self.inspect(staged)
            # Hard link publishes atomically without overwriting any existing target.
            os.link(staged,destination)
            info['format']['filename']=str(destination)
            return info
        finally: staged.unlink(missing_ok=True)

    def capture_artwork(self,path:Path,media_id:str):
        info=self.inspect(path)
        if not any(s.get('codec_type')=='video' for s in info['streams']): return None
        if not re.fullmatch(r'[A-Za-z0-9_-]+',media_id): raise ValueError('Invalid artwork identity')
        folder=self.data_dir/'artwork'; folder.mkdir(parents=True,exist_ok=True)
        dest=folder/(media_id+'.jpg')
        self._run([self.ffmpeg,'-v','error','-y','-i',str(path),'-frames:v','1',str(dest)])
        return dest


class TransmissionClient:
    def __init__(self,endpoint='http://127.0.0.1:9091/transmission/rpc',username=None,password=None,timeout=15):
        parsed=parse.urlsplit(endpoint)
        if parsed.scheme not in ('http','https') or parsed.username or parsed.password: raise ValueError('Use a HTTP endpoint and separate credentials')
        self.endpoint=endpoint; self.username=username; self.password=password; self.timeout=timeout; self.session_id=None

    def call(self,method,args=None):
        body=json.dumps({'method':method,'arguments':args or {}}).encode()
        for attempt in range(2):
            headers={'Content-Type':'application/json'}
            if self.session_id: headers['X-Transmission-Session-Id']=self.session_id
            if self.username is not None: headers['Authorization']='Basic '+base64.b64encode((self.username+':'+(self.password or '')).encode()).decode()
            req=request.Request(self.endpoint,data=body,headers=headers,method='POST')
            try:
                with request.urlopen(req,timeout=self.timeout) as response: result=json.load(response)
            except error.HTTPError as exc:
                if exc.code==409 and attempt==0 and exc.headers.get('X-Transmission-Session-Id'):
                    self.session_id=exc.headers['X-Transmission-Session-Id']; continue
                raise RuntimeError(f'Transmission HTTP failure ({exc.code})') from None
            except (error.URLError,TimeoutError): raise RuntimeError('Transmission connection failed or timed out') from None
            if result.get('result')!='success': raise RuntimeError('Transmission RPC request failed')
            return result.get('arguments',{})
        raise RuntimeError('Transmission session handshake failed')

    def add(self,uri,download_dir:Path):
        candidate=normalize_candidate(uri)
        args={'download-dir':str(Path(download_dir).resolve())}
        if candidate['kind']=='torrent': args['metainfo']=base64.b64encode(Path(candidate['uri']).read_bytes()).decode()
        else: args['filename']=candidate['uri']
        return self.call('torrent-add',args)

    def status(self,ids:list):
        return self.call('torrent-get',{'ids':ids,'fields':['id','name','status','percentDone','downloadDir','files','error','errorString']}).get('torrents',[])
