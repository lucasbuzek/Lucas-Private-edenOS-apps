"""Verified local delivery; bookkeeping belongs in the caller's app-data store.

Placement is atomic per file, not across a set. A process crash can leave verified
copies or exclusive staging files; sources remain until all copies verify. Moves
cannot atomically remove multiple source paths. Callers must journal/reconcile
interrupted moves, and must exclude concurrent writers to media directories.
"""
from pathlib import Path
import hashlib
import os
import stat
import tempfile

_SIDE_EXTENSIONS = {'.srt', '.ass', '.ssa', '.vtt', '.sub', '.idx', '.nfo', '.jpg', '.jpeg', '.png', '.webp', '.txt', '.cue', '.lrc'}


def _regular(path):
    path = Path(os.path.abspath(path))
    for component in (path, *path.parents):
        if component.is_symlink():
            raise ValueError(f'Symlinks are not supported: {component}')
    info = path.stat()
    if not stat.S_ISREG(info.st_mode):
        raise ValueError(f'Expected regular file: {path}')
    return path, info


def _signature(info):
    return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns)


def digest(path: Path) -> str:
    path, before = _regular(path)
    value = hashlib.sha256()
    fd = os.open(path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0))
    with os.fdopen(fd, 'rb') as stream:
        if _signature(os.fstat(stream.fileno())) != _signature(before):
            raise OSError(f'File changed before verification: {path}')
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
        if _signature(os.fstat(stream.fileno())) != _signature(before):
            raise OSError(f'File changed during verification: {path}')
    if _signature(path.stat()) != _signature(before):
        raise OSError(f'File changed during verification: {path}')
    return value.hexdigest()


def _sync_directory(path):
    fd = os.open(path, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def _deliver(source, destination, preserve_sidecars, move):
    source, _ = _regular(source)
    destination = Path(os.path.abspath(destination))
    if source == destination:
        raise ValueError('Source and destination must differ')
    for component in (destination, *destination.parents):
        if component.is_symlink():
            raise ValueError(f'Symlinks are not supported: {component}')
    if not destination.parent.is_dir():
        raise NotADirectoryError(f'Destination directory must exist: {destination.parent}')
    pairs = [(source, destination)]
    if preserve_sidecars:
        prefix = source.stem + '.'
        for candidate in sorted(source.parent.iterdir()):
            if candidate != source and candidate.name.startswith(prefix) and candidate.suffix.lower() in _SIDE_EXTENSIONS:
                _regular(candidate)
                pairs.append((candidate, destination.parent / (destination.stem + candidate.name[len(source.stem):])))
    records = []
    snapshots = {}
    staged = []
    placed = []
    try:
        for origin, target in pairs:
            _, info = _regular(origin)
            checksum = digest(origin)
            snapshots[origin] = _signature(info)
            if target.exists():
                if os.path.samefile(origin, target):
                    raise ValueError('Source and destination reference the same file')
                if digest(target) != checksum:
                    raise FileExistsError(f'Destination differs: {target}')
            records.append({'source': str(origin), 'destination': str(target), 'sha256': checksum, 'size': info.st_size})
        for record in records:
            target = Path(record['destination'])
            if target.exists():
                continue
            fd, temporary = tempfile.mkstemp(prefix='.skald-transfer-', dir=target.parent)
            temporary = Path(temporary)
            staged.append(temporary)
            origin = Path(record['source'])
            source_fd = os.open(origin, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0))
            with os.fdopen(fd, 'wb') as output, os.fdopen(source_fd, 'rb') as input_file:
                if _signature(os.fstat(input_file.fileno())) != snapshots[origin]:
                    raise OSError(f'Source changed: {origin}')
                for block in iter(lambda: input_file.read(1024 * 1024), b''):
                    output.write(block)
                output.flush()
                os.fsync(output.fileno())
            if digest(temporary) != record['sha256']:
                raise OSError(f'Copy verification failed: {origin}')
            # Hard-link publication is atomic and refuses any existing path.
            os.link(temporary, target)
            placed.append((target, target.stat().st_ino, record['sha256']))
            _sync_directory(target.parent)
        for record in records:
            origin, target = Path(record['source']), Path(record['destination'])
            if _signature(origin.stat()) != snapshots[origin] or digest(origin) != record['sha256']:
                raise OSError(f'Source changed: {origin}')
            if digest(target) != record['sha256']:
                raise OSError(f'Destination verification failed: {target}')
    except BaseException:
        for target, inode, checksum in reversed(placed):
            try:
                if target.exists() and not target.is_symlink() and target.stat().st_ino == inode and digest(target) == checksum:
                    target.unlink()
            except (OSError, ValueError):
                # Preserve a concurrently changed path; retain original failure.
                pass
        raise
    finally:
        for temporary in staged:
            temporary.unlink(missing_ok=True)
    if move:
        # Once removal begins retain all verified destinations even on error.
        for record in records:
            origin = Path(record['source'])
            if _signature(origin.stat()) != snapshots[origin]:
                raise OSError(f'Source changed before removal: {origin}; verified copies retained')
            origin.unlink()
            _sync_directory(origin.parent)
    result = records[0]
    result['sidecars'] = records[1:]
    return result


def verified_copy(source: Path, destination: Path, preserve_sidecars=True) -> dict:
    return _deliver(source, destination, preserve_sidecars, False)


def verified_move(source: Path, destination: Path, preserve_sidecars=True) -> dict:
    return _deliver(source, destination, preserve_sidecars, True)
