"""Reversible hosting of the one SKALD runtime; newly implemented, not recovered.

A HostDriver hosts the existing entry point and data directory. It never imports
or reimplements the media domain. Health-check loss alone is not proof that the
old runtime stopped: process evidence and the runtime's exclusive lock govern
retake. Unowned processes are attached to, never signalled by this controller.
"""
from __future__ import annotations

from contextlib import contextmanager
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time
from typing import Protocol
from urllib.parse import urlparse
from urllib.request import Request, urlopen

from . import VERSION

CONTRACT_NAME = 'skald-runtime-host'
CONTRACT_VERSION = 1


def compatible_contract(response):
    contract = response.get('hosting', {}) if isinstance(response, dict) else {}
    return (contract.get('name') == CONTRACT_NAME and
            contract.get('version') == CONTRACT_VERSION and
            all(contract.get(field) is True for field in
                ('ready', 'same_entry', 'same_data_dir', 'exclusive_owner')))


class HostDriver(Protocol):
    def probe(self) -> dict: ...
    def prepare(self, entry: Path, data_dir: Path) -> bool: ...
    def start(self, entry: Path, data_dir: Path) -> dict: ...
    def status(self) -> dict | None: ...
    def stop(self) -> None: ...


class BifrostDriver:
    """Opt-in HTTP adapter. Ordinary BIFROST /api/status is not compatibility.

    The host must advertise a versioned skald_hosting contract with relative
    prepare/start/status/stop operation URLs. No guessed API route is called.
    Current recovered BIFROST source has no such advertised contract.
    """
    def __init__(self, endpoint: str, token: str, timeout: float = 3):
        parsed = urlparse(endpoint)
        if parsed.scheme not in ('http', 'https') or not parsed.netloc:
            raise ValueError('A host HTTP endpoint is required')
        self.endpoint = endpoint.rstrip('/')
        self.token = token
        self.timeout = timeout
        self.operations = {}

    def _request(self, path, data=None):
        if not isinstance(path, str) or not path.startswith('/') or path.startswith('//'):
            raise RuntimeError('Host operation must be a same-origin absolute path')
        request = Request(self.endpoint + path,
                          data=None if data is None else json.dumps(data).encode(),
                          headers={'X-EDEN-Token': self.token, 'Content-Type': 'application/json'})
        with urlopen(request, timeout=self.timeout) as response:
            return json.load(response)

    def probe(self):
        self.operations = {}
        try:
            status = self._request('/api/status')
        except (OSError, ValueError) as exc:
            return {'compatible': False, 'available': False,
                    'reason': 'Host status unavailable: ' + str(exc)}
        contract = status.get('skald_hosting', {})
        result = {'hosting': contract, 'available': True, 'compatible': False,
                  'reason': 'Host does not advertise the required SKALD hosting contract'}
        operations = contract.get('operations', {})
        if compatible_contract(result) and all(
                isinstance(operations.get(key), str) and operations[key].startswith('/') and
                not operations[key].startswith('//') for key in ('prepare', 'start', 'status', 'stop')):
            self.operations = dict(operations)
            result.update(compatible=True, reason='Compatible explicit SKALD hosting contract')
        return result

    def _operation(self, name, data=None):
        if name not in self.operations:
            raise RuntimeError('No compatible explicit SKALD hosting contract')
        return self._request(self.operations[name], data)

    def prepare(self, entry, data_dir):
        if not self.probe()['compatible']:
            return False
        response = self._operation('prepare', {'entry': str(entry), 'data_dir': str(data_dir)})
        return response.get('ready') is True

    def start(self, entry, data_dir):
        response = self._operation('start', {'entry': str(entry), 'data_dir': str(data_dir)})
        return response.get('runtime', response)

    def status(self):
        response = self._operation('status')
        return response.get('runtime')

    def stop(self):
        self._operation('stop', {})


def _lock(stream):
    if os.name == 'nt':
        import msvcrt
        stream.seek(0, os.SEEK_END)
        if stream.tell() == 0:
            stream.write(b'0'); stream.flush()
        stream.seek(0)
        msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
    else:
        import fcntl
        fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)


def _unlock(stream):
    if os.name == 'nt':
        import msvcrt
        stream.seek(0)
        msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
    else:
        import fcntl
        fcntl.flock(stream, fcntl.LOCK_UN)


def _pid_alive(pid):
    try:
        if not isinstance(pid, int) or pid <= 0:
            return False
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True


class HostingController:
    def __init__(self, entry: Path, data_dir: Path, driver: HostDriver | None = None,
                 port: int = 0, timeout: float = 12):
        self.entry = Path(entry).expanduser().resolve(strict=True)
        self.data_dir = Path(data_dir).expanduser().resolve()
        self.data_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.driver = driver
        self.port = port
        self.timeout = timeout
        self.child = None
        self.runtime = None
        self.mode = 'stopped'
        self.closed = False
        self.mutex = threading.RLock()
        self.coordinator = (self.data_dir / 'hosting.lock').open('a+b')
        try:
            _lock(self.coordinator)
        except OSError as exc:
            self.coordinator.close()
            raise RuntimeError('Another hosting coordinator already owns transitions for this data') from exc

    def _check_open(self):
        if self.closed:
            raise RuntimeError('Hosting coordinator is closed')

    def _owner_busy(self):
        with (self.data_dir / 'runtime.lock').open('a+b') as stream:
            try:
                _lock(stream)
            except OSError:
                return True
            _unlock(stream)
            return False

    def _disk_state(self):
        try:
            state = json.loads((self.data_dir / 'runtime.json').read_text())
            if (state.get('version') != VERSION or
                    Path(state['data_dir']).resolve() != self.data_dir or
                    not isinstance(state['pid'], int) or state['pid'] <= 0):
                return None
            url = urlparse(state['url'])
            if url.scheme != 'http' or url.hostname not in ('127.0.0.1', 'localhost'):
                return None
            return state
        except (OSError, ValueError, KeyError, TypeError):
            return None

    def _healthy(self, state):
        if not state:
            return False
        try:
            token = (self.data_dir / 'broadcast-token').read_text().strip()
            request = Request(state['url'] + '/api/status',
                              headers={'Authorization': 'Bearer ' + token})
            with urlopen(request, timeout=1) as response:
                result = json.load(response)
            return result.get('version') == VERSION and result.get('runtime') == 'persistent'
        except (OSError, ValueError):
            return False

    def _live(self, state):
        if self.child and state and state['pid'] == self.child.pid:
            if self.child.poll() is not None:
                return False
        return bool(state and _pid_alive(state['pid']) and self._owner_busy())

    def _snapshot(self, degraded=False, reason=None):
        result = {'mode': self.mode, 'runtime': dict(self.runtime) if self.runtime else None,
                  'degraded': degraded, 'provenance': 'new implementation; no recovered host contract'}
        if reason:
            result['reason'] = reason
        return result

    def _wait_ready(self, expected_pid=None):
        until = time.monotonic() + self.timeout
        while time.monotonic() < until:
            state = self._disk_state()
            if (state and (expected_pid is None or state['pid'] == expected_pid) and
                    self._live(state) and self._healthy(state)):
                return state
            if self.child and expected_pid == self.child.pid and self.child.poll() is not None:
                raise RuntimeError('Standalone runtime exited before becoming ready; inspect hosting-runtime.log')
            time.sleep(.025)
        raise RuntimeError('Runtime readiness timed out')

    def _require_vacant(self):
        if self._owner_busy():
            raise RuntimeError('Previous runtime still owns the data; refusing duplicate runtime or unsafe retake')
        if self.runtime and _pid_alive(self.runtime['pid']):
            raise RuntimeError('Previous runtime process still alive; refusing unsafe retake')

    def _launch_standalone(self):
        self._require_vacant()
        with (self.data_dir / 'hosting-runtime.log').open('ab') as log:
            self.child = subprocess.Popen(
                [sys.executable, str(self.entry), '--data-dir', str(self.data_dir),
                 '--host', '127.0.0.1', '--port', str(self.port)],
                stdin=subprocess.DEVNULL, stdout=log, stderr=log, start_new_session=True)
        try:
            self.runtime = self._wait_ready(self.child.pid)
            self.mode = 'standalone'
            return self._snapshot()
        except Exception:
            self._stop_child()
            raise

    def _stop_child(self):
        if self.child:
            if self.child.poll() is None:
                self.child.terminate()
                try:
                    self.child.wait(timeout=self.timeout)
                except subprocess.TimeoutExpired as exc:
                    # No forced kill: a slow worker might own an in-flight verified write.
                    raise RuntimeError('Runtime did not stop; refusing unsafe handoff') from exc
            self.child = None

    def ensure_standalone(self):
        with self.mutex:
            self._check_open()
            if self.mode == 'shared':
                return self.retake()
            state = self._disk_state()
            if self._live(state):
                self.runtime = state
                if not self.child or self.child.pid != state['pid']:
                    self.mode = 'external'
                return self._snapshot(degraded=not self._healthy(state))
            self._stop_child()
            self.runtime = state
            return self._launch_standalone()

    def delegate(self):
        with self.mutex:
            self._check_open()
            if not self.driver:
                raise RuntimeError('No compatible shared-host driver is configured')
            response = self.driver.probe()
            if not compatible_contract(response) or response.get('compatible') is False:
                raise RuntimeError('Shared host is not compatible with the explicit SKALD hosting contract')
            if self.mode == 'shared' and self._live(self.runtime):
                return self._snapshot()
            self.ensure_standalone()
            if self.mode == 'external':
                raise RuntimeError('Runtime is externally owned; refuse to stop an unowned process')
            if self.driver.prepare(self.entry, self.data_dir) is not True:
                raise RuntimeError('Compatible host is not ready to own the runtime launch')
            self._stop_child()
            self._require_vacant()
            self.mode = 'stopped'
            try:
                launched = self.driver.start(self.entry, self.data_dir)
                self.runtime = self._wait_ready(launched.get('pid'))
                if self.runtime['pid'] != launched.get('pid'):
                    raise RuntimeError('Shared host readiness identifies the wrong runtime process')
                self.mode = 'shared'
                return self._snapshot()
            except Exception:
                # A failed host may still own a live service. Require an explicit stop
                # and actual vacancy before recovery; never infer death from HTTP loss.
                self.driver.stop()
                state = self._disk_state()
                if state:
                    self.runtime = state
                self._launch_standalone()
                raise

    def retake(self):
        with self.mutex:
            self._check_open()
            if self.mode == 'external':
                raise RuntimeError('Runtime is externally owned; an unowned process cannot be stopped')
            if self.mode != 'shared':
                return self.ensure_standalone()
            state = self._disk_state() or self.runtime
            if self._live(state):
                if not self.driver:
                    raise RuntimeError('Host runtime is still alive; retake requires verified host stop')
                self.driver.stop()
            self._require_vacant()
            self.mode = 'stopped'
            return self._launch_standalone()

    def poll(self):
        with self.mutex:
            self._check_open()
            state = self._disk_state() or self.runtime
            if self.mode == 'shared':
                try:
                    response = self.driver.probe()
                    host_ok = compatible_contract(response) and response.get('compatible') is not False
                except (OSError, RuntimeError):
                    host_ok = False
                if self._live(state):
                    self.runtime = state
                    return self._snapshot(degraded=not host_ok or not self._healthy(state),
                                          reason=None if host_ok else 'Host unavailable; existing runtime is still alive')
                if self._owner_busy():
                    return self._snapshot(degraded=True, reason='Runtime lock remains owned; retake blocked')
                self._require_vacant()
                self.mode = 'stopped'
                return self._launch_standalone()
            return self.ensure_standalone()

    def close(self):
        """Deliberate all-stop for runtime processes this controller actually owns."""
        with self.mutex:
            if self.closed:
                return
            if self.mode == 'shared' and self.driver:
                self.driver.stop()
                self._require_vacant()
            self._stop_child()
            self.runtime = None
            self.mode = 'stopped'
            _unlock(self.coordinator)
            self.coordinator.close()
            self.closed = True
