"""Persistent SKALD media domain. Historical envelope reconstruction, new bytes."""
from __future__ import annotations
from contextlib import contextmanager, nullcontext
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import sqlite3
import threading
import time
import uuid

from storage import LOCAL_STORAGE
from . import VERSION

VIDEO = {'.mp4','.m4v','.mkv','.mov','.avi','.webm','.ts','.m2ts','.mpeg','.mpg'}
AUDIO = {'.mp3','.m4a','.flac','.wav','.aac','.aiff','.ogg','.opus','.alac'}
WRITE_JOBS = {'prepare','pack','archive','restore','acquire'}
PRESETS = ['weekend','getaway','couples retreat','holiday','vacation','road trip','custom']

def now(): return datetime.now(timezone.utc).isoformat(timespec='microseconds')
def uid(): return uuid.uuid4().hex
def fingerprint(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''): value.update(block)
    return value.hexdigest()
def canonical(path, directory=False):
    if not isinstance(path,(str,Path)) or not str(path).strip(): raise ValueError('A location is required')
    result = Path(path).expanduser().resolve(strict=True)
    if directory and not result.is_dir(): raise ValueError('Choose a folder')
    return result

def infer(path):
    text = path.stem.replace('.', ' ').replace('_',' ')
    episode = re.search(r'(?i)(.*?)\bs(\d{1,2})e(\d{1,3})\b',text)
    year = re.search(r'\b((?:19|20)\d{2})\b',text)
    if path.suffix.lower() in AUDIO: kind,series,season,number = 'music',None,None,None
    elif episode:
        kind,series,season,number='tv',episode[1].strip(' -'),int(episode[2]),int(episode[3])
        text = f'{series} · S{season:02} E{number:02}'
    else: kind,series,season,number='movie',None,None,None
    text = re.split(r'(?i)\b(?:1080p|2160p|720p|bluray|webrip|web-dl|x264|x265|h264|h265)\b',text)[0]
    return {'title':text.strip(' -()[]') or path.stem,'kind':kind,'year':int(year[1]) if year else None,'series':series,'season':season,'episode':number}

class Runtime:
    def __init__(self, data_dir, start_workers=False):
        self.data_dir = Path(data_dir).expanduser().resolve()
        self.data_dir.mkdir(parents=True,exist_ok=True,mode=0o700)
        self.db_path=self.data_dir/'skald.sqlite3'
        self.stop_event=threading.Event();self.wake=threading.Event();self.worker=None
        self.run_lock=threading.Lock();self._tools=None
        self.initialize()
        if start_workers:self.start()
    @contextmanager
    def db(self):
        db=sqlite3.connect(self.db_path, timeout=30)
        db.row_factory=sqlite3.Row
        db.execute('PRAGMA foreign_keys=ON')
        try:
            yield db
            db.commit()
        except BaseException:
            db.rollback();raise
        finally:db.close()
    def initialize(self):
        with self.db() as db:
            db.execute('PRAGMA journal_mode=WAL')
            db.executescript('''
            CREATE TABLE IF NOT EXISTS media(id TEXT PRIMARY KEY,title TEXT NOT NULL,kind TEXT NOT NULL,year INTEGER,series TEXT,season INTEGER,episode INTEGER,summary TEXT NOT NULL DEFAULT '',duration REAL NOT NULL DEFAULT 0,position REAL NOT NULL DEFAULT 0,watched INTEGER NOT NULL DEFAULT 0,ready INTEGER NOT NULL DEFAULT 0,artwork TEXT,metadata TEXT NOT NULL DEFAULT '{}',created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS sources(id TEXT PRIMARY KEY,name TEXT NOT NULL,kind TEXT NOT NULL,path TEXT NOT NULL UNIQUE,config TEXT NOT NULL DEFAULT '{}');
            CREATE TABLE IF NOT EXISTS storage(id TEXT PRIMARY KEY,name TEXT NOT NULL,path TEXT NOT NULL UNIQUE,role TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS locations(id TEXT PRIMARY KEY,media_id TEXT NOT NULL REFERENCES media(id),source_id TEXT REFERENCES sources(id),storage_id TEXT REFERENCES storage(id),path TEXT NOT NULL UNIQUE,sha256 TEXT NOT NULL,size INTEGER NOT NULL,available INTEGER NOT NULL DEFAULT 1,role TEXT NOT NULL DEFAULT 'library',verified_at TEXT NOT NULL);
            CREATE INDEX IF NOT EXISTS locations_content ON locations(sha256);
            CREATE TABLE IF NOT EXISTS collections(id TEXT PRIMARY KEY,name TEXT NOT NULL,media_ids TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS tracking(id TEXT PRIMARY KEY,title TEXT NOT NULL,kind TEXT NOT NULL,series TEXT,season INTEGER,episode INTEGER,release_at TEXT,source_id TEXT,query TEXT,state TEXT NOT NULL,media_id TEXT,config TEXT NOT NULL DEFAULT '{}',updated_at TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY,kind TEXT NOT NULL,payload TEXT NOT NULL,state TEXT NOT NULL,stage TEXT NOT NULL,result TEXT,error TEXT,created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS review(id TEXT PRIMARY KEY,job_id TEXT,media_id TEXT,title TEXT NOT NULL,error TEXT NOT NULL,resolved INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS packs(id TEXT PRIMARY KEY,name TEXT NOT NULL,context TEXT NOT NULL,target_storage_id TEXT NOT NULL,media_ids TEXT NOT NULL,max_bytes INTEGER,max_titles INTEGER,quality TEXT NOT NULL,state TEXT NOT NULL DEFAULT 'DEFINED',receipt TEXT,updated_at TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS operations(id TEXT PRIMARY KEY,job_id TEXT NOT NULL,action TEXT NOT NULL,media_id TEXT NOT NULL,source TEXT NOT NULL,destination TEXT NOT NULL,sha256 TEXT NOT NULL,state TEXT NOT NULL,receipt TEXT);
            CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS services(id TEXT PRIMARY KEY,config TEXT NOT NULL);
            ''')
            defaults={'automation_paused':False,'profile':'RECOMMENDED','subtitle_languages':['en','sk','cs'],'scan_interval':300,'library_broadcast':True}
            for key,value in defaults.items():db.execute('INSERT OR IGNORE INTO settings VALUES(?,?)',(key,json.dumps(value)))
            db.execute("UPDATE jobs SET state='QUEUED',stage='RECOVERING',updated_at=? WHERE state='RUNNING'",(now(),))
            if db.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise ValueError('SKALD database integrity failed')
    @property
    def tools(self):
        if self._tools is None:
            from .adapters import MediaTools
            self._tools=MediaTools(self.data_dir)
        return self._tools
    def start(self):
        if self.worker and self.worker.is_alive():return
        self.stop_event.clear()
        self.worker=threading.Thread(target=self._worker,name='SKALD-runtime',daemon=True);self.worker.start()
    def close(self):
        self.stop_event.set();self.wake.set()
        if self.worker and self.worker is not threading.current_thread():self.worker.join(timeout=30)
    def _worker(self):
        last=0
        while not self.stop_event.is_set():
            if self.run_next():continue
            if time.monotonic()-last>5 and not self.settings()['automation_paused']:
                try:self.automation_tick()
                except Exception as exc:self.add_review('Automation needs attention',str(exc))
                last=time.monotonic()
            self.wake.wait(1);self.wake.clear()
    def settings(self):
        with self.db() as db:return {r['key']:json.loads(r['value']) for r in db.execute('SELECT * FROM settings')}
    def update_settings(self,values):
        allowed={'automation_paused','profile','subtitle_languages','scan_interval','library_broadcast'}
        if set(values)-allowed:raise ValueError('Unsupported setting')
        if 'profile' in values and values['profile'] not in {'LEAN','RECOMMENDED','FULL','CUSTOM'}:raise ValueError('Invalid installer profile')
        for key in ('automation_paused','library_broadcast'):
            if key in values and type(values[key]) is not bool:raise ValueError(key+' must be boolean')
        if 'subtitle_languages' in values and (not isinstance(values['subtitle_languages'],list) or any(not isinstance(v,str) or not re.fullmatch('[a-z]{2,3}',v) for v in values['subtitle_languages'])):raise ValueError('Invalid subtitle language list')
        if 'scan_interval' in values and (type(values['scan_interval']) is not int or not 30<=values['scan_interval']<=86400):raise ValueError('Scan interval must be 30–86400 seconds')
        with self.db() as db:
            for k,v in values.items():db.execute('INSERT OR REPLACE INTO settings VALUES(?,?)',(k,json.dumps(v)))
        self.wake.set();return self.settings()
    def add_source(self,name,kind,path,config=None):
        if not isinstance(name,str) or not name.strip():raise ValueError('Name is required')
        if kind!='local':raise ValueError('This source adapter must be configured before use')
        path=canonical(path,True)
        with self.db() as db:
            old=db.execute('SELECT id FROM sources WHERE path=?',(str(path),)).fetchone();identifier=old['id'] if old else uid()
            db.execute('INSERT OR REPLACE INTO sources VALUES(?,?,?,?,?)',(identifier,name.strip(),kind,str(path),json.dumps(config or {})))
        return {'id':identifier,'name':name,'kind':kind,'path':str(path)}
    def sources(self):
        with self.db() as db:return [dict(r)|{'available':Path(r['path']).is_dir()} for r in db.execute('SELECT id,name,kind,path FROM sources')]
    def add_storage(self,name,path,role):
        if role not in {'library','archive','device','inbox'}:raise ValueError('Invalid storage role')
        if not isinstance(name,str) or not name.strip():raise ValueError('Name is required')
        path=canonical(path,True)
        if path==self.data_dir or path.is_relative_to(self.data_dir):raise ValueError('Media storage must be separate from app operational data')
        with self.db() as db:
            old=db.execute('SELECT id FROM storage WHERE path=?',(str(path),)).fetchone();identifier=old['id'] if old else uid()
            db.execute('INSERT OR REPLACE INTO storage VALUES(?,?,?,?)',(identifier,name.strip(),str(path),role))
        return {'id':identifier,'name':name.strip(),'path':str(path),'role':role}
    def storages(self):
        with self.db() as db:rows=[dict(r) for r in db.execute('SELECT * FROM storage')]
        for row in rows:
            row['available']=Path(row['path']).is_dir()
            try:row['free_bytes']=shutil.disk_usage(row['path']).free
            except OSError:row['free_bytes']=None
        return rows
    def storage(self,identifier,roles=None):
        with self.db() as db:row=db.execute('SELECT * FROM storage WHERE id=?',(identifier,)).fetchone()
        if not row or (roles and row['role'] not in roles):raise ValueError('Choose a configured destination with the appropriate storage role')
        return dict(row)|{'path':canonical(row['path'],True)}
    def register(self,path,source_id=None,storage_id=None,media_id=None,inspection=None,ready=False,role='library',_db=None,_sha=None):
        path=canonical(path);info=LOCAL_STORAGE.inspect(path);sha=_sha or fingerprint(path);facts=infer(path)
        with (self.db() if _db is None else nullcontext(_db)) as db:
            if media_id:
                if not db.execute('SELECT id FROM media WHERE id=?',(media_id,)).fetchone():raise ValueError('Unknown replacement identity')
            else:
                match=db.execute('SELECT media_id FROM locations WHERE sha256=? LIMIT 1',(sha,)).fetchone()
                media_id=match['media_id'] if match else uid()
            if not db.execute('SELECT id FROM media WHERE id=?',(media_id,)).fetchone():
                db.execute('INSERT INTO media(id,title,kind,year,series,season,episode,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)',(media_id,facts['title'],facts['kind'],facts['year'],facts['series'],facts['season'],facts['episode'],now(),now()))
                tags=(inspection or {}).get('tags',{})
                title=tags.get('title') or tags.get('TITLE')
                if title:db.execute('UPDATE media SET title=? WHERE id=?',(str(title),media_id))

            location=db.execute('SELECT id FROM locations WHERE path=?',(str(path),)).fetchone()
            db.execute('''INSERT INTO locations VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(path) DO UPDATE SET media_id=excluded.media_id,sha256=excluded.sha256,size=excluded.size,available=1,verified_at=excluded.verified_at,role=excluded.role,storage_id=COALESCE(excluded.storage_id,locations.storage_id),source_id=COALESCE(excluded.source_id,locations.source_id)''',(location['id'] if location else uid(),media_id,source_id,storage_id,str(path),sha,info.size,1,role,now()))
            if inspection:
                duration=float(inspection.get('duration') or 0)
                db.execute('UPDATE media SET duration=?,metadata=?,ready=MAX(ready,?),updated_at=? WHERE id=?',(duration,json.dumps(inspection),int(ready),now(),media_id))
            elif ready:db.execute('UPDATE media SET ready=1,updated_at=? WHERE id=?',(now(),media_id))
        return self.media(media_id) if _db is None else {"id":media_id}
    def scan(self,source_id):
        with self.db() as db:source=db.execute('SELECT * FROM sources WHERE id=?',(source_id,)).fetchone()
        if not source:raise ValueError('Unknown media source')
        base=canonical(source['path'],True)
        records=LOCAL_STORAGE.inventory(base,VIDEO|AUDIO)
        prepared=[]
        for record in records:
            sha=fingerprint(record.path);inspection=None;artwork=None
            try:
                inspection=self.tools.inspect(record.path)
                artwork=self.data_dir/'artwork'/(sha+'.jpg')
                if not artwork.exists():artwork=self.tools.capture_artwork(record.path,sha)
            except (RuntimeError,OSError,ValueError):
                # Retain a discovered identity even when it needs processing; it is not READY.
                artwork=None
            if record.path.stat().st_size!=record.size or record.path.stat().st_mtime!=record.modified:raise OSError('Media changed during inventory; previous snapshot retained')
            prepared.append((record,sha,inspection,artwork))
        with self.db() as db:
            for row in db.execute('SELECT id,path FROM locations').fetchall():
                if Path(row['path']).is_relative_to(base):db.execute('UPDATE locations SET available=0 WHERE id=?',(row['id'],))
            result=[]
            for record,sha,inspection,artwork in prepared:
                item=self.register(record.path,source_id=source_id,inspection=inspection,ready=bool(inspection),_db=db,_sha=sha)
                if artwork:db.execute('UPDATE media SET artwork=? WHERE id=?',(str(artwork),item['id']))
                result.append(item['id'])
        return {'indexed':len(records),'media_ids':list(dict.fromkeys(result))}
    def _item(self,row,locations):
        item=dict(row);item['watched']=bool(item['watched']);item['metadata']=json.loads(item['metadata'])
        usable=[l for l in locations if l['available'] and Path(l['path']).is_file()]
        item['offline']=not bool(usable);item['ready']=bool(item['ready'] and usable)
        item['artwork']='/api/artwork/'+item['id'] if item['artwork'] and Path(item['artwork']).is_file() else None
        item['locations']=locations
        return item
    def library(self,kind='all',q=''):
        if kind not in {'all','movie','tv','music'}:raise ValueError('Invalid media domain')
        with self.db() as db:
            rows=db.execute("SELECT * FROM media WHERE (?='all' OR kind=?) ORDER BY title COLLATE NOCASE",(kind,kind)).fetchall()
            locations=[dict(r) for r in db.execute('SELECT * FROM locations')]
        result=[]
        for row in rows:
            if q.casefold() not in (row['title']+' '+(row['series'] or '')+' '+row['summary']).casefold():continue
            item=self._item(row,[r for r in locations if r['media_id']==row['id']]);result.append(item)
        return {'items':result}
    def media(self,identifier):
        with self.db() as db:
            row=db.execute('SELECT * FROM media WHERE id=?',(identifier,)).fetchone()
            locations=[dict(r) for r in db.execute('SELECT * FROM locations WHERE media_id=? ORDER BY verified_at DESC',(identifier,))]
        if not row:raise ValueError('Unknown library title')
        return self._item(row,locations)
    def playable(self,identifier):
        item=self.media(identifier)
        for location in sorted(item['locations'],key=lambda l:l['role']=='archive'):
            if location['available']:
                try:return LOCAL_STORAGE.inspect(Path(location['path'])).path
                except OSError:pass
        raise FileNotFoundError('This title is offline; reconnect its storage or restore it')
    def progress(self,identifier,position,duration,watched=None):
        for value in (position,duration):
            if type(value) not in {int,float} or not 0<=value<=10**12 or not math.isfinite(value):raise ValueError('Invalid playback position')
        if position>duration:raise ValueError('Playback position exceeds duration')
        if watched is not None and type(watched) is not bool:raise ValueError('watched must be a boolean')
        self.media(identifier)
        with self.db() as db:
            db.execute('UPDATE media SET position=?,duration=?,watched=COALESCE(?,watched),updated_at=? WHERE id=?',(position,duration,None if watched is None else int(watched),now(),identifier))
            if watched:db.execute("UPDATE tracking SET state='WATCHED',updated_at=? WHERE media_id=?",(now(),identifier))
        return self.media(identifier)
    def correct_metadata(self,identifier,values):
        allowed={'title','kind','year','series','season','episode','summary'}
        if set(values)-allowed:raise ValueError('Unsupported metadata field')
        if 'title' in values and (not isinstance(values['title'],str) or not values['title'].strip()):raise ValueError('A title is required')
        if 'kind' in values and values['kind'] not in {'movie','tv','music'}:raise ValueError('Invalid media kind')
        for k in ('year','season','episode'):
            if values.get(k) is not None and (type(values[k]) is not int or not 0<=values[k]<=9999):raise ValueError('Invalid '+k)
        for k in ('series','summary'):
            if k in values and values[k] is not None and not isinstance(values[k],str):raise ValueError('Invalid '+k)
        self.media(identifier)
        if values:
            with self.db() as db:db.execute('UPDATE media SET '+','.join(k+'=?' for k in values)+',updated_at=? WHERE id=?',(*values.values(),now(),identifier))
        return self.media(identifier)
    def home(self):
        items=self.library()['items'];tracking=self.tracking()
        continuing=sorted((i for i in items if i['position']>0 and not i['watched']),key=lambda i:i['updated_at'],reverse=True)
        next_up=[];series_seen=set()
        for i in sorted((i for i in items if i['kind']=='tv' and not i['watched']),key=lambda i:(i['series'] or i['title'],i['season'] or 0,i['episode'] or 0)):
            key=i['series'] or i['title']
            if key not in series_seen:next_up.append(i);series_seen.add(key)
        return {'continue_watching':continuing,'next_up':next_up,'ready_to_watch':[i for i in items if i['ready'] and not i['watched']], 'recent':sorted(items,key=lambda i:i['created_at'],reverse=True)[:24], 'movies':[i for i in items if i['kind']=='movie'][:16], 'tv':[i for i in items if i['kind']=='tv'][:16], 'music':[i for i in items if i['kind']=='music'][:16], 'upcoming':[t for t in tracking if t['state'] in {'EXPECTED','RELEASED','AVAILABLE'}], 'attention':self.reviews()}
    def save_collection(self,name,media_ids):
        if not isinstance(name,str) or not name.strip():raise ValueError('Name a collection')
        if not isinstance(media_ids,list) or len(media_ids)>10000:raise ValueError('Invalid collection selection')
        for identifier in media_ids:self.media(identifier)
        identifier=uid()
        with self.db() as db:db.execute('INSERT INTO collections VALUES(?,?,?)',(identifier,name.strip(),json.dumps(list(dict.fromkeys(media_ids)))))
        return {'id':identifier,'name':name.strip(),'media_ids':media_ids}
    def collections(self):
        with self.db() as db:return [dict(r)|{'media_ids':json.loads(r['media_ids'])} for r in db.execute('SELECT * FROM collections')]
    def track(self,values):
        if values.get('kind') not in {'movie','tv','music'} or not isinstance(values.get('title'),str) or not values['title'].strip():raise ValueError('A title and media domain are required')
        release=values.get('release_at');future=False
        if release:
            parsed=datetime.fromisoformat(release.replace('Z','+00:00'))
            if parsed.tzinfo is None:raise ValueError('Release time needs a timezone')
            future=parsed>datetime.now(timezone.utc)
        identifier=uid();state='EXPECTED' if future else 'RELEASED'
        config={k:values[k] for k in ('auto_prepare','storage_id','mode') if k in values}
        if config.get('auto_prepare') and values.get('confirmed') is not True:raise ValueError('Authorize automatic preparation to a configured destination')
        with self.db() as db:db.execute('INSERT INTO tracking VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',(identifier,values['title'],values['kind'],values.get('series'),values.get('season'),values.get('episode'),release,values.get('source_id'),values.get('query') or values['title'],state,None,json.dumps(config),now()))
        return next(t for t in self.tracking() if t['id']==identifier)
    def tracking(self):
        with self.db() as db:return [dict(r)|{'config':json.loads(r['config'])} for r in db.execute('SELECT * FROM tracking ORDER BY updated_at DESC')]
    def tracking_state(self,identifier,state,media_id=None):
        with self.db() as db:db.execute('UPDATE tracking SET state=?,media_id=COALESCE(?,media_id),updated_at=? WHERE id=?',(state,media_id,now(),identifier))
    def add_review(self,title,error,job_id=None,media_id=None):
        identifier=uid()
        with self.db() as db:db.execute('INSERT INTO review VALUES(?,?,?,?,?,?,?)',(identifier,job_id,media_id,title,str(error),0,now()))
        return identifier
    def reviews(self):
        with self.db() as db:return [dict(r) for r in db.execute('SELECT * FROM review WHERE resolved=0 ORDER BY created_at DESC')]
    def resolve_review(self,identifier,action):
        with self.db() as db:
            row=db.execute('SELECT * FROM review WHERE id=?',(identifier,)).fetchone()
            if not row:raise ValueError('Unknown Review item')
            if action=='retry' and row['job_id']:db.execute("UPDATE jobs SET state='QUEUED',error=NULL,updated_at=? WHERE id=?",(now(),row['job_id']))
            elif action!='dismiss':raise ValueError('Choose retry or dismiss')
            db.execute('UPDATE review SET resolved=1 WHERE id=?',(identifier,))
        self.wake.set();return {'resolved':True}
    def enqueue(self,kind,payload):
        if kind not in {'scan','prepare','pack','archive','restore','acquire','backup','discover'}:raise ValueError('Unknown background operation')
        if kind in WRITE_JOBS and payload.get('confirmed') is not True:raise ValueError('Explicit confirmation is required for this media operation')
        identifier=uid()
        with self.db() as db:db.execute('INSERT INTO jobs VALUES(?,?,?,?,?,?,?,?,?)',(identifier,kind,json.dumps(payload),'QUEUED','QUEUED',None,None,now(),now()))
        self.wake.set();return self.job(identifier)
    def job(self,identifier):
        with self.db() as db:row=db.execute('SELECT * FROM jobs WHERE id=?',(identifier,)).fetchone()
        if not row:raise ValueError('Unknown activity')
        return dict(row)|{'payload':json.loads(row['payload']),'result':json.loads(row['result']) if row['result'] else None}
    def jobs(self):
        with self.db() as db:identifiers=[r['id'] for r in db.execute('SELECT id FROM jobs ORDER BY created_at DESC LIMIT 200')]
        return [self.job(i) for i in identifiers]
    def stage(self,job_id,stage):
        with self.db() as db:db.execute('UPDATE jobs SET stage=?,updated_at=? WHERE id=?',(stage,now(),job_id))
    def run_next(self):
        if not self.run_lock.acquire(blocking=False):return False
        try:
            with self.db() as db:
                db.execute('BEGIN IMMEDIATE')
                row=db.execute("SELECT * FROM jobs WHERE state='QUEUED' ORDER BY created_at LIMIT 1").fetchone()
                if not row:return False
                db.execute("UPDATE jobs SET state='RUNNING',updated_at=? WHERE id=?",(now(),row['id']))
            payload=json.loads(row['payload'])
            try:
                result=self.execute(row['kind'],payload,row['id'])
                with self.db() as db:db.execute("UPDATE jobs SET state='SUCCEEDED',stage='VERIFIED',result=?,error=NULL,updated_at=? WHERE id=?",(json.dumps(result),now(),row['id']))
            except Exception as exc:
                with self.db() as db:db.execute("UPDATE jobs SET state='REVIEW',stage='REVIEW',error=?,updated_at=? WHERE id=?",(str(exc),now(),row['id']))
                self.add_review(row['kind'].replace('_',' ').title()+' needs attention',str(exc),row['id'])
                if payload.get('tracking_id'):self.tracking_state(payload['tracking_id'],'REVIEW')
            return True
        finally:self.run_lock.release()
    def execute(self,kind,payload,job_id):
        if kind=='scan':return self.scan(payload['source_id'])
        if kind=='backup':return self.backup()
        if kind=='discover':return {'candidates':self.discover(payload['tracking_id'])}
        if kind=='prepare':return self.prepare(payload,job_id)
        if kind=='pack':return self.prepare_pack(payload['id'],job_id)
        if kind in {'archive','restore'}:return self.relocate(payload,job_id,kind)
        if kind=='acquire':return self.acquire(payload,job_id)
        raise ValueError('Operation is not implemented')
    def backup(self):
        directory=self.data_dir/'backups';directory.mkdir(exist_ok=True)
        path=directory/(datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S-')+uid()[:8]+'.sqlite3')
        with self.db() as db:
            target=sqlite3.connect(path)
            try:
                db.backup(target)
                if target.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise ValueError('Backup integrity failed')
            finally:target.close()
        os.chmod(path,0o600)
        return {'path':str(path),'sha256':fingerprint(path),'verified':True,'includes_media':False}
    def automation_tick(self):
        # Added below with the preparation/acquisition workflow; paused state is persisted.
        return None

    def _tracking(self,identifier):
        value=next((t for t in self.tracking() if t['id']==identifier),None)
        if not value:raise ValueError('Unknown tracked title')
        return value
    def discover(self,tracking_id):
        track=self._tracking(tracking_id)
        if track['state']=='EXPECTED':return []
        with self.db() as db:source=db.execute('SELECT * FROM sources WHERE id=?',(track['source_id'],)).fetchone()
        if not source:raise ValueError('Choose a discovery source for this title')
        candidates=[]
        for entry in LOCAL_STORAGE.inventory(canonical(source['path'],True),VIDEO|AUDIO):
            info=infer(entry.path)
            query=track['query'].casefold()
            if track['kind']=='tv' and track['season'] is not None and track['episode'] is not None:
                matches=info['kind']=='tv' and info['season']==track['season'] and info['episode']==track['episode'] and (track['series'] or track['title']).casefold() in (info['series'] or '').casefold()
            else:matches=query in info['title'].casefold() or query in entry.path.stem.casefold()
            if matches:candidates.append({'id':fingerprint(entry.path),'provider':'local','title':info['title'],'kind':info['kind'],'uri':str(entry.path),'size':entry.size,'available':True})
        if candidates:self.tracking_state(tracking_id,'AVAILABLE')
        return candidates
    def _copy_sidecars(self,source,destination):
        from .delivery import verified_copy,_SIDE_EXTENSIONS
        records=[]
        for path in source.parent.iterdir():
            if path!=source and path.name.startswith(source.stem+'.') and path.suffix.lower() in _SIDE_EXTENSIONS:
                target=destination.parent/(destination.stem+path.name[len(source.stem):])
                records.append(verified_copy(path,target,False))
        return records
    def _destination(self,storage,source,media=None):
        facts=media or infer(source)
        def safe(value):return re.sub(r'[^\w .()_-]','_',str(value)).strip(' .') or 'Untitled'
        base=storage['path']/({'movie':'Movies','tv':'TV Shows','music':'Music'}[facts['kind']])
        if facts['kind']=='tv' and facts.get('series'):base=base/safe(facts['series'])/f"Season {facts.get('season') or 0:02}"
        base.mkdir(parents=True,exist_ok=True)
        if not base.resolve().is_relative_to(storage['path']):raise ValueError('Destination escapes configured storage')
        return base/source.name
    def prepare(self,payload,job_id):
        from .delivery import verified_copy,digest
        track_id=payload.get('tracking_id');track=self._tracking(track_id) if track_id else None
        if track_id:self.tracking_state(track_id,'VERIFYING')
        source=canonical(payload['source_path'])
        # Preparation is limited to selected source/storage locations, never arbitrary system files.
        approved=[Path(s['path']) for s in self.sources()]+[Path(s['path']) for s in self.storages()]
        if not any(source.is_relative_to(base) for base in approved):raise ValueError('Source must belong to configured Sources or Storage')
        storage=self.storage(payload['storage_id'],{'library'})
        mode=payload.get('mode','direct')
        working=self.data_dir/'working'/job_id
        input_dir=working/'input';output_dir=working/'output'
        input_dir.mkdir(parents=True,exist_ok=True);output_dir.mkdir(parents=True,exist_ok=True)
        input_path=input_dir/source.name
        self.stage(job_id,'SAFE_WORKING_COPY')
        verified_copy(source,input_path)
        self.stage(job_id,'INSPECTING');inspection=self.tools.inspect(input_path)
        self.stage(job_id,'IDENTIFYING')
        identity=payload.get('replace_media_id') or (track['media_id'] if track else None)
        metadata=payload.get('metadata') or {}
        output=output_dir/source.name
        if mode=='remux':output=output.with_suffix('.mp4')
        if mode=='transcode':output=output.with_suffix('.mp4')
        if track_id:self.tracking_state(track_id,'PREPARING')
        self.stage(job_id,'PREPARING')
        if output.exists():
            inspection=self.tools.inspect(output)
        elif mode=='direct':
            verified_copy(input_path,output);inspection=self.tools.inspect(output)
        else:
            inspection=self.tools.prepare(input_path,output,mode=mode,metadata=metadata)
            self._copy_sidecars(input_path,output)
        self.stage(job_id,'VALIDATING');self.tools.inspect(output)
        destination=self._destination(storage,output,infer(source))
        self.stage(job_id,'TRANSFERRING');receipt=verified_copy(output,destination)
        self.stage(job_id,'VERIFYING');checksum=digest(destination)
        if checksum!=receipt['sha256']:raise ValueError('Prepared media verification failed')
        item=self.register(destination,storage_id=storage['id'],media_id=identity,inspection=inspection,ready=True)
        if track:
            values={k:track[k] for k in ('title','kind','series','season','episode') if track.get(k) is not None}
            if values:self.correct_metadata(item['id'],values)
            self.tracking_state(track_id,'READY_TO_WATCH',item['id'])
        artwork=self.tools.capture_artwork(destination,item['id'])
        if artwork:
            with self.db() as db:db.execute('UPDATE media SET artwork=? WHERE id=?',(str(artwork),item['id']))
        self.stage(job_id,'READY_TO_WATCH')
        return {'media_id':item['id'],'destination':str(destination),'verified':True,'receipt':receipt,'mode':mode,'subtitle_languages':self.settings()['subtitle_languages'],'subtitles_preserved':[r['destination'] for r in receipt['sidecars'] if Path(r['destination']).suffix in {'.srt','.ass','.vtt'}]}
    def save_pack(self,values):
        name=values.get('name');ids=values.get('media_ids');context=values.get('context','custom')
        if not isinstance(name,str) or not name.strip():raise ValueError('Name this Travel Pack')
        if context not in PRESETS:raise ValueError('Choose a Travel Pack context')
        if not isinstance(ids,list) or not ids or len(ids)>10000:raise ValueError('Choose Pack contents')
        for identifier in ids:self.media(identifier)
        self.storage(values['target_storage_id'],{'device'})
        limits=[values.get('max_bytes'),values.get('max_titles')]
        if any(v is not None and (type(v) is not int or not 0<v<2**63) for v in limits):raise ValueError('Pack limits must be positive integers')
        quality=values.get('quality','original')
        if quality not in {'original','remux','compact'}:raise ValueError('Choose original, remux or compact quality')
        identifier=uid()
        with self.db() as db:db.execute('INSERT INTO packs VALUES(?,?,?,?,?,?,?,?,?,?,?)',(identifier,name.strip(),context,values['target_storage_id'],json.dumps(list(dict.fromkeys(ids))),*limits,quality,'DEFINED',None,now()))
        return next(p for p in self.packs() if p['id']==identifier)
    def packs(self):
        with self.db() as db:rows=[dict(r) for r in db.execute('SELECT * FROM packs ORDER BY updated_at DESC')]
        for p in rows:
            p['media_ids']=json.loads(p['media_ids']);p['receipt']=json.loads(p['receipt']) if p['receipt'] else None
            if p['state']=='READY_OFFLINE' and p['receipt']:
                p['target_connected']=all(Path(item['destination']).is_file() for item in p['receipt']['items'])
        return rows
    def _pack(self,identifier):
        p=next((p for p in self.packs() if p['id']==identifier),None)
        if not p:raise ValueError('Unknown Travel Pack')
        return p
    def preview_pack(self,identifier):
        p=self._pack(identifier);items=[];excluded=[];total=0
        for media_id in p['media_ids']:
            item=self.media(media_id)
            try:
                path=self.playable(media_id);size=path.stat().st_size
                from .delivery import _SIDE_EXTENSIONS
                size+=sum(f.stat().st_size for f in path.parent.iterdir() if f!=path and f.name.startswith(path.stem+'.') and f.suffix.lower() in _SIDE_EXTENSIONS)
                reason=None
            except (OSError,ValueError):reason='offline';size=0;path=None
            if not reason and p['max_titles'] and len(items)>=p['max_titles']:reason='title_limit'
            if not reason and p['max_bytes'] and total+size>p['max_bytes']:reason='storage_budget'
            if reason:excluded.append({'id':media_id,'title':item['title'],'reason':reason})
            else:items.append({'id':media_id,'title':item['title'],'path':str(path),'size':size});total+=size
        storage=self.storage(p['target_storage_id'],{'device'})
        free=shutil.disk_usage(storage['path']).free
        return {'id':identifier,'items':items,'excluded':excluded,'total_bytes':total,'free_bytes':free,'fits':total<=free,'quality':p['quality']}
    def prepare_pack(self,identifier,job_id):
        from .delivery import verified_copy,digest
        p=self._pack(identifier);preview=self.preview_pack(identifier)
        if not preview['items']:raise ValueError('No selected titles are available within this Pack budget')
        if not preview['fits']:raise ValueError('Target device does not have enough free space')
        storage=self.storage(p['target_storage_id'],{'device'})
        folder=storage['path']/('SKALD '+re.sub(r'[^\w -]','_',p['name'])+' '+p['id'][:8]);folder.mkdir(exist_ok=True)
        if not folder.resolve().is_relative_to(storage['path']):raise ValueError('Pack destination escapes device storage')
        with self.db() as db:db.execute("UPDATE packs SET state='PREPARING',updated_at=? WHERE id=?",(now(),identifier))
        receipts=[];total=0
        for selected in preview['items']:
            self.stage(job_id,'PREPARING '+selected['title']);source=Path(selected['path']);item=self.media(selected['id'])
            if not item['ready']:
                # Validation rather than filename presence proves usable media.
                self.tools.inspect(source)
            if p['quality']!='original':
                work=self.data_dir/'working'/job_id/selected['id'];work.mkdir(parents=True,exist_ok=True)
                prepared=work/source.with_suffix('.mp4').name
                if not prepared.exists():self.tools.prepare(source,prepared,'remux' if p['quality']=='remux' else 'transcode')
                self._copy_sidecars(source,prepared);source=prepared
            destination=folder/(selected['id'][:8]+' '+source.name)
            self.stage(job_id,'TRANSFERRING');receipt=verified_copy(source,destination)
            receipt['media_id']=selected['id'];receipts.append(receipt)
            total+=receipt['size']+sum(r['size'] for r in receipt['sidecars'])
            if p['max_bytes'] and total>p['max_bytes']:raise ValueError('Prepared Pack exceeds its storage budget; retained transfers require review')
            if digest(destination)!=receipt['sha256']:raise ValueError('Offline media verification failed')
            self.register(destination,storage_id=storage['id'],media_id=selected['id'],ready=True,role='pack')
        self.stage(job_id,'VERIFYING')
        receipt={'pack_id':identifier,'items':receipts,'verified':True,'total_bytes':total,'verified_at':now(),'state':'READY_OFFLINE'}
        # Receipts and offline identity live in app data, never alongside device media.
        record_dir=self.data_dir/'packs'/identifier;record_dir.mkdir(parents=True,exist_ok=True)
        (record_dir/'delivery.json').write_text(json.dumps(receipt,indent=2))
        with self.db() as db:db.execute("UPDATE packs SET state='READY_OFFLINE',receipt=?,updated_at=? WHERE id=?",(json.dumps(receipt),now(),identifier))
        return receipt
    def reconcile_pack(self,identifier,progress):
        pack=self._pack(identifier)
        if pack['state']!='READY_OFFLINE':raise ValueError('Prepare and verify this offline Pack first')
        if not isinstance(progress,list):raise ValueError('Provide offline progress records')
        for row in progress:
            if row.get('media_id') not in pack['media_ids']:raise ValueError('Progress record is not part of this Pack')
            self.progress(row['media_id'],row['position'],row['duration'],row.get('watched'))
        return {'reconciled':len(progress),'pack_id':identifier}
    def relocate(self,payload,job_id,action):
        from .delivery import verified_copy,digest
        media_id=payload['media_id'];item=self.media(media_id)
        storage=self.storage(payload['storage_id'],{'archive'} if action=='archive' else {'library'})
        with self.db() as db:operation=db.execute('SELECT * FROM operations WHERE job_id=?',(job_id,)).fetchone()
        if operation:
            source=Path(operation['source']);destination=Path(operation['destination']);checksum=operation['sha256']
        else:
            candidates=[r for r in item['locations'] if r['role']==('archive' if action=='restore' else 'library') and r['available'] and Path(r['path']).is_file()]
            if not candidates:raise ValueError('No available '+('archived' if action=='restore' else 'library')+' representation to move')
            source=Path(candidates[0]['path']);destination=self._destination(storage,source,item);checksum=digest(source)
            if source==destination:raise ValueError('Media is already at this destination')
            with self.db() as db:db.execute('INSERT INTO operations VALUES(?,?,?,?,?,?,?,?,?)',(uid(),job_id,action,media_id,str(source),str(destination),checksum,'PLANNED',None))
        self.stage(job_id,'COPYING')
        if source.exists():receipt=verified_copy(source,destination)
        elif destination.exists() and digest(destination)==checksum:
            with self.db() as db:stored=db.execute('SELECT receipt FROM operations WHERE job_id=?',(job_id,)).fetchone()
            if not stored or not stored['receipt']:raise ValueError('Interrupted move needs source/sidecar review')
            receipt=json.loads(stored['receipt'])
        else:raise ValueError('Neither original nor verified moved media is available')
        self.stage(job_id,'VERIFYING')
        if digest(destination)!=checksum:raise ValueError('Storage movement verification failed')
        # Commit verified representation before removal; recovery can finish any interrupted deletion.
        self.register(destination,storage_id=storage['id'],media_id=media_id,ready=item['ready'],role='archive' if action=='archive' else 'library')
        with self.db() as db:db.execute("UPDATE operations SET state='REGISTERED',receipt=? WHERE job_id=?",(json.dumps(receipt),job_id))
        for record in [receipt,*receipt['sidecars']]:
            original=Path(record['source']);target=Path(record['destination'])
            if original.exists():
                if digest(original)!=record['sha256'] or digest(target)!=record['sha256']:raise ValueError('Move changed during final verification; originals retained')
                original.unlink()
        with self.db() as db:
            db.execute('UPDATE locations SET available=0 WHERE path=?',(str(source),))
            db.execute("UPDATE operations SET state='COMPLETED' WHERE job_id=?",(job_id,))
        return receipt|{'media_id':media_id,'verified':True,'operation':action}
    def configure_service(self,identifier,config):
        if identifier not in {'transmission','metadata','subtitles'}:raise ValueError('Unknown configurable media service')
        if identifier=='transmission':
            from .adapters import TransmissionClient
            TransmissionClient(config.get('endpoint','http://127.0.0.1:9091/transmission/rpc'),config.get('username'),config.get('password'))
        with self.db() as db:db.execute('INSERT OR REPLACE INTO services VALUES(?,?)',(identifier,json.dumps(config)))
        os.chmod(self.db_path,0o600)
        return {'id':identifier,'configured':True}
    def service_config(self,identifier):
        with self.db() as db:row=db.execute('SELECT config FROM services WHERE id=?',(identifier,)).fetchone()
        if not row:raise ValueError('Configure '+identifier+' in Services first')
        return json.loads(row['config'])
    def services(self):
        result=[]
        for value in self.tools.capabilities():
            value=dict(value);value['id']=value.get('id') or value.get('name','').lower();result.append(value)
        with self.db() as db:configured={r['id'] for r in db.execute('SELECT id FROM services')}
        result.append({'id':'transmission','name':'Transmission acquisition','configured':'transmission' in configured,'available':'transmission' in configured,'verification':'connection verification required'})
        for identifier,name in [('metadata','Metadata provider'),('subtitles','Subtitle provider')]:result.append({'id':identifier,'name':name,'configured':identifier in configured,'available':identifier in configured,'verification':'user configuration required'})
        return result
    def acquire(self,payload,job_id):
        from .adapters import TransmissionClient,normalize_candidate
        config=self.service_config('transmission');track=self._tracking(payload['tracking_id']) if payload.get('tracking_id') else None
        inboxes=[s for s in self.storages() if s['role']=='inbox' and s['available']]
        if not inboxes:raise ValueError('Configure an acquisition inbox in Storage')
        uri=normalize_candidate(payload['uri'])['uri']
        client=TransmissionClient(config.get('endpoint','http://127.0.0.1:9091/transmission/rpc'),config.get('username'),config.get('password'))
        result=client.add(uri,Path(inboxes[0]['path']))
        torrent=result.get('torrent-added') or result.get('torrent-duplicate')
        if not torrent:raise ValueError('Provider did not return an acquisition identity')
        if track:
            settings=track['config'];settings['acquisition_id']=torrent['id'];settings['storage_id']=payload.get('storage_id') or settings.get('storage_id');settings['download_dir']=inboxes[0]['path']
            with self.db() as db:db.execute("UPDATE tracking SET state='ACQUIRING',config=?,updated_at=? WHERE id=?",(json.dumps(settings),now(),track['id']))
        return {'provider':'transmission','acquisition_id':torrent['id'],'state':'ACQUIRING'}
    def automation_tick(self):
        if self.settings()['automation_paused']:return
        for track in self.tracking():
            if track['state']=='EXPECTED':
                release=datetime.fromisoformat(track['release_at'].replace('Z','+00:00'))
                if release<=datetime.now(timezone.utc):self.tracking_state(track['id'],'RELEASED')
                else:continue
            if track['state'] in {'RELEASED','AVAILABLE'}:
                try:candidates=self.discover(track['id'])
                except (ValueError,OSError):continue
                if candidates and track['config'].get('auto_prepare'):
                    with self.db() as db:pending=db.execute("SELECT payload FROM jobs WHERE state IN ('QUEUED','RUNNING') AND kind='prepare'").fetchall()
                    if any(json.loads(r['payload']).get('tracking_id')==track['id'] for r in pending):continue
                    self.enqueue('prepare',{'tracking_id':track['id'],'source_path':candidates[0]['uri'],'storage_id':track['config'].get('storage_id'),'mode':track['config'].get('mode','direct'),'confirmed':True})
                    self.tracking_state(track['id'],'VERIFYING')
            elif track['state']=='ACQUIRING':
                try:
                    from .adapters import TransmissionClient
                    config=self.service_config('transmission');client=TransmissionClient(config.get('endpoint','http://127.0.0.1:9091/transmission/rpc'),config.get('username'),config.get('password'))
                    rows=client.status([track['config']['acquisition_id']])
                    if not rows:raise ValueError('Acquisition disappeared from provider')
                    torrent=rows[0]
                    if torrent.get('error'):raise ValueError('Acquisition provider reported a failure')
                    if torrent['percentDone']>=1:
                        base=canonical(torrent['downloadDir'],True)
                        files=[canonical(base/f['name']) for f in torrent['files'] if Path(f['name']).suffix.lower() in VIDEO|AUDIO]
                        if not files:raise ValueError('Completed acquisition contains no supported media')
                        if any(not f.is_relative_to(base) for f in files):raise ValueError('Provider file escaped acquisition directory')
                        self.enqueue('prepare',{'tracking_id':track['id'],'source_path':str(files[0]),'storage_id':track['config'].get('storage_id'),'confirmed':True,'mode':track['config'].get('mode','direct')})
                        self.tracking_state(track['id'],'VERIFYING')
                except Exception as exc:
                    self.tracking_state(track['id'],'REVIEW');self.add_review('Episode acquisition needs attention',str(exc))
