#!/usr/bin/env python3
"""Packaging is explicitly gated until corrected Headless envelope is verified."""
raise SystemExit('PACKAGING DISABLED: 0.2.0 is rejected. Satisfy recovered v0.9.4 Headless envelope, then native GUI/menu-bar gates before distribution packaging.')
