import {spawn} from 'node:child_process';
import {mkdtemp,readFile,mkdir,writeFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
const root=path.resolve(import.meta.dirname,'..');
const temp=await mkdtemp(path.join(tmpdir(),'skald-browser-'));
const ready=path.join(temp,'ready.json');
const media=path.join(temp,'media');
await mkdir(media);await writeFile(path.join(media,'Browser Movie.mp4'),'fixture');
let chrome,ws;
const service=spawn(process.env.SKALD_TEST_PYTHON||'python3',[path.join(root,'skald.py'),'--port','0','--ready-file',ready],{env:{...process.env,SKALD_DATA_DIR:path.join(temp,'data')},stdio:'ignore'});
async function until(fn){for(let i=0;i<200;i++){try{let result=await fn();if(result)return result}catch{}await new Promise(r=>setTimeout(r,50))}throw Error('Timed out waiting for browser/service state')}
try{
 const state=await until(async()=>JSON.parse(await readFile(ready,'utf8')));
 const profile=path.join(temp,'chrome');
 chrome=spawn('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',['--headless','--no-first-run','--no-default-browser-check','--disable-background-networking','--disable-sync','--disable-component-update','--remote-debugging-port=0','--user-data-dir='+profile,state.url],{stdio:'ignore'});
 const port=await until(async()=>(await readFile(path.join(profile,'DevToolsActivePort'),'utf8')).split('\n')[0]);
 const target=await until(async()=>{let pages=await (await fetch('http://127.0.0.1:'+port+'/json/list')).json();return pages.find(x=>x.type==='page')});
 ws=new WebSocket(target.webSocketDebuggerUrl);await new Promise((r,j)=>{ws.onopen=r;ws.onerror=j});
 let next=0;const pending=new Map();ws.onmessage=e=>{let data=JSON.parse(e.data);if(data.id){let p=pending.get(data.id);pending.delete(data.id);data.error?p.reject(Error(JSON.stringify(data.error))):p.resolve(data.result)}};
 function cdp(method,params={}){return new Promise((resolve,reject)=>{let id=++next;pending.set(id,{resolve,reject});ws.send(JSON.stringify({id,method,params}))})}
 async function evaluate(expression){let r=await cdp('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true});if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));return r.result.value}
 await until(()=>evaluate("document.querySelector('#health')?.textContent.includes('Service online')"));
 await evaluate(`document.querySelector('#add input').value=${JSON.stringify(media)};document.querySelector('#add').requestSubmit();`);
 await until(()=>evaluate("document.querySelector('#items').textContent.includes('Browser Movie')"));
 await evaluate("document.querySelector('[data-watch]').click()");
 await until(()=>evaluate("document.querySelector('[data-watch]').textContent==='Unwatch'"));
 await evaluate("window.prompt=(()=>{let values=['90','300'];return ()=>values.shift()})();document.querySelector('[data-progress]').click()");
 await until(()=>evaluate("document.querySelector('#items').textContent.includes('90 / 300')"));
 await evaluate("document.querySelector('[data-select]').click();document.querySelector('#selection [name=name]').value='Browser Getaway';document.querySelector('#selection [name=max_titles]').value='1';document.querySelector('#selection').requestSubmit(document.querySelector('#selection [value=pack]'))");
 await until(()=>evaluate("document.querySelector('#packs').textContent.includes('Browser Getaway')"));
 await evaluate("document.querySelector('[data-plan]').click()");
 await until(()=>evaluate("document.querySelector('#plan').textContent.includes('1 ready titles')"));
 assert.equal(await evaluate("document.querySelector('#plan a').download.startsWith('SKALD-pack-')"),true);
 await cdp('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:true});
 assert.equal(await evaluate('document.documentElement.scrollWidth<=window.innerWidth'),true,'mobile page overflows');
 await until(()=>evaluate('navigator.serviceWorker.controller!==null'));
 const cached=await evaluate("(async()=>{let names=await caches.keys();let c=await caches.open(names.find(x=>x.startsWith('skald-shell-')));return (await c.keys()).map(x=>new URL(x.url).pathname)})()");
 assert.deepEqual(cached.sort(),['/','/icon.svg','/manifest.webmanifest'].sort(),'private API records were cached');
 console.log('ENVIRONMENT PASS: Chrome exercised folder scan, watched, progress, Travel Pack form/manifest, mobile width and shell-only PWA cache');
}finally{ws?.close();chrome?.kill('SIGTERM');service.kill('SIGTERM');await new Promise(r=>setTimeout(r,500));await rm(temp,{recursive:true,force:true})}
