import {spawn,spawnSync} from 'node:child_process';
import {mkdtemp,readFile,mkdir,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
const root=path.resolve(import.meta.dirname,'..'),temp=await mkdtemp(path.join(tmpdir(),'skald-envelope-browser-'));
const ready=path.join(temp,'ready.json');let chrome,ws;
for(const folder of ['media','inbox','library','archive','device'])await mkdir(path.join(temp,folder));
function createVideo(file){const result=spawnSync('/opt/homebrew/bin/ffmpeg',['-v','error','-y','-f','lavfi','-i','color=c=blue:s=160x90:r=10','-f','lavfi','-i','anullsrc=r=44100:cl=mono','-t','4','-c:v','libx264','-pix_fmt','yuv420p','-c:a','aac','-shortest',file]);assert.equal(result.status,0,String(result.stderr))}
createVideo(path.join(temp,'media','Arrival (2016).mp4'));createVideo(path.join(temp,'inbox','Fixture Show S01E01.mp4'));
const service=spawn(process.env.SKALD_TEST_PYTHON||'python3',[path.join(root,'skald.py'),'--data-dir',path.join(temp,'data'),'--port','0','--ready-file',ready],{stdio:'ignore'});
async function until(fn,label='state'){for(let i=0;i<400;i++){try{let result=await fn();if(result)return result}catch{}await new Promise(r=>setTimeout(r,50))}throw Error('Timed out: '+label)}
try{
 const state=await until(async()=>JSON.parse(await readFile(ready,'utf8')),'runtime');
 const profile=path.join(temp,'chrome');chrome=spawn('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',['--headless','--no-first-run','--no-default-browser-check','--disable-background-networking','--disable-sync','--disable-component-update','--remote-debugging-port=0','--user-data-dir='+profile,state.url],{stdio:'ignore'});
 const port=await until(async()=>(await readFile(path.join(profile,'DevToolsActivePort'),'utf8')).split('\n')[0],'Chrome');
 const target=await until(async()=>{let pages=await(await fetch('http://127.0.0.1:'+port+'/json/list')).json();return pages.find(x=>x.type==='page')});
 ws=new WebSocket(target.webSocketDebuggerUrl);await new Promise((r,j)=>{ws.onopen=r;ws.onerror=j});let seq=0,pending=new Map();ws.onmessage=e=>{let d=JSON.parse(e.data);if(d.id){let p=pending.get(d.id);pending.delete(d.id);d.error?p.reject(Error(JSON.stringify(d.error))):p.resolve(d.result)}};
 function cdp(method,params={}){return new Promise((resolve,reject)=>{let id=++seq;pending.set(id,{resolve,reject});ws.send(JSON.stringify({id,method,params}))})}
 async function evaluate(expression){let x=await cdp('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true});if(x.exceptionDetails)throw Error(JSON.stringify(x.exceptionDetails));return x.result.value}
 await until(()=>evaluate("document.querySelector('#nav a')!==null"),'session');
 async function post(route,data){return evaluate(`(async()=>{let r=await fetch('/api/'+${JSON.stringify(route)},{method:'POST',headers:{'Content-Type':'application/json','X-SKALD-CSRF':csrf},body:JSON.stringify(${JSON.stringify(data)})});let d=await r.json();if(!r.ok)throw Error(d.error);return d})()`)}
 const storages={};for(const role of ['library','archive','device','inbox'])storages[role]=await post('storage',{name:role,path:path.join(temp,role),role});
 await evaluate("location.hash='sources'");await until(()=>evaluate("!!document.querySelector('form[data-action=sources]')"),'Sources UI');
 await evaluate(`let f=document.querySelector('form[data-action=sources]');f.elements.name.value='Movie library';f.elements.path.value=${JSON.stringify(path.join(temp,'media'))};f.requestSubmit()`);
 await until(()=>evaluate("!!document.querySelector('[data-command=scan]')"),'source created');await evaluate("document.querySelector('[data-command=scan]').click()");
 await until(()=>evaluate("(async()=>{let d=await api('library?kind=movie');return d.items.length>0})()"),'indexing');
 await evaluate("location.hash='movies'");await until(()=>evaluate("!!document.querySelector('[data-media]')"),'media-first Movie card');
 assert.equal(await evaluate("document.querySelector('.card img')!==null"),true,'actual app-data artwork missing');
 await evaluate("document.querySelector('[data-media]').click()");await until(()=>evaluate("document.querySelector('#detail').open"),'media detail');await evaluate("document.querySelector('[data-command=web-play]').click()");
 await until(()=>evaluate("document.querySelector('#player video')?.readyState>=1"),'actual range-stream playback');
 await evaluate("let v=document.querySelector('#player video');v.pause();v.currentTime=1;v.dispatchEvent(new Event('pause'));document.querySelector('#player .close').click()");
 await until(()=>evaluate("(async()=>{let d=await api('home');return d.continue_watching.length>0})()"),'playback progress');
 const movie=await evaluate("(async()=>{let d=await api('library?kind=movie');return d.items[0]})()");
 await evaluate("location.hash='packs'");await until(()=>evaluate("!!document.querySelector('form[data-action=packs]')"),'Pack form');
 await evaluate(`let f=document.querySelector('form[data-action=packs]');f.elements.name.value='Weekend';f.elements.context.value='weekend';f.elements.target_storage_id.value=${JSON.stringify(storages.device.id)};f.querySelector('[name=media_ids]').checked=true;f.requestSubmit()`);
 await until(()=>evaluate("!!document.querySelector('[data-command=\"packs/prepare\"]')"),'Pack definition');
 await evaluate("window.confirm=()=>true;document.querySelector('[data-command=\"packs/prepare\"]').click()");
 await until(()=>evaluate("(async()=>{let p=await api('packs');return p.packs[0]?.state==='READY_OFFLINE'})()"),'real verified offline Pack');
 const pack=await evaluate("(async()=>{let p=await api('packs');return p.packs[0]})()");assert.equal((await readFile(pack.receipt.items[0].destination)).length>0,true);
 const src=await post('sources',{name:'Daily inbox',kind:'local',path:path.join(temp,'inbox')});
 await evaluate("location.hash='downloads'");await until(()=>evaluate("!!document.querySelector('form[data-action=tracking]')"),'Daily tracking form');
 await evaluate(`let f=document.querySelector('form[data-action=tracking]');f.elements.title.value='Fixture Show';f.elements.kind.value='tv';f.elements.series.value='Fixture Show';f.elements.season.value='1';f.elements.episode.value='1';f.elements.source_id.value=${JSON.stringify(src.id)};f.elements.storage_id.value=${JSON.stringify(storages.library.id)};f.elements.auto_prepare.checked=true;f.elements.confirmed.checked=true;f.requestSubmit()`);
 await until(()=>evaluate("(async()=>{let t=await api('tracking');return t.items[0]?.state==='READY_TO_WATCH'})()"),'automatic episode READY');
 await evaluate("location.hash='home'");await until(()=>evaluate("document.querySelector('#content').textContent.includes('Fixture Show')"),'Ready episode on Home');
 await post('archive',{media_id:movie.id,storage_id:storages.archive.id,confirmed:true});
 await until(()=>evaluate(`(async()=>{let i=await api('media/'+${JSON.stringify(movie.id)});return i.locations.some(l=>l.role==='archive'&&l.available)})()`),'archive movement');
 await cdp('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:true});assert.equal(await evaluate('document.documentElement.scrollWidth<=window.innerWidth'),true,'responsive layout overflows');
 await until(()=>evaluate('navigator.serviceWorker.controller!==null'),'PWA controller');const cached=await evaluate("(async()=>{let c=await caches.open((await caches.keys())[0]);return(await c.keys()).map(r=>new URL(r.url).pathname)})()");assert.equal(cached.some(p=>p.startsWith('/api/')),false);
 console.log('ENVIRONMENT PASS: real Chrome media/artwork/index, authenticated streaming/progress, actual verified Travel Pack transfer, Daily Episode READY/Home, Archive, responsive/PWA workflows');
}finally{ws?.close();chrome?.kill('SIGTERM');service.kill('SIGTERM');await new Promise(r=>setTimeout(r,700));await rm(temp,{recursive:true,force:true})}
