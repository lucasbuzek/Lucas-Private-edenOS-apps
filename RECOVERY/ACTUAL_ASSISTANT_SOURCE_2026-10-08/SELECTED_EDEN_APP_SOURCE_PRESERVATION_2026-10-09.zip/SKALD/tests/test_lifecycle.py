import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import unittest

class LifecycleTests(unittest.TestCase):
    def test_persistent_runtime_detached_attach_and_duplicate_owner(self):
        with tempfile.TemporaryDirectory(prefix='skald-life-') as directory:
            data=Path(directory)
            command=[sys.executable,'skald.py','--data-dir',str(data),'--port','0','--background']
            first=subprocess.run(command,capture_output=True,text=True,timeout=15)
            self.assertEqual(first.returncode,0,first.stderr)
            state=json.loads(first.stdout)
            try:
                self.assertTrue((data/'runtime.json').exists())
                second=subprocess.run(command,capture_output=True,text=True,timeout=15)
                self.assertEqual(second.returncode,0,second.stderr)
                self.assertEqual(json.loads(second.stdout)['pid'],state['pid'])
                duplicate=subprocess.run([sys.executable,'skald.py','--data-dir',str(data),'--port','0'],capture_output=True,text=True,timeout=5)
                self.assertNotEqual(duplicate.returncode,0)
                self.assertIn('already owns',duplicate.stderr)
            finally:
                os.kill(state['pid'],15)
                for _ in range(100):
                    if not (data/'runtime.json').exists():break
                    time.sleep(.03)
                self.assertFalse((data/'runtime.json').exists())
    def test_public_bind_rejected_without_lan_opt_in(self):
        with tempfile.TemporaryDirectory() as data:
            result=subprocess.run([sys.executable,'skald.py','--data-dir',data,'--host','0.0.0.0'],capture_output=True,text=True)
            self.assertNotEqual(result.returncode,0);self.assertIn('--allow-lan',result.stderr)
