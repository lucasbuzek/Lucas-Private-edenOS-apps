import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from skald_runtime import delivery


class DeliveryTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name).resolve()
        self.source = self.root / 'source' / 'Film.mkv'
        self.source.parent.mkdir()
        self.source.write_bytes(b'abc')
        self.destination = self.root / 'target' / 'Renamed.mkv'
        self.destination.parent.mkdir()

    def test_copy_preserves_only_associated_sidecars(self):
        (self.source.parent / 'Film.en.srt').write_bytes(b'subtitle')
        (self.source.parent / 'Film.nfo').write_bytes(b'user metadata')
        (self.source.parent / 'Other.srt').write_bytes(b'unrelated')
        result = delivery.verified_copy(self.source, self.destination)
        self.assertEqual(result['sha256'], 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad')
        self.assertEqual(self.destination.read_bytes(), b'abc')
        self.assertEqual((self.destination.parent / 'Renamed.en.srt').read_bytes(), b'subtitle')
        self.assertEqual(sorted(p.name for p in self.destination.parent.iterdir()), ['Renamed.en.srt', 'Renamed.mkv', 'Renamed.nfo'])
        self.assertEqual(len(result['sidecars']), 2)
        self.assertTrue(self.source.exists())

    def test_move_removes_verified_sources(self):
        sidecar = self.source.with_suffix('.vtt')
        sidecar.write_bytes(b'captions')
        delivery.verified_move(self.source, self.destination)
        self.assertFalse(self.source.exists())
        self.assertFalse(sidecar.exists())
        self.assertEqual(self.destination.read_bytes(), b'abc')

    def test_collision_keeps_all_sources_and_existing_destination(self):
        self.source.with_suffix('.srt').write_bytes(b'new')
        collision = self.destination.with_suffix('.srt')
        collision.write_bytes(b'user')
        with self.assertRaises(FileExistsError):
            delivery.verified_move(self.source, self.destination)
        self.assertEqual(collision.read_bytes(), b'user')
        self.assertTrue(self.source.exists())
        self.assertFalse(self.destination.exists())

    def test_rejects_symlinks_directories_and_same_path(self):
        link = self.source.parent / 'link.mkv'
        link.symlink_to(self.source)
        for source, target in [(link, self.destination), (self.source.parent, self.destination), (self.source, self.source)]:
            with self.subTest(source=source, target=target), self.assertRaises((ValueError, OSError)):
                delivery.verified_copy(source, target)
        self.destination.symlink_to(self.source)
        with self.assertRaises((ValueError, OSError)):
            delivery.verified_copy(self.source, self.destination)

    def test_identical_existing_destination_is_safe(self):
        self.destination.write_bytes(b'abc')
        delivery.verified_copy(self.source, self.destination)
        self.assertEqual(self.destination.read_bytes(), b'abc')

    def test_interrupted_placement_rolls_back_new_files(self):
        self.source.with_suffix('.srt').write_bytes(b'sub')
        import os
        original = os.link
        count = 0
        def interrupted(*args, **kwargs):
            nonlocal count
            count += 1
            if count == 2:
                raise OSError('injected interruption')
            return original(*args, **kwargs)
        with patch.object(delivery.os, 'link', side_effect=interrupted):
            with self.assertRaises(OSError):
                delivery.verified_move(self.source, self.destination)
        self.assertTrue(self.source.exists())
        self.assertEqual(list(self.destination.parent.iterdir()), [])

    def test_disabled_sidecars_leaves_user_files_at_source(self):
        sidecar = self.source.with_suffix('.srt')
        sidecar.write_bytes(b'sub')
        result = delivery.verified_move(self.source, self.destination, preserve_sidecars=False)
        self.assertEqual(result['sidecars'], [])
        self.assertTrue(sidecar.exists())
        self.assertEqual(list(self.destination.parent.iterdir()), [self.destination])

    def test_racing_destination_creation_is_not_overwritten(self):
        import os
        original = os.link
        def race(temporary, target):
            Path(target).write_bytes(b'concurrent user file')
            return original(temporary, target)
        with patch.object(delivery.os, 'link', side_effect=race):
            with self.assertRaises(FileExistsError):
                delivery.verified_copy(self.source, self.destination)
        self.assertEqual(self.destination.read_bytes(), b'concurrent user file')
        self.assertEqual(self.source.read_bytes(), b'abc')
        self.assertEqual(list(self.destination.parent.iterdir()), [self.destination])

    def test_symlink_sidecar_is_not_followed(self):
        self.source.with_suffix('.srt').symlink_to(self.source)
        with self.assertRaises(ValueError):
            delivery.verified_move(self.source, self.destination)
        self.assertTrue(self.source.exists())
        self.assertFalse(self.destination.exists())

    def test_destination_directory_must_already_exist(self):
        with self.assertRaises(NotADirectoryError):
            delivery.verified_copy(self.source, self.root / 'absent' / 'Film.mkv')
        self.assertFalse((self.root / 'absent').exists())

    def test_rollback_preserves_destination_modified_by_another_writer(self):
        self.source.with_suffix('.srt').write_bytes(b'sub')
        import os
        original = os.link
        count = 0
        def interrupted(*args, **kwargs):
            nonlocal count
            count += 1
            if count == 2:
                self.destination.write_bytes(b'user modification')
                raise OSError('interrupted')
            return original(*args, **kwargs)
        with patch.object(delivery.os, 'link', side_effect=interrupted):
            with self.assertRaises(OSError):
                delivery.verified_copy(self.source, self.destination)
        self.assertEqual(self.destination.read_bytes(), b'user modification')
        self.assertTrue(self.source.exists())
