from pathlib import Path
import shutil
import subprocess

def video(path):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    subprocess.run([shutil.which('ffmpeg') or '/opt/homebrew/bin/ffmpeg','-v','error','-y','-f','lavfi','-i','color=c=blue:s=160x90:r=10','-f','lavfi','-i','anullsrc=r=44100:cl=mono','-t','1','-c:v','libx264','-pix_fmt','yuv420p','-c:a','aac','-shortest',str(path)],check=True,timeout=20)
    return path
