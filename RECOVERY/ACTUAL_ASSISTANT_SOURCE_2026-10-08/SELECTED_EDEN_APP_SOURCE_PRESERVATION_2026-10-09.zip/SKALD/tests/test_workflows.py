from pathlib import Path
import tempfile
import unittest
from skald_runtime.core import Runtime
from .fixtures import video

class WorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='skald-workflow-');self.base=Path(self.temp.name).resolve()
        self.runtime=Runtime(self.base/'app-data')
        for name in ('inbox','library','archive','device'):(self.base/name).mkdir()
        self.original=video(self.base/'inbox'/'Example S01E02.mp4')
        self.original.with_suffix('.en.srt').write_text('1\n00:00:00,000 --> 00:00:00,900\nFixture subtitle\n')
        self.source=self.runtime.add_source('Selected inbox','local',str(self.base/'inbox'))
        self.library=self.runtime.add_storage('Library',str(self.base/'library'),'library')
        self.archive=self.runtime.add_storage('Archive',str(self.base/'archive'),'archive')
        self.device=self.runtime.add_storage('Offline device',str(self.base/'device'),'device')
    def tearDown(self):self.runtime.close();self.temp.cleanup()
    def run_job(self,kind,payload):
        job=self.runtime.enqueue(kind,payload)
        self.runtime.run_next()
        result=self.runtime.job(job['id'])
        self.assertEqual(result['state'],'SUCCEEDED',result['error'])
        return result['result']
    def prepare(self):
        return self.run_job('prepare',{'source_path':str(self.original),'storage_id':self.library['id'],'confirmed':True,'mode':'direct'})
    def test_safe_preparation_actual_pack_verified_offline_and_reconcile(self):
        prepared=self.prepare();item=self.runtime.media(prepared['media_id'])
        self.assertTrue(item['ready'])
        self.assertTrue(self.original.exists(),'source must remain untouched')
        pack=self.runtime.save_pack({'name':'Road trip','context':'road trip','target_storage_id':self.device['id'],'media_ids':[item['id']],'max_titles':1,'quality':'original'})
        preview=self.runtime.preview_pack(pack['id']);self.assertEqual(len(preview['items']),1)
        receipt=self.run_job('pack',{'id':pack['id'],'confirmed':True})
        self.assertTrue(receipt['verified'])
        self.assertEqual(self.runtime.packs()[0]['state'],'READY_OFFLINE')
        offline=Path(receipt['items'][0]['destination'])
        self.assertEqual(offline.read_bytes(),self.original.read_bytes())
        self.assertTrue(offline.with_suffix('.en.srt').is_file())
        self.assertFalse(any(p.suffix in {'.json','.nfo','.jpg','.xml','.sha256'} for p in offline.parent.iterdir()))
        self.runtime.reconcile_pack(pack['id'],[{'media_id':item['id'],'position':.5,'duration':1,'watched':False}])
        self.assertEqual(self.runtime.media(item['id'])['position'],.5)
    def test_archive_restore_preserves_identity_progress_and_user_sidecars(self):
        item=self.runtime.media(self.prepare()['media_id'])
        self.runtime.progress(item['id'],.5,1)
        old=self.runtime.playable(item['id'])
        archived=self.run_job('archive',{'media_id':item['id'],'storage_id':self.archive['id'],'confirmed':True})
        self.assertFalse(old.exists())
        self.assertTrue(Path(archived['destination']).is_file())
        self.assertTrue(Path(archived['destination']).with_suffix('.en.srt').exists())
        restored=self.run_job('restore',{'media_id':item['id'],'storage_id':self.library['id'],'confirmed':True})
        self.assertTrue(Path(restored['destination']).exists())
        self.assertEqual(self.runtime.media(item['id'])['position'],.5)
        self.assertEqual(self.runtime.media(item['id'])['id'],item['id'])
    def test_daily_episode_automation_reaches_ready_and_surfaces_home(self):
        tracked=self.runtime.track({'title':'Example','kind':'tv','series':'Example','season':1,'episode':2,'source_id':self.source['id'],'auto_prepare':True,'storage_id':self.library['id'],'confirmed':True})
        candidates=self.runtime.discover(tracked['id']);self.assertEqual(len(candidates),1)
        self.runtime.automation_tick()
        self.runtime.run_next()
        state=self.runtime.tracking()[0]
        self.assertEqual(state['state'],'READY_TO_WATCH')
        self.assertEqual(self.runtime.home()['ready_to_watch'][0]['id'],state['media_id'])
        self.assertEqual(self.runtime.home()['next_up'][0]['id'],state['media_id'])
    def test_preferred_replacement_preserves_logical_state(self):
        item=self.runtime.media(self.prepare()['media_id']);self.runtime.progress(item['id'],.5,1)
        other=video(self.base/'inbox'/'Preferred Example.mp4')
        new=self.run_job('prepare',{'source_path':str(other),'storage_id':self.library['id'],'replace_media_id':item['id'],'confirmed':True,'mode':'remux'})
        self.assertEqual(new['media_id'],item['id'])
        self.assertEqual(self.runtime.media(item['id'])['position'],.5)

if __name__=='__main__':unittest.main()
