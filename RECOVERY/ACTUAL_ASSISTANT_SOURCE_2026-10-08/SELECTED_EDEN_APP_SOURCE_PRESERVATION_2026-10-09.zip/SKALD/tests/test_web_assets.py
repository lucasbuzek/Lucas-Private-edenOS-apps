"""Checks for the distributable shell and private-media cache boundary."""
import json
from pathlib import Path
import shutil
import subprocess
import unittest

WEB = Path(__file__).resolve().parents[1] / 'web'


class WebAssetTests(unittest.TestCase):
    def test_manifest_and_external_assets(self):
        manifest = json.loads((WEB / 'manifest.webmanifest').read_text())
        self.assertEqual(manifest['display'], 'standalone')
        html = (WEB / 'index.html').read_text()
        self.assertIn('src="/app.js"', html)
        self.assertIn('href="/style.css"', html)
        self.assertNotIn('<script>', html)

    def test_javascript_parses(self):
        node = shutil.which('node')
        if not node:
            self.skipTest('Node unavailable')
        for name in ('app.js', 'sw.js'):
            subprocess.run([node, '--check', str(WEB / name)], check=True, capture_output=True)

    def test_cache_excludes_api_and_mutations(self):
        worker = (WEB / 'sw.js').read_text()
        self.assertIn("url.pathname.startsWith('/api/')", worker)
        self.assertIn("event.request.method!=='GET'", worker)
        self.assertIn('!SHELL.includes(url.pathname)', worker)
        app = (WEB / 'app.js').read_text()
        self.assertIn("'X-SKALD-CSRF':csrf", app)
        self.assertIn("credentials:'same-origin'", app)
