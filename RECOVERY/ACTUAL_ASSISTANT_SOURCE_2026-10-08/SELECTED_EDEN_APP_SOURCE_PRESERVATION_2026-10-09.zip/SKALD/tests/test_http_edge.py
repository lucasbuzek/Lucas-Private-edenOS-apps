from .test_http import HttpTests

class HttpEdgeTests(HttpTests):
    def test_empty_file_full_get_and_range(self):
        self.login();self.file.write_bytes(b'')
        route='/api/media/'+self.item['id']+'/stream'
        self.assertEqual(self.req('GET',route)[:2],(200,b''))
        self.assertEqual(self.req('GET',route,headers={'Range':'bytes=0-'})[0],416)
    def test_invalid_fields_return_json_errors(self):
        self.login()
        for body in ({'id':self.item['id'],'position':'bad','duration':10},{'id':{},'position':1,'duration':10},{'id':self.item['id'],'position':-1,'duration':10}):
            self.assertEqual(self.req('POST','/api/progress',body,{'X-SKALD-CSRF':self.csrf})[0],400)
