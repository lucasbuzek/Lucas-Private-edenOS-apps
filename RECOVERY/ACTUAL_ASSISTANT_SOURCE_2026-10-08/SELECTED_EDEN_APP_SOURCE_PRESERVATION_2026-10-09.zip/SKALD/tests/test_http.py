import http.client
import json
from pathlib import Path
import tempfile
import threading
import unittest
from skald_runtime.core import Runtime
try:
    from skald_runtime.http import Server
except ImportError:Server=None

class HttpTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='skald-http-');self.base=Path(self.temp.name)
        self.runtime=Runtime(self.base/'data')
        self.assertIsNotNone(Server,'recovered HTTP streaming/API not implemented')
        self.folder=self.base/'library';self.folder.mkdir();self.file=self.folder/'Movie.mp4';self.file.write_bytes(b'0123456789')
        source=self.runtime.add_source('Fixture','local',str(self.folder));self.runtime.scan(source['id']);self.item=self.runtime.library()['items'][0]
        self.server=Server(('127.0.0.1',0),self.runtime)
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
        self.port=self.server.server_port;self.cookie='';self.csrf=''
    def tearDown(self):
        if hasattr(self,'server'):self.server.shutdown();self.server.server_close();self.thread.join(2)
        self.runtime.close();self.temp.cleanup()
    def req(self,method,route,body=None,headers=None):
        conn=http.client.HTTPConnection('127.0.0.1',self.port,timeout=3)
        h={'Cookie':self.cookie};h.update(headers or {})
        if body is not None:h['Content-Type']='application/json';body=json.dumps(body)
        conn.request(method,route,body,h);response=conn.getresponse();value=response.read();rh=dict(response.getheaders());conn.close()
        if 'Set-Cookie' in rh:self.cookie=rh['Set-Cookie'].split(';')[0]
        return response.status,value,rh
    def login(self):
        status,body,_=self.req('GET','/api/session');self.assertEqual(status,200);self.csrf=json.loads(body)['csrf']
    def test_authorized_ranges_suffix_head_and_unsatisfiable(self):
        route='/api/media/'+self.item['id']+'/stream'
        self.assertEqual(self.req('GET',route)[0],401)
        self.login()
        status,value,h=self.req('GET',route,headers={'Range':'bytes=2-5'})
        self.assertEqual((status,value),(206,b'2345'));self.assertEqual(h['Content-Range'],'bytes 2-5/10')
        self.assertEqual(self.req('GET',route,headers={'Range':'bytes=-3'})[:2],(206,b'789'))
        self.assertEqual(self.req('GET',route,headers={'Range':'bytes=99-'})[0],416)
        status,value,h=self.req('HEAD',route);self.assertEqual((status,value),(200,b''));self.assertEqual(h['Content-Length'],'10')
    def test_csrf_and_host_validation(self):
        self.login()
        self.assertEqual(self.req('POST','/api/progress',{'id':self.item['id'],'position':1,'duration':10})[0],403)
        self.assertEqual(self.req('POST','/api/progress',{'id':self.item['id'],'position':1,'duration':10}, {'X-SKALD-CSRF':self.csrf})[0],200)
        self.assertEqual(self.req('GET','/api/library',headers={'Host':'hostile.invalid'})[0],403)
        self.assertEqual(self.req('POST','/api/progress',{}, {'Origin':'https://hostile.invalid','X-SKALD-CSRF':self.csrf})[0],403)
    def test_library_broadcast_token_read_scope(self):
        self.assertEqual(self.req('GET','/api/library',headers={'Authorization':'Bearer '+self.server.broadcast_token})[0],200)
        self.assertEqual(self.req('GET','/api/storage',headers={'Authorization':'Bearer '+self.server.broadcast_token})[0],403)
        status,body,_=self.req('GET','/api/library',headers={'Authorization':'Bearer '+self.server.broadcast_token})
        self.assertNotIn(str(self.folder),body.decode())

if __name__=='__main__':unittest.main()
