import json
from pathlib import Path
import tempfile
import unittest

try:
    from skald_runtime.core import Runtime
except ImportError:
    Runtime = None

class DomainTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='skald-domain-')
        self.base = Path(self.temp.name)
        self.assertIsNotNone(Runtime, 'recovered domain runtime is not implemented')
        self.runtime = Runtime(self.base / 'app-data')
        self.media = self.base / 'media'
        self.media.mkdir()
        self.movie = self.media / 'Arrival (2016).mp4'
        self.movie.write_bytes(b'controlled movie fixture')
        self.source = self.runtime.add_source('Library', 'local', str(self.media))
    def tearDown(self):
        if hasattr(self,'runtime'):
            self.runtime.close()
        self.temp.cleanup()
    def scan(self):
        job = self.runtime.enqueue('scan', {'source_id':self.source['id']})
        self.runtime.run_next()
        self.assertEqual(self.runtime.job(job['id'])['state'], 'SUCCEEDED')
        return self.runtime.library()['items']
    def test_identity_dedup_offline_and_search(self):
        item = self.scan()[0]
        self.runtime.progress(item['id'], 90, 300)
        copy = self.media / 'Alternate filename.mp4'
        copy.write_bytes(self.movie.read_bytes())
        self.assertEqual(len(self.scan()), 1)
        self.assertEqual(len(self.runtime.media(item['id'])['locations']), 2)
        self.assertEqual(self.runtime.library(q='arrival')['items'][0]['id'], item['id'])
        self.movie.unlink();copy.unlink()
        offline = self.scan()[0]
        self.assertTrue(offline['offline'])
        self.assertEqual(offline['position'],90)
    def test_home_continuity_collections_tracking_and_metadata(self):
        item = self.scan()[0]
        self.runtime.progress(item['id'],90,300)
        self.assertEqual(self.runtime.home()['continue_watching'][0]['id'], item['id'])
        self.runtime.correct_metadata(item['id'], {'title':'Arrival','year':2016,'summary':'A linguist meets visitors.'})
        self.assertEqual(self.runtime.media(item['id'])['summary'],'A linguist meets visitors.')
        collection = self.runtime.save_collection('Favourites',[item['id']])
        self.assertEqual(self.runtime.collections()[0]['media_ids'],[item['id']])
        tracked = self.runtime.track({'title':'Show','kind':'tv','series':'Show','season':1,'episode':2,'release_at':'2099-01-01T00:00:00Z','source_id':self.source['id']})
        self.assertEqual(tracked['state'],'EXPECTED')
        self.assertEqual(self.runtime.home()['upcoming'][0]['id'],tracked['id'])
    def test_jobs_survive_restart_and_failures_enter_review(self):
        job = self.runtime.enqueue('scan', {'source_id':self.source['id']})
        self.runtime.close()
        self.runtime = Runtime(self.base/'app-data')
        self.runtime.run_next()
        self.assertEqual(self.runtime.job(job['id'])['state'],'SUCCEEDED')
        job = self.runtime.enqueue('scan',{'source_id':'missing'})
        self.runtime.run_next()
        self.assertEqual(self.runtime.job(job['id'])['state'],'REVIEW')
        self.assertEqual(self.runtime.reviews()[0]['job_id'],job['id'])
    def test_backup_contains_library_state_without_user_media(self):
        item = self.scan()[0]
        self.runtime.progress(item['id'],30,300)
        backup = self.runtime.backup()
        self.assertTrue(Path(backup['path']).is_file())
        import sqlite3
        with sqlite3.connect(backup['path']) as db:
            self.assertEqual(db.execute('SELECT position FROM media WHERE id=?',(item['id'],)).fetchone()[0],30)
        self.assertEqual(sorted(x.name for x in self.media.iterdir()),['Arrival (2016).mp4'])
    def test_media_write_jobs_require_explicit_confirmation(self):
        with self.assertRaises(ValueError):
            self.runtime.enqueue('archive', {'media_id':'unknown','storage_id':'unknown'})

if __name__=='__main__':unittest.main()
