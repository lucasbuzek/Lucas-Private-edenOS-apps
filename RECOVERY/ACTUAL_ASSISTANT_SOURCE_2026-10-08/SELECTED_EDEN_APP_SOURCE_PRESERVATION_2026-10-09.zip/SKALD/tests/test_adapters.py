import hashlib
import json
from pathlib import Path
import subprocess
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer
from skald_runtime import adapters

class MediaTests(unittest.TestCase):
    def test_real_media_pipeline(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); source=root/'source.mp4'
            subprocess.run(['/opt/homebrew/bin/ffmpeg','-v','error','-f','lavfi','-i','color=c=blue:s=64x64:d=1','-f','lavfi','-i','sine=frequency=440:duration=1','-c:v','libx264','-c:a','aac','-shortest',str(source)],check=True)
            before=hashlib.sha256(source.read_bytes()).hexdigest()
            tools=adapters.MediaTools(root/'data')
            info=tools.inspect(source)
            self.assertGreater(info['duration'],0)
            self.assertEqual({'audio','video'}, {s['codec_type'] for s in info['streams']})
            direct=root/'copy.mp4'; tools.prepare(source,direct)
            self.assertEqual(source.read_bytes(),direct.read_bytes())
            with self.assertRaises(FileExistsError): tools.prepare(source,direct)
            remux=root/'remux.mp4'; result=tools.prepare(source,remux,'remux',{'title':'Corrected title'})
            self.assertEqual(result['tags']['title'],'Corrected title')
            self.assertEqual(info['streams'][0]['codec_name'],result['streams'][0]['codec_name'])
            tools.prepare(source,root/'transcode.mp4','transcode')
            art=tools.capture_artwork(source,'fixture')
            self.assertTrue(art.is_file()); self.assertEqual(art.parent,root/'data'/'artwork')
            self.assertEqual(before,hashlib.sha256(source.read_bytes()).hexdigest())
            with self.assertRaises(ValueError): tools.prepare(source,root/'bad.mp4','automatic')
            invalid=root/'invalid.mp4'; invalid.write_text('invalid')
            with self.assertRaises(RuntimeError): tools.prepare(invalid,root/'failed.mp4')
            self.assertFalse((root/'failed.mp4').exists())
            self.assertTrue(any(x['name']=='ffmpeg' and x['available'] for x in tools.capabilities()))

class RpcTests(unittest.TestCase):
    def test_handshake_and_normalization(self):
        seen=[]
        class Handler(BaseHTTPRequestHandler):
            def log_message(self,*args): pass
            def do_POST(self):
                request=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
                if self.headers.get('X-Transmission-Session-Id')!='fixture-session':
                    self.send_response(409); self.send_header('X-Transmission-Session-Id','fixture-session'); self.end_headers(); return
                seen.append(request)
                self.send_response(200); self.end_headers()
                args={'torrents':[{'id':1,'name':'Fixture'}]} if request['method']=='torrent-get' else {'torrent-added':{'id':1}}
                self.wfile.write(json.dumps({'result':'success','arguments':args}).encode())
        server=HTTPServer(('127.0.0.1',0),Handler); thread=threading.Thread(target=server.serve_forever,daemon=True); thread.start()
        try:
            client=adapters.TransmissionClient('http://127.0.0.1:%s/transmission/rpc'%server.server_port)
            self.assertEqual(client.add('magnet:?xt=urn:btih:'+'a'*40,Path('/tmp'))['torrent-added']['id'],1)
            self.assertEqual(client.status([1])[0]['name'],'Fixture')
            self.assertEqual(seen[0]['arguments']['download-dir'],'/tmp')
            self.assertEqual(adapters.normalize_candidate('magnet:?xt=urn:btih:'+'a'*40)['kind'],'magnet')
            with self.assertRaises(ValueError): adapters.normalize_candidate('https://example.com/file')
        finally: server.shutdown(); server.server_close(); thread.join()
