"""Real subprocess handoff proofs; fixture host is not a BIFROST adapter."""
import http.cookiejar
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import unittest
from urllib.request import HTTPCookieProcessor, Request, build_opener, urlopen

from skald_runtime.core import Runtime
try:
    from skald_runtime.hosting import HostingController, BifrostDriver
except ImportError:
    HostingController = BifrostDriver = None

ENTRY = Path(__file__).resolve().parents[1] / 'skald.py'
CONTRACT = {'name':'skald-runtime-host','version':1,'ready':True,
            'same_entry':True,'same_data_dir':True,'exclusive_owner':True}


class ProcessHostDriver:
    """Controlled host fixture launches the sole production core entry."""
    def __init__(self):
        self.available = True
        self.compatible = True
        self.child = None
        self.state = None
        self.prepared = None

    def probe(self):
        if not self.available:
            raise OSError('Fixture host is unavailable')
        return {'hosting':dict(CONTRACT) if self.compatible else {}}

    def prepare(self, entry, data_dir):
        self.probe()
        self.prepared = (entry, data_dir)
        return True

    def start(self, entry, data_dir):
        if self.prepared != (entry, data_dir):
            raise RuntimeError('Unprepared host launch')
        self.child = subprocess.Popen([sys.executable,str(entry),'--data-dir',str(data_dir),'--port','0'],
                                      stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        for _ in range(200):
            try:
                state = json.loads((data_dir/'runtime.json').read_text())
                if state['pid']==self.child.pid:
                    with urlopen(state['url']+'/api/session',timeout=.5) as response:
                        json.load(response)
                    self.state = state
                    return state
            except (OSError,ValueError):
                pass
            if self.child.poll() is not None:
                raise RuntimeError('Host-owned runtime failed to start')
            time.sleep(.025)
        raise RuntimeError('Host launch timeout')

    def status(self):
        if self.child and self.child.poll() is None:
            return self.state
        return None

    def stop(self):
        if self.child and self.child.poll() is None:
            self.child.terminate()
            self.child.wait(timeout=10)
        self.state = None

    def lose_host(self, stop_runtime=True):
        self.available = False
        if stop_runtime:
            self.stop()


class HostingTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(HostingController,'Process lifecycle hosting coordinator is absent')
        self.tmp = tempfile.TemporaryDirectory(prefix='skald-hosting-')
        self.addCleanup(self.tmp.cleanup)
        self.data = Path(self.tmp.name)/'data'
        self.driver = ProcessHostDriver()
        self.addCleanup(self.driver.stop)
        self.controller = HostingController(ENTRY,self.data,self.driver)
        self.addCleanup(self.controller.close)

    def request(self,state,route,data=None):
        opener = build_opener(HTTPCookieProcessor(http.cookiejar.CookieJar()))
        with opener.open(state['runtime']['url']+'/api/session',timeout=3) as response:
            session = json.load(response)
        request = Request(state['runtime']['url']+'/api/'+route,
                          data=json.dumps(data).encode() if data is not None else None,
                          headers={'Content-Type':'application/json','X-SKALD-CSRF':session['csrf']})
        with opener.open(request,timeout=3) as response:
            return json.load(response)

    def seed(self):
        media = Path(self.tmp.name)/'media'
        media.mkdir()
        (media/'Arrival (2016).mp4').write_bytes(b'fixture media content')
        runtime = Runtime(self.data)
        try:
            source = runtime.add_source('Fixture','local',str(media))
            runtime.scan(source['id'])
            return runtime.library()['items'][0]['id']
        finally:
            runtime.close()

    def test_http_progress_survives_real_delegate_host_loss_and_retake(self):
        identifier = self.seed()
        standalone = self.controller.ensure_standalone()
        old_pid = standalone['runtime']['pid']
        self.request(standalone,'progress',{'id':identifier,'position':45,'duration':120})
        delegated = self.controller.delegate()
        self.assertEqual(delegated['mode'],'shared')
        self.assertNotEqual(delegated['runtime']['pid'],old_pid)
        with self.assertRaises(ProcessLookupError):
            os.kill(old_pid,0)
        item = self.request(delegated,'media/'+identifier)
        self.assertEqual(item['position'],45)
        self.request(delegated,'progress',{'id':identifier,'position':120,'duration':120,'watched':True})
        old_host_pid = delegated['runtime']['pid']
        self.driver.lose_host()
        retaken = self.controller.poll()
        self.assertEqual(retaken['mode'],'standalone')
        with self.assertRaises(ProcessLookupError):
            os.kill(old_host_pid,0)
        item = self.request(retaken,'media/'+identifier)
        self.assertTrue(item['watched'])
        self.assertEqual(item['position'],120)
        self.assertEqual(Path(retaken['runtime']['data_dir']),self.data.resolve())

    def test_incompatible_host_does_not_stop_standalone(self):
        state = self.controller.ensure_standalone()
        self.driver.compatible = False
        with self.assertRaisesRegex(RuntimeError,'compatible'):
            self.controller.delegate()
        self.assertEqual(self.controller.poll()['runtime']['pid'],state['runtime']['pid'])
        self.request(state,'library')

    def test_lost_host_heartbeat_does_not_duplicate_live_runtime(self):
        self.controller.ensure_standalone()
        state = self.controller.delegate()
        self.driver.lose_host(stop_runtime=False)
        result = self.controller.poll()
        self.assertEqual(result['runtime']['pid'],state['runtime']['pid'])
        self.assertEqual(result['mode'],'shared')
        self.assertTrue(result['degraded'])
        self.request(result,'library')

    def test_user_retake_stops_host_before_launching_standalone(self):
        self.controller.ensure_standalone()
        shared = self.controller.delegate()
        state = self.controller.retake()
        self.assertEqual(state['mode'],'standalone')
        self.assertNotEqual(state['runtime']['pid'],shared['runtime']['pid'])
        self.assertIsNotNone(self.driver.child.poll())

    def test_exclusive_coordinator_prevents_competing_transition_owner(self):
        with self.assertRaisesRegex(RuntimeError,'coordinator'):
            HostingController(ENTRY,self.data,self.driver)

    def test_close_deliberately_stops_runtime(self):
        self.controller.ensure_standalone()
        state = self.controller.delegate()
        self.controller.close()
        self.assertIsNotNone(self.driver.child.poll())
        with self.assertRaises(OSError):
            urlopen(state['runtime']['url']+'/api/session',timeout=.5)

    def test_failed_shared_launch_restores_standalone(self):
        self.controller.ensure_standalone()
        original = self.driver.start
        def fail(entry,data_dir):
            raise OSError('Injected host launch failure')
        self.driver.start = fail
        with self.assertRaisesRegex(OSError,'Injected'):
            self.controller.delegate()
        state = self.controller.poll()
        self.assertEqual(state['mode'],'standalone')
        self.request(state,'library')
        self.driver.start = original


class CompatibilityTests(unittest.TestCase):
    def test_bifrost_status_without_explicit_contract_is_incompatible(self):
        self.assertIsNotNone(BifrostDriver,'HTTP host adapter is absent')
        from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
        from threading import Thread
        received = []
        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                received.append((self.path,self.headers.get('X-EDEN-Token')))
                body = json.dumps({'status':'running','version':'fixture'}).encode()
                self.send_response(200);self.end_headers();self.wfile.write(body)
            def log_message(self,*args):
                pass
        server = ThreadingHTTPServer(('127.0.0.1',0),Handler)
        thread = Thread(target=server.serve_forever,daemon=True);thread.start()
        self.addCleanup(server.server_close)
        self.addCleanup(server.shutdown)
        driver = BifrostDriver(f'http://127.0.0.1:{server.server_port}','fixture-secret')
        result = driver.probe()
        self.assertFalse(result['compatible'])
        self.assertIn('contract',result['reason'])
        self.assertEqual(received,[('/api/status','fixture-secret')])
