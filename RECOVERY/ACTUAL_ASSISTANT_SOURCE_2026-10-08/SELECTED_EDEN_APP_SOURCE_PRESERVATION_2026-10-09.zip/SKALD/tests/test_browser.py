import os
from pathlib import Path
import shutil
import subprocess
import sys
import unittest

class BrowserTests(unittest.TestCase):
    @unittest.skipUnless(Path('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome').exists() and shutil.which('node') and shutil.which('ffmpeg'),'Chrome, Node and FFmpeg required for real browser fixture')
    def test_recovered_headless_web_workflows(self):
        result=subprocess.run(['node','verification/headless-browser.mjs'],capture_output=True,text=True,env=dict(os.environ,SKALD_TEST_PYTHON=sys.executable),timeout=100)
        self.assertEqual(result.returncode,0,result.stdout+result.stderr)
        self.assertIn('ENVIRONMENT PASS',result.stdout)
        print(result.stdout.strip())
