import Cocoa
import Foundation

final class Service {
    let process = Process()
    let temporary = FileManager.default.temporaryDirectory.appendingPathComponent("skald-launch-" + UUID().uuidString)
    var url: URL?
    var log: FileHandle?
    func start() throws {
        try FileManager.default.createDirectory(at: temporary, withIntermediateDirectories: true)
        let ready = temporary.appendingPathComponent("ready.json")
        let resources = Bundle.main.resourceURL!
        let core = resources.appendingPathComponent("core/skald.py")
        let candidates = [ProcessInfo.processInfo.environment["SKALD_PYTHON"], "/opt/homebrew/bin/python3", "/usr/local/bin/python3", "/usr/bin/python3"].compactMap { $0 }
        var python: String?
        for candidate in candidates where FileManager.default.isExecutableFile(atPath: candidate) {
            let probe = Process()
            probe.executableURL = URL(fileURLWithPath: candidate)
            probe.arguments = ["-c", "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)"]
            probe.standardOutput = FileHandle.nullDevice
            probe.standardError = FileHandle.nullDevice
            if (try? probe.run()) != nil { probe.waitUntilExit(); if probe.terminationStatus == 0 { python = candidate; break } }
        }
        guard let python else { throw failure("Python 3.10 or newer is required. Install Python or set SKALD_PYTHON to its executable path.") }
        process.executableURL = URL(fileURLWithPath: python)
        process.arguments = [core.path, "--port", "0", "--ready-file", ready.path]
        FileManager.default.createFile(atPath: temporary.appendingPathComponent("service.log").path, contents: nil)
        log = try FileHandle(forWritingTo: temporary.appendingPathComponent("service.log"))
        process.standardOutput = log
        process.standardError = log
        try process.run()
        for _ in 0..<200 {
            if let data = try? Data(contentsOf: ready), let value = try? JSONSerialization.jsonObject(with: data) as? [String: Any], let address = value["url"] as? String, let parsed = URL(string: address) {
                url = parsed
                return
            }
            if !process.isRunning { break }
            Thread.sleep(forTimeInterval: 0.05)
        }
        let detail = (try? String(contentsOf: temporary.appendingPathComponent("service.log"), encoding: .utf8)) ?? "No service output"
        throw failure("The local service could not start.\n" + detail)
    }
    func stop() {
        if process.isRunning { process.terminate(); process.waitUntilExit() }
        try? log?.close()
        try? FileManager.default.removeItem(at: temporary)
    }
    func failure(_ description: String) -> NSError { NSError(domain: "SKALD", code: 1, userInfo: [NSLocalizedDescriptionKey: description]) }
}

let service = Service()
if CommandLine.arguments.contains("--smoke-test") {
    do {
        try service.start()
        let status = try Data(contentsOf: service.url!.appendingPathComponent("api/status"))
        let value = try JSONSerialization.jsonObject(with: status) as! [String: Any]
        let manifest = try Data(contentsOf: Bundle.main.resourceURL!.appendingPathComponent("package-manifest.json"))
        let metadata = try JSONSerialization.jsonObject(with: manifest) as! [String: Any]
        guard value["version"] as? String == metadata["version"] as? String else { throw service.failure("Package/service version mismatch") }
        print("ENVIRONMENT PASS: native launcher started packaged shared core; version \(value["version"]!); loopback HTTP responded")
        service.stop()
        exit(0)
    } catch {
        fputs(error.localizedDescription + "\n", stderr)
        service.stop()
        exit(1)
    }
}

final class Delegate: NSObject, NSApplicationDelegate {
    var window: NSWindow!
    func applicationDidFinishLaunching(_ notification: Notification) {
        do {
            try service.start()
            window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 520, height: 230), styleMask: [.titled, .closable, .miniaturizable], backing: .buffered, defer: false)
            window.title = "SKALD — StoryKeeper"
            window.center()
            let label = NSTextField(wrappingLabelWithString: "SKALD is running locally at \(service.url!.absoluteString)\n\nYour library stays on this Mac. Use the Web UI to browse media, record progress, and plan Travel Packs. Quit SKALD to stop its service.")
            label.frame = NSRect(x: 24, y: 80, width: 470, height: 125)
            window.contentView!.addSubview(label)
            let button = NSButton(title: "Open SKALD", target: self, action: #selector(openLibrary))
            button.frame = NSRect(x: 24, y: 25, width: 150, height: 36)
            window.contentView!.addSubview(button)
            let menu = NSMenu()
            let item = NSMenuItem()
            menu.addItem(item)
            let appMenu = NSMenu()
            appMenu.addItem(withTitle: "Quit SKALD", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")
            item.submenu = appMenu
            NSApp.mainMenu = menu
            window.makeKeyAndOrderFront(nil)
            NSApp.activate(ignoringOtherApps: true)
            openLibrary()
        } catch {
            let alert = NSAlert()
            alert.messageText = "SKALD could not start"
            alert.informativeText = error.localizedDescription
            alert.runModal()
            NSApp.terminate(nil)
        }
    }
    @objc func openLibrary() { if let url = service.url { NSWorkspace.shared.open(url) } }
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { true }
    func applicationWillTerminate(_ notification: Notification) { service.stop() }
}
let app = NSApplication.shared
let delegate = Delegate()
app.delegate = delegate
app.setActivationPolicy(.regular)
app.run()
