# SKALD — StoryKeeper Archive Lifestyle Delivery

## Authority and provenance

This is the first local SKALD project record, created from the user's recovery
brief on 2026-10-01 and the global `#appDev Bible`. No SKALD Project Bible,
source, package, or Git repository was present in the workspace during recovery.
This document records the supplied product direction and identifies unspecified
requirements; it does not claim to recover prior conversation details.

Authority order follows `#appDev Bible/APPDEV_BIBLE.txt`: newest explicit user
decision, frozen AppDev canon, project canon, verified evidence, then older valid
implementation/provenance.

## Established product direction

SKALD is a private/custom media-center and media-library system. It is intended
to provide a macOS application, standalone headless/service capability, web UI,
local-first operation, a unified library, Movies and TV browsing,
tracking/discovery, jobs/activity, review queue, storage management,
settings/diagnostics/admin, native Apple integration, native media-app launch,
metadata/artwork management, watched/progress/resume state, device/library
synchronization, external/NAS storage, iPhone/iPad streaming, Travel Packs, daily
episode automation, modular providers, Siri, and AppleScript/Automator support.

SKALD remains standalone. Compatible BIFROST infrastructure may host generic
headless/runtime responsibilities, but SKALD owns its domain logic, data, APIs,
and standalone capability. BIFROST is never mandatory.

Preserve the established concept and exact name: **THE PANTHEON — A SKALD
Picture Palace**. It is the private family/friends shared-viewing experience.
Its detailed requirements have not been recovered and remain pending; do not
implement or rename that concept based on guesses.

## Global engineering canon

- Local first; user data outlives software; integrations are adapters.
- Prefer OS/native capability, installed software, small established libraries,
  engines, providers, and custom code in that order.
- Build only the unsolved gap; make automation explainable and keep one
  authoritative path.
- Evidence states remain distinct: implemented, built, tested, and verified are
  separate. Unknown is never pass.
- User data migration must detect, validate, stage/backup, migrate, verify,
  commit, and roll back on failure.

## First baseline scope

The initial implementation is a small local headless HTTP service with a browser
UI. It indexes user-selected folders of video files into SQLite, lists Movies
and TV, persists watched state, and hands a selected local file to macOS's
registered media application. It has no external runtime dependencies and can
run independently of BIFROST.

Initial classification rule (implementation choice, not recovered canon): a
file is placed under TV when its path includes a conventional `Season N` or
`SxxExx` episode marker; otherwise it is placed under Movies. The index stores
file identity/path and filesystem facts only. It does not fabricate provider
metadata, artwork, playback progress, review decisions, or sync state.

## Requirements explicitly pending recovery

- Detailed acceptance requirements for every listed capability.
- Pantheon membership, invitations, access control, room/session behavior,
  device roles, synchronization, moderation, and privacy rules.
- Supported media formats, metadata/artwork providers, matching precedence,
  conflict resolution, and offline behavior.
- Library schema, backup/restore, migration policy, identity model, and sync
  conflict policy.
- Streaming/transcoding behavior, supported clients, bandwidth and security
  requirements, Travel Pack format/expiry, and download rules.
- Daily episode automation source, scheduling semantics, approval/review rules,
  and failure handling.
- macOS deployment target, signing/notarization/distribution profile, and
  whether the native application must embed the service or supervise it.
- Siri intents, AppleScript/Automator vocabulary, device synchronization
  semantics, and BIFROST integration contract.

These remain recovery-pending; the first baseline must not be treated as the
complete product definition.

## Account-migration reconciliation — 2026-10-02

The new user's account-migration handoff supplies newer product continuity and
execution scope. The “first baseline” and pending-recovery sections above
record the prior session's implementation limits; they do not override the
new handoff. Recovery found the previous-account Python service, tests and a
matching source ZIP. It found no historical 0.9.x source. See
`RECOVERY_REPORT.md` for demonstrated state and `HANDOFF.md` for the current
execution position. These records do not create replacement historical canon.
