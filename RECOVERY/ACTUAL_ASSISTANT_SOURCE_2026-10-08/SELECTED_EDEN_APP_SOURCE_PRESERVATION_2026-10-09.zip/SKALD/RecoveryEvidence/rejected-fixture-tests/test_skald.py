import http.client
import json
import sqlite3
import shutil
from unittest.mock import patch
import tempfile
import threading
import time
import unittest
from http.server import ThreadingHTTPServer
from pathlib import Path

import skald


class LibraryHTTPTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="skald-verify-")
        self.original_data_dir, self.original_db_path = skald.DATA_DIR, skald.DB_PATH
        skald.DATA_DIR = Path(self.temp.name) / "data"
        skald.DB_PATH = skald.DATA_DIR / "library.sqlite3"
        skald.initialize()
        self.library = Path(self.temp.name) / "media"
        (self.library / "Movies").mkdir(parents=True)
        (self.library / "Shows" / "Season 01").mkdir(parents=True)
        (self.library / "Movies" / "Example Movie.mp4").write_bytes(b"movie bytes")
        (self.library / "Shows" / "Season 01" / "Show S01E01.mkv").write_bytes(b"episode bytes")
        (self.library / "readme.txt").write_text("not media")
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), skald.Handler)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.port = self.server.server_address[1]

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)
        skald.DATA_DIR, skald.DB_PATH = self.original_data_dir, self.original_db_path
        self.temp.cleanup()

    def request(self, method, path, value=None, extra_headers=None):
        conn = http.client.HTTPConnection("127.0.0.1", self.port, timeout=3)
        body = json.dumps(value).encode() if value is not None else None
        headers = {"Content-Type": "application/json"} if body else {}
        headers.update(extra_headers or {})
        conn.request(method, path, body=body, headers=headers)
        response = conn.getresponse()
        result = json.loads(response.read())
        status = response.status
        conn.close()
        return status, result

    def test_add_scan_browse_and_persist_watched_state(self):
        status, root = self.request("POST", "/api/roots", {"path": str(self.library)})
        self.assertEqual(status, 201)
        status, _ = self.request("POST", "/api/scan", {"id": root["id"]})
        self.assertEqual(status, 202)
        for _ in range(100):
            _, state = self.request("GET", "/api/status")
            if state["jobs"] and state["jobs"][0]["state"] != "running":
                break
            time.sleep(0.02)
        self.assertEqual(state["jobs"][0]["state"], "completed")
        self.assertEqual(state["count"], 2)
        _, movies = self.request("GET", "/api/library?kind=movie")
        _, shows = self.request("GET", "/api/library?kind=tv")
        self.assertEqual([x["title"] for x in movies["items"]], ["Example Movie"])
        self.assertEqual([x["title"] for x in shows["items"]], ["Show S01E01"])
        movie_id = movies["items"][0]["id"]
        self.assertEqual(self.request("POST", "/api/watched", {"id": movie_id, "watched": True})[0], 200)
        _, movies = self.request("GET", "/api/library?kind=movie")
        self.assertTrue(movies["items"][0]["watched"])

    def scan_library(self):
        _, root = self.request("POST", "/api/roots", {"path": str(self.library)})
        self.assertEqual(self.request("POST", "/api/scan", {"id": root["id"]})[0], 202)
        for _ in range(100):
            _, state = self.request("GET", "/api/status")
            if state["jobs"] and state["jobs"][0]["state"] != "running":
                self.assertEqual(state["jobs"][0]["state"], "completed")
                return root
            time.sleep(.02)
        self.fail("scan did not finish")

    def test_missing_media_retains_identity_and_watched(self):
        self.scan_library()
        _, movies = self.request("GET", "/api/library?kind=movie")
        item = movies["items"][0]
        self.request("POST", "/api/watched", {"id": item["id"], "watched": True})
        path = Path(item["path"])
        contents = path.read_bytes()
        path.unlink()
        self.scan_library()
        _, movies = self.request("GET", "/api/library?kind=movie")
        self.assertEqual(len(movies["items"]), 1, "offline records must survive scans")
        self.assertFalse(movies["items"][0]["available"])
        self.assertTrue(movies["items"][0]["watched"])
        path.write_bytes(contents)
        self.scan_library()
        _, movies = self.request("GET", "/api/library?kind=movie")
        self.assertEqual(movies["items"][0]["id"], item["id"])
        self.assertTrue(movies["items"][0]["available"])
        self.assertTrue(movies["items"][0]["watched"])

    def test_progress_collections_and_travel_plan_persist(self):
        self.scan_library()
        _, movies = self.request("GET", "/api/library?kind=movie")
        item = movies["items"][0]
        self.assertEqual(self.request("POST", "/api/progress", {"id": item["id"], "position": 120, "duration": 600})[0], 200)
        _, movies = self.request("GET", "/api/library?kind=movie")
        self.assertEqual(movies["items"][0]["position"], 120)
        status, collection = self.request("POST", "/api/collections", {"name": "Weekend", "media_ids": [item["id"]]})
        self.assertEqual(status, 201)
        status, pack = self.request("POST", "/api/packs", {"name": "Getaway", "media_ids": [item["id"]], "max_bytes": item["size"], "max_titles": 1})
        self.assertEqual(status, 201)
        skald.initialize()
        _, collections = self.request("GET", "/api/collections")
        self.assertEqual(collections["collections"][0]["media_ids"], [item["id"]])
        _, plan = self.request("GET", "/api/packs/" + pack["id"] + "/plan")
        self.assertEqual(plan["total_bytes"], item["size"])
        self.assertEqual(plan["items"][0]["id"], item["id"])
        self.assertEqual(plan["operation"], "plan_only")
        self.assertEqual(Path(item["path"]).read_bytes(), b"movie bytes")
        self.assertEqual(self.request("POST", "/api/progress", {"id": item["id"], "position": -1, "duration": 600})[0], 400)
        self.assertEqual(self.request("POST", "/api/watched", {"id": item["id"], "watched": "false"})[0], 400)

    def test_music_and_budget_exclusion(self):
        (self.library / "Song.m4a").write_bytes(b"music")
        self.scan_library()
        status, music = self.request("GET", "/api/library?kind=music")
        self.assertEqual(status, 200)
        self.assertEqual(music["items"][0]["category"], "music")
        _, pack = self.request("POST", "/api/packs", {"name": "Tiny", "media_ids": [music["items"][0]["id"]], "max_bytes": 1, "max_titles": 1})
        _, plan = self.request("GET", "/api/packs/" + pack["id"] + "/plan")
        self.assertEqual(plan["items"], [])
        self.assertEqual(plan["excluded"][0]["reason"], "size_limit")

    def test_cross_origin_and_rebinding_are_rejected(self):
        self.assertEqual(self.request("POST", "/api/roots", {"path": str(self.library)}, {"Origin": "https://hostile.invalid"})[0], 403)
        self.assertEqual(self.request("GET", "/api/status", extra_headers={"Host": "hostile.invalid"})[0], 403)
        self.assertEqual(self.request("POST", "/api/roots", {"path": ""})[0], 400)

    def test_relocate_preserves_state_without_moving_media(self):
        self.scan_library()
        _, movies = self.request("GET", "/api/library?kind=movie")
        item = movies["items"][0]
        self.request("POST", "/api/watched", {"id": item["id"], "watched": True})
        old = Path(item["path"])
        new = old.with_name("Renamed.mp4")
        old.rename(new)
        status, _ = self.request("POST", "/api/relocate", {"id": item["id"], "path": str(new)})
        self.assertEqual(status, 200)
        self.scan_library()
        _, movies = self.request("GET", "/api/library?kind=movie")
        self.assertEqual(len(movies["items"]), 1)
        self.assertEqual(movies["items"][0]["id"], item["id"])
        self.assertTrue(movies["items"][0]["watched"])
        self.assertEqual(new.read_bytes(), b"movie bytes")
        self.assertFalse(old.exists())

    def test_failed_scan_retains_existing_records(self):
        root = self.scan_library()
        self.library.rename(self.library.with_name("offline"))
        self.assertEqual(self.request("POST", "/api/scan", {"id": root["id"]})[0], 202)
        for _ in range(100):
            _, status = self.request("GET", "/api/status")
            if status["jobs"][0]["state"] != "running":
                break
            time.sleep(.02)
        self.assertEqual(status["jobs"][0]["state"], "failed")
        self.assertEqual(status["count"], 2)

    def test_manifest_service_worker_and_web_are_served(self):
        for route, mime in [("/", "text/html"), ("/manifest.webmanifest", "application/manifest+json"), ("/sw.js", "application/javascript")]:
            conn = http.client.HTTPConnection("127.0.0.1", self.port)
            conn.request("GET", route)
            response = conn.getresponse()
            self.assertEqual(response.status, 200)
            self.assertIn(mime, response.getheader("Content-Type"))
            content = response.read().decode()
            if route == "/":
                self.assertIn("Travel Packs", content)
                self.assertIn("/api/progress", content)
            conn.close()

    def test_partial_scan_is_atomic_and_symlinks_are_not_indexed(self):
        self.scan_library()
        (self.library / "Movies" / "New.mp4").write_bytes(b"new")
        original = skald.os.walk
        def broken_walk(*args, **kwargs):
            for row in original(*args, **kwargs):
                yield row
            kwargs["onerror"](OSError("fixture unreadable folder"))
        with patch.object(skald.os, "walk", broken_walk):
            _, root = self.request("POST", "/api/roots", {"path": str(self.library)})
            _, job = self.request("POST", "/api/scan", {"id": root["id"]})
            for _ in range(100):
                with skald.connect() as db:
                    state = db.execute("SELECT state FROM jobs WHERE id=?", (job["job_id"],)).fetchone()[0]
                if state != "running":
                    break
                time.sleep(.02)
        self.assertEqual(state, "failed")
        _, status = self.request("GET", "/api/status")
        self.assertEqual(status["count"], 2)
        outside = Path(self.temp.name) / "private.mp4"
        outside.write_bytes(b"outside")
        (self.library / "link.mp4").symlink_to(outside)
        self.scan_library()
        _, all_items = self.request("GET", "/api/library?kind=all")
        self.assertEqual(len(all_items["items"]), 3)
        self.assertNotIn(str(outside), [x["path"] for x in all_items["items"]])

    def test_legacy_schema_migration_preserves_state_and_backup(self):
        legacy = skald.DATA_DIR / "legacy.sqlite3"
        original = skald.DB_PATH
        with sqlite3.connect(legacy) as db:
            db.executescript("CREATE TABLE roots(id TEXT PRIMARY KEY,path TEXT UNIQUE,added_at TEXT); CREATE TABLE media(id TEXT PRIMARY KEY,root_id TEXT,path TEXT UNIQUE,title TEXT,category TEXT,size INTEGER,modified REAL,watched INTEGER,indexed_at TEXT);")
            db.execute("INSERT INTO roots VALUES('root','/fixture','date')")
            db.execute("INSERT INTO media VALUES('item','root','/fixture/movie.mp4','Movie','movie',1,0,1,'date')")
        try:
            skald.DB_PATH = legacy
            skald.initialize()
            skald.initialize()
            with skald.connect() as db:
                row = db.execute("SELECT * FROM media").fetchone()
                self.assertEqual(row["id"], "item")
                self.assertEqual(row["watched"], 1)
                self.assertEqual(row["position"], 0)
            with sqlite3.connect(legacy.with_suffix(".pre-0.2.sqlite3")) as db:
                self.assertEqual(db.execute("SELECT watched FROM media").fetchone()[0], 1)
                self.assertNotIn("position", [r[1] for r in db.execute("PRAGMA table_info(media)")])
        finally:
            skald.DB_PATH = original

    def test_recreated_original_path_has_distinct_identity(self):
        self.scan_library()
        _, movies = self.request("GET", "/api/library?kind=movie")
        item = movies["items"][0]
        old = Path(item["path"])
        new = old.with_name("Renamed.mp4")
        old.rename(new)
        self.assertEqual(self.request("POST", "/api/relocate", {"id": item["id"], "path": str(new)})[0], 200)
        old.write_bytes(b"different movie")
        self.scan_library()
        _, movies = self.request("GET", "/api/library?kind=movie")
        self.assertEqual(len({x["id"] for x in movies["items"]}), 2)

    def test_pack_budget_uses_current_file_size(self):
        self.scan_library()
        _, movies = self.request("GET", "/api/library?kind=movie")
        item = movies["items"][0]
        _, pack = self.request("POST", "/api/packs", {"name": "Trip", "media_ids": [item["id"]], "max_bytes": item["size"]})
        Path(item["path"]).write_bytes(b"larger contents than original fixture")
        _, plan = self.request("GET", "/api/packs/" + pack["id"] + "/plan")
        self.assertEqual(plan["items"], [])
        self.assertEqual(plan["excluded"][0]["reason"], "size_limit")

    def test_unknown_provider_is_rejected_and_local_is_reported(self):
        status, _ = self.request("POST", "/api/roots", {"path": str(self.library), "provider": "unconfigured-cloud"})
        self.assertEqual(status, 400)
        _, status = self.request("GET", "/api/status")
        self.assertEqual(status["providers"][0]["id"], "local")
        self.assertFalse(status["providers"][0]["writes_media"])

    def test_schema_upgrade_rolls_back_on_failure(self):
        legacy = skald.DATA_DIR / "rollback.sqlite3"
        shutil.copy2(skald.DB_PATH.with_suffix(".pre-0.2.sqlite3"), legacy)
        original = skald.DB_PATH
        class InterruptedUpgrade(sqlite3.Connection):
            def execute(self, sql, parameters=()):
                if sql.startswith("ALTER TABLE media ADD COLUMN duration"):
                    raise sqlite3.OperationalError("fixture interrupted upgrade")
                return super().execute(sql, parameters)
        def failing_connect():
            db = sqlite3.connect(legacy, factory=InterruptedUpgrade)
            db.row_factory = sqlite3.Row
            return db
        try:
            skald.DB_PATH = legacy
            with patch.object(skald, "connect", failing_connect):
                with self.assertRaises(sqlite3.OperationalError):
                    skald.initialize()
            with sqlite3.connect(legacy) as db:
                columns = {r[1] for r in db.execute("PRAGMA table_info(media)")}
                self.assertNotIn("position", columns, "failed upgrades must not commit partial columns")
            skald.initialize()
            with skald.connect() as db:
                self.assertIn("duration", {r["name"] for r in db.execute("PRAGMA table_info(media)")})
        finally:
            skald.DB_PATH = original

    def test_parent_scan_reconciles_child_owned_locations(self):
        child = self.library / "Movies"
        _, child_root = self.request("POST", "/api/roots", {"path": str(child)})
        _, job = self.request("POST", "/api/scan", {"id": child_root["id"]})
        for _ in range(100):
            with skald.connect() as db:
                state = db.execute("SELECT state FROM jobs WHERE id=?", (job["job_id"],)).fetchone()[0]
            if state != "running":
                break
            time.sleep(.02)
        self.assertEqual(state, "completed")
        self.scan_library()
        (child / "Example Movie.mp4").unlink()
        child.rmdir()
        self.scan_library()
        _, movies = self.request("GET", "/api/library?kind=movie")
        self.assertFalse(movies["items"][0]["available"])

    def test_overlapping_scans_are_serialized(self):
        root = self.scan_library()
        _, child_root = self.request("POST", "/api/roots", {"path": str(self.library / "Movies")})
        entered, release = threading.Event(), threading.Event()
        original = skald.LOCAL_STORAGE.inventory
        def slow_inventory(*args):
            entered.set()
            release.wait(3)
            return original(*args)
        with patch.object(skald.LOCAL_STORAGE, "inventory", slow_inventory):
            _, job = self.request("POST", "/api/scan", {"id": root["id"]})
            self.assertTrue(entered.wait(1))
            try:
                status, error = self.request("POST", "/api/scan", {"id": child_root["id"]})
                self.assertEqual(status, 400)
                self.assertIn("overlapping", error["error"])
            finally:
                release.set()
            for _ in range(100):
                with skald.connect() as db:
                    state = db.execute("SELECT state FROM jobs WHERE id=?", (job["job_id"],)).fetchone()[0]
                if state != "running":
                    break
                time.sleep(.02)
            self.assertEqual(state, "completed")

    def test_reject_invalid_root_and_unknown_category(self):
        status, error = self.request("POST", "/api/roots", {"path": str(Path(self.temp.name) / "missing")})
        self.assertEqual(status, 400)
        self.assertTrue(error["error"])
        self.assertEqual(self.request("GET", "/api/library?kind=invalid")[0], 400)


if __name__ == "__main__":
    unittest.main()
