import hashlib
import json
import os
from pathlib import Path
import plistlib
import re
import subprocess
import tempfile
import unittest
import zipfile
import skald

class PackageTests(unittest.TestCase):
    @unittest.skipUnless(os.environ.get('SKALD_PACKAGE_PATH'), 'Set SKALD_PACKAGE_PATH to verify a built package')
    def test_package_integrity_and_native_service_start(self):
        app = Path(os.environ['SKALD_PACKAGE_PATH'])
        contents = app / 'Contents'
        manifest = json.loads((contents / 'Resources/package-manifest.json').read_text())
        self.assertEqual(manifest['version'], skald.VERSION)
        info = plistlib.loads((contents / 'Info.plist').read_bytes())
        self.assertEqual(info['CFBundleShortVersionString'], skald.VERSION.split('-')[0])
        load_commands = subprocess.run(['/usr/bin/otool', '-l', str(contents / 'MacOS/SKALD')], capture_output=True, text=True, check=True).stdout
        minimum = re.search(r'LC_BUILD_VERSION.*?minos (\S+)', load_commands, re.S).group(1)
        self.assertEqual(minimum, info['LSMinimumSystemVersion'], 'Binary/plist minimum OS drift')
        for relative, expected in manifest['files'].items():
            file = contents / relative
            self.assertEqual(hashlib.sha256(file.read_bytes()).hexdigest(), expected, relative)
        core = contents / 'Resources/core'
        for name in ['skald.py', 'storage.py', 'test_skald.py', 'test_service.py', 'test_browser.py']:
            self.assertEqual((core / name).read_bytes(), Path(name).read_bytes(), 'stale package '+name)
        for file in Path('web').iterdir():
            self.assertEqual((core / 'web' / file.name).read_bytes(), file.read_bytes())
        archive = app.parent / f'SKALD-{skald.VERSION}-macOS.zip'
        with zipfile.ZipFile(archive) as bundle:
            for file in app.rglob('*'):
                if file.is_file():
                    self.assertEqual(bundle.read(str(file.relative_to(app.parent))), file.read_bytes())
        with tempfile.TemporaryDirectory(prefix='skald-package-') as data:
            env = dict(os.environ, SKALD_DATA_DIR=data)
            result = subprocess.run([str(contents / 'MacOS/SKALD'), '--smoke-test'], capture_output=True, text=True, env=env, timeout=25)
            self.assertEqual(result.returncode, 0, result.stdout+result.stderr)
            self.assertIn('ENVIRONMENT PASS', result.stdout)
            print(result.stdout.strip())
            tests = subprocess.run(['python3','-m','unittest','test_skald','test_service','test_browser','-v'], cwd=core, capture_output=True, text=True, env=env, timeout=30)
            self.assertEqual(tests.returncode, 0, tests.stdout+tests.stderr)
