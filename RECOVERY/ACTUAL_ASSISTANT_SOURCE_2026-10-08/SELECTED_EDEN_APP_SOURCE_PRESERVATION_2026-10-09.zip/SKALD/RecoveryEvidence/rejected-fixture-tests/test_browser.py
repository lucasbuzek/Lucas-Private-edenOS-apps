import os
from pathlib import Path
import shutil
import subprocess
import sys
import unittest

class BrowserTests(unittest.TestCase):
    @unittest.skipUnless(Path('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome').exists() and shutil.which('node'), 'Chrome and Node are required only for browser verification')
    def test_functional_browser_workflows(self):
        env = dict(os.environ, SKALD_TEST_PYTHON=sys.executable)
        result = subprocess.run(['node', 'verification/browser.mjs'], capture_output=True, text=True, timeout=50, env=env)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn('ENVIRONMENT PASS', result.stdout)
        print(result.stdout.strip())
