"""Real process checks with isolated data; never touches the user's library."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import unittest
import urllib.request


class ProcessTests(unittest.TestCase):
    def test_process_lock_version_and_restart(self):
        with tempfile.TemporaryDirectory(prefix="skald-process-") as directory:
            ready = Path(directory) / "ready.json"
            env = dict(os.environ, SKALD_DATA_DIR=directory)
            args = [sys.executable, "skald.py", "--port", "0", "--ready-file", str(ready)]
            first = subprocess.Popen(args, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            try:
                for _ in range(100):
                    if ready.exists() or first.poll() is not None:
                        break
                    time.sleep(.03)
                self.assertTrue(ready.exists(), "service did not produce readiness evidence")
                state = json.loads(ready.read_text())
                with urllib.request.urlopen(state["url"] + "/api/status") as response:
                    status = json.load(response)
                self.assertEqual(state["version"], status["version"])
                second = subprocess.run(args, env=env, capture_output=True, timeout=5)
                self.assertNotEqual(second.returncode, 0)
                self.assertIn(b"already running", second.stderr)
            finally:
                first.terminate()
                first.communicate(timeout=5)
            self.assertFalse(ready.exists())
            restart = subprocess.Popen(args, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            try:
                for _ in range(100):
                    if ready.exists() or restart.poll() is not None:
                        break
                    time.sleep(.03)
                self.assertTrue(ready.exists(), "standalone could not retake its data after exit")
            finally:
                restart.terminate()
                restart.communicate(timeout=5)

    def test_remote_bind_is_rejected(self):
        result = subprocess.run([sys.executable, "skald.py", "--host", "0.0.0.0"], capture_output=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn(b"loopback", result.stderr)
