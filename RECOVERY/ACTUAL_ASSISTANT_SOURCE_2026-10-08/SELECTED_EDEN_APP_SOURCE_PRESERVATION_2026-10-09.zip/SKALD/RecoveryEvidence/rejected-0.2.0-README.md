# SKALD — StoryKeeper: Archive, Lifestyle & Delivery

Private local candidate **0.2.0-experimental**. This extends source created by
previous-account Codex sessions. It is new implementation, not recovered
historical 0.9.x source. See `PROJECT_BIBLE.md` and `RECOVERY_REPORT.md` for
provenance and exact evidence limits.

## Use

Requires Python **3.10+**. The core uses only the Python standard library and
runs independently of every other EDEN app. On macOS:

```sh
./SKALD.command
```

For headless use: `python3 skald.py --port 8765`. The service permits only
localhost binding. Open `http://127.0.0.1:8765` in a browser. Control-C stops it.
Set `SKALD_DATA_DIR` to choose another data directory; otherwise SQLite lives
in `~/Library/Application Support/SKALD/`. The first schema upgrade retains a
`library.pre-0.2.sqlite3` backup. Only one service can own each data directory.
An occupied port produces an explicit failure rather than silently replacing
another service. Python/POSIX is required; Windows has not been verified.

The macOS `SKALD.app` package supervises the **same bundled core**, chooses a
free loopback port, opens the Web UI in your default browser, and stops its
service when you quit/close the launcher. It requires a separately installed
Python 3.10+; it checks Homebrew, `/usr/local/bin`, `/usr/bin`, or an explicit
`SKALD_PYTHON` executable. A running headless instance using the same data
will be reported rather than duplicated. The package is not signed or
notarized for distribution. It is not installed into `/Applications` by the
build script. The native binary is built for the current Mac architecture with
a macOS 12.0 deployment target; execution on older macOS releases has not been
verified.

## Working workflows

- Add a folder on this Mac, an external volume, or an already mounted share.
  Scans read files without modifying media. Symlinks are excluded. An unreadable
  scan fails atomically and preserves the preceding library snapshot. Nested
  folders are supported; overlapping scans are serialized and a parent scan
  reconciles all media locations beneath it.
- Browse/filter the unified library, Movies, TV and Music. TV is inferred from
  conventional `Season N` or `SxxExx` path markers; this is a heuristic. Titles
  are filenames. Metadata is limited to local filesystem facts.
- Mark watched/unwatched and record resume position/duration in seconds.
  State persists locally; it is not captured from the media player or synced
  across devices. “Open” hands the file to the registered macOS application.
- Missing items retain identity and state. “Relink” associates an existing
  record with a user-specified new path under a configured folder, without
  moving a file. The original must be missing and the destination must not
  already be another indexed record. Automatic move/content matching is absent.
- Select titles across views and save named collections or Travel Packs.
  Optional Pack limits use bytes/title count. Planning checks current file
  sizes and availability, keeps selection order, and reports exclusions.
  Download the JSON planning manifest locally. Definitions persist separately
  from media; no media copies, device sync, transcoding or uploads occur.
- View scan activity/errors and diagnostics. The PWA manifest and service
  worker cache only the application shell; library APIs are never cached.
  Offline shell availability does not make the stopped backend usable. Actual
  PWA installation on Apple devices remains unverified.

There are no configured cloud providers, NAS-specific connectors, external
metadata/artwork, discovery feeds, daily episode scheduling/downloading,
review queue, BIFROST hosting/retake, remote access, iCloud, Siri/App Intents,
AppleScript/Automator, or Pantheon runtime. The BIFROST relationship remains
optional; its recovered discovery manifest is evidence only. See the recovery
report for these gates. Installed IINA/VLC/Subler and other suitable media tools
can supply future capabilities; SKALD does not reimplement their engines.

## API

GET `/api/status`, `/api/library?kind=all|movie|tv|music`, `/api/collections`,
`/api/packs`, `/api/packs/<id>/plan`.

POST JSON to `/api/roots` (`path`, optional `provider: "local"`), `/api/scan`
(`id`), `/api/watched` (`id`, boolean `watched`), `/api/progress` (`id`,
`position`, `duration`), `/api/relocate` (`id`, new `path`), `/api/open` (`id`),
`/api/collections` or `/api/packs` (`name`, `media_ids`, optional positive
integer `max_bytes`, `max_titles`). Unknown providers are rejected.
Browser access must be same-origin; these safeguards do not provide remote
multiuser authentication.

## Verify and package

```sh
python3 -m unittest -v
python3 build_package.py --output ~/edenOS/Temporary/SKALD/<fresh-candidate>
SKALD_PACKAGE_PATH=~/edenOS/Temporary/SKALD/<fresh-candidate>/SKALD.app python3 -m unittest -v
```

Tests use disposable fixtures, never your actual media library. Chrome and
Node are optional verification tools for a real browser workflow test; their
absence is reported as a skip. The package test is skipped unless a package
path is supplied. Package verification checks hashes, ZIP bytes, source drift,
version agreement, native service startup, and tests from the packaged core.
GUI, real-player playback, NAS, actual device, signing/notarization and user
acceptance remain separate evidence gates.
