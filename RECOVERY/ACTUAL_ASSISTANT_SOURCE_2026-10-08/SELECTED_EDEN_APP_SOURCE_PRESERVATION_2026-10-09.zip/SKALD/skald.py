#!/usr/bin/env python3
"""SKALD persistent Headless runtime entry point; reconstruction, not byte recovery."""
from __future__ import annotations
import argparse
from contextlib import contextmanager
import ipaddress
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
from urllib.request import Request,urlopen
from skald_runtime import VERSION
from skald_runtime.core import Runtime
from skald_runtime.http import Server


def default_data_dir():
    if os.environ.get('SKALD_DATA_DIR'):return Path(os.environ['SKALD_DATA_DIR']).expanduser()
    if sys.platform=='darwin':return Path.home()/'Library/Application Support/SKALD'
    if os.name=='nt':return Path(os.environ.get('LOCALAPPDATA',Path.home()))/'SKALD'
    return Path(os.environ.get('XDG_DATA_HOME',Path.home()/'.local/share'))/'skald'

@contextmanager
def owner_lock(data_dir):
    path=data_dir/'runtime.lock'
    stream=path.open('a+b')
    try:
        if os.name=='nt':
            import msvcrt
            if path.stat().st_size==0:stream.write(b'0');stream.flush()
            stream.seek(0);msvcrt.locking(stream.fileno(),msvcrt.LK_NBLCK,1)
        else:
            import fcntl
            fcntl.flock(stream,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except OSError:
        stream.close();raise RuntimeError('SKALD runtime already owns this data; attach to it rather than starting another')
    try:yield
    finally:
        stream.close()

def running_runtime(data_dir):
    try:
        state=json.loads((data_dir/'runtime.json').read_text())
        token=(data_dir/'broadcast-token').read_text().strip()
        request=Request(state['url']+'/api/status',headers={'Authorization':'Bearer '+token})
        with urlopen(request,timeout=2) as response:status=json.load(response)
        if status.get('version')!=VERSION:return None
        return state
    except (OSError,ValueError,KeyError):return None

def main():
    p=argparse.ArgumentParser(description='SKALD persistent media runtime')
    p.add_argument('--data-dir',type=Path,default=default_data_dir())
    p.add_argument('--host',default='127.0.0.1');p.add_argument('--port',type=int,default=8765)
    p.add_argument('--allow-lan',action='store_true',help='Explicitly enable private-LAN Library Broadcast; device token still required')
    p.add_argument('--ready-file',type=Path);p.add_argument('--background',action='store_true',help='Start or attach to the persistent runtime independently of any GUI')
    p.add_argument('--open',action='store_true');p.add_argument('--version',action='version',version=VERSION)
    args=p.parse_args();args.data_dir=args.data_dir.expanduser().resolve();args.data_dir.mkdir(parents=True,exist_ok=True,mode=0o700)
    if args.host!='localhost':
        try:host=ipaddress.ip_address(args.host)
        except ValueError:p.error('Choose a loopback/private bind address')
        if not host.is_loopback and not (args.allow_lan and (host.is_private or host.is_unspecified) and not host.is_multicast):p.error('Non-loopback delivery requires explicit --allow-lan and a private bind address')
        if host.version!=4:p.error('This listener currently uses IPv4')
    if args.background:
        state=running_runtime(args.data_dir)
        if not state:
            log=(args.data_dir/'runtime.log').open('ab')
            command=[sys.executable,str(Path(__file__).resolve()),'--data-dir',str(args.data_dir),'--host',args.host,'--port',str(args.port)]
            if args.allow_lan:command.append('--allow-lan')
            child=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=log,stderr=log,start_new_session=True);log.close()
            for _ in range(200):
                state=running_runtime(args.data_dir)
                if state:break
                if child.poll() is not None:p.exit(1,'Runtime failed to start; inspect its local runtime.log\n')
                time.sleep(.05)
            if not state:p.exit(1,'Runtime startup did not become ready; inspect its local runtime.log\n')
        print(json.dumps(state))
        if args.open:open_web(state['url'])
        return
    try:
        with owner_lock(args.data_dir):
            os.umask(0o077)
            runtime=Runtime(args.data_dir)
            server=Server((args.host,args.port),runtime,args.allow_lan)
            address='127.0.0.1' if args.host=='0.0.0.0' else args.host
            state={'url':f'http://{address}:{server.server_port}','pid':os.getpid(),'version':VERSION,'runtime':'persistent','data_dir':str(args.data_dir)}
            readiness={args.data_dir/'runtime.json'}
            if args.ready_file:readiness.add(args.ready_file)
            for file in readiness:
                file.parent.mkdir(parents=True,exist_ok=True);temp=file.with_suffix('.tmp');temp.write_text(json.dumps(state));temp.replace(file)
            runtime.start()
            print(json.dumps(state),flush=True)
            if args.open:open_web(state['url'])
            def stop(signum,frame):raise KeyboardInterrupt
            signal.signal(signal.SIGTERM,stop)
            try:server.serve_forever()
            except KeyboardInterrupt:pass
            finally:
                runtime.close();server.server_close()
                for file in readiness:file.unlink(missing_ok=True)
    except (RuntimeError,OSError) as exc:p.exit(1,str(exc)+'\n')

def open_web(url):
    import webbrowser
    webbrowser.open(url)

if __name__=='__main__':main()
