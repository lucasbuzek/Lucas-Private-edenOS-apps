# SKALD workspace notes

Project-specific authority and recovery limits are recorded in `PROJECT_BIBLE.md`.
Do not represent new implementation or this newly established Git history as
recovered historical SKALD work.
