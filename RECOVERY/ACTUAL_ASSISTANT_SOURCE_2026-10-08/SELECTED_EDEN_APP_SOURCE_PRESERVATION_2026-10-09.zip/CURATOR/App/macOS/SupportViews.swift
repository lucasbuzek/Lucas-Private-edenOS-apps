#if os(macOS)
import SwiftUI
import CuratorCore

struct StorageView: View {
    var body: some View {
        List(StorageRole.allCases, id: \.self) { role in
            Label(role.rawValue.capitalized, systemImage: "externaldrive")
        }.navigationTitle("Storage")
    }
}

struct ActivityView: View {
    @EnvironmentObject var model: AppModel
    var body: some View {
        List {
            Section("Current State") { Text(model.activity) }
            Section("Journal") {
                if model.actions.isEmpty { Text("No recorded actions yet").foregroundStyle(.secondary) }
                ForEach(model.actions) { action in
                    VStack(alignment: .leading) {
                        Text(action.action).bold()
                        Text("\(action.target) • \(action.state)").font(.caption).foregroundStyle(.secondary)
                    }
                }
            }
        }.navigationTitle("Activity")
    }
}

struct DiagnosticsView: View {
    @EnvironmentObject var model: AppModel
    var body: some View {
        Form {
            Section("Runtime") {
                LabeledContent("Assets", value: "\(model.assets.count)")
                LabeledContent("Library", value: model.libraryURL?.path ?? "Not selected")
                LabeledContent("Automation", value: model.automationLevel.rawValue)
            }
            Section("Capabilities") {
                ForEach(CuratorCapabilities.all, id: \.id) { c in
                    LabeledContent(c.id, value: "M\(c.milestone)")
                }
            }
        }.formStyle(.grouped).navigationTitle("Diagnostics")
    }
}

struct SettingsView: View {
    @EnvironmentObject var model: AppModel
    var body: some View {
        Form {
            Picker("Automation", selection: $model.automationLevel) {
                ForEach(AutomationLevel.allCases, id: \.self) { Text($0.rawValue).tag($0) }
            }
            Text("Guided is the Private-build default. Destructive actions remain approval-controlled.")
                .foregroundStyle(.secondary)
        }.padding().frame(width: 520)
    }
}
#endif
