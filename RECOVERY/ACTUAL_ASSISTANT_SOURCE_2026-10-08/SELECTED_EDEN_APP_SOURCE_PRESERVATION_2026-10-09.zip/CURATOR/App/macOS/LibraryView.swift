#if os(macOS)
import SwiftUI
import QuickLookThumbnailing
import CuratorCore

struct LibraryView: View {
    @EnvironmentObject var model: AppModel
    private let columns = [GridItem(.adaptive(minimum: 150, maximum: 230), spacing: 14)]

    var body: some View {
        ScrollView {
            LazyVGrid(columns: columns, spacing: 14) {
                ForEach(model.filteredAssets) { asset in
                    AssetTile(asset: asset, selected: model.selection == asset.id)
                        .onTapGesture { model.selection = asset.id }
                }
            }.padding()
        }
        .navigationTitle(model.libraryURL?.lastPathComponent ?? "Library")
        .overlay {
            if model.assets.isEmpty {
                ContentUnavailableView("No Library Loaded",
                    systemImage: "photo.on.rectangle",
                    description: Text("Choose a folder to begin indexing real assets."))
            }
        }
    }
}

struct AssetTile: View {
    let asset: Asset
    let selected: Bool
    @State private var thumbnail: NSImage?

    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            ZStack {
                RoundedRectangle(cornerRadius: 10).fill(.quaternary)
                if let thumbnail {
                    Image(nsImage: thumbnail).resizable().scaledToFit()
                } else {
                    Image(systemName: asset.kind == .video ? "film" : "photo")
                        .font(.largeTitle).foregroundStyle(.secondary)
                }
            }
            .aspectRatio(4/3, contentMode: .fit)
            .overlay(RoundedRectangle(cornerRadius: 10).stroke(selected ? Color.accentColor : .clear, lineWidth: 3))
            Text(asset.filename).font(.caption).lineLimit(1)
            HStack {
                Text(String(repeating: "★", count: asset.rating)).font(.caption2)
                Spacer()
                if asset.curationState != .none {
                    Text(asset.curationState.rawValue).font(.caption2).bold()
                }
            }
        }
        .task { await loadThumbnail() }
    }

    func loadThumbnail() async {
        let request = QLThumbnailGenerator.Request(fileAt: asset.url, size: CGSize(width: 420, height: 315), scale: 2, representationTypes: .thumbnail)
        if let rep = try? await QLThumbnailGenerator.shared.generateBestRepresentation(for: request) {
            thumbnail = rep.nsImage
        }
    }
}
#endif
