#if os(macOS)
import SwiftUI
import CuratorCore

struct ContentView: View {
    @EnvironmentObject var model: AppModel
    @State private var columnVisibility: NavigationSplitViewVisibility = .all

    var body: some View {
        NavigationSplitView(columnVisibility: $columnVisibility) {
            List(SidebarSection.allCases, selection: $model.section) { s in
                Label(s.rawValue, systemImage: icon(s)).tag(s)
            }
            .navigationTitle("CURATOR")
            .safeAreaInset(edge: .bottom) {
                Button("Choose Library…") { model.chooseLibrary() }
                    .buttonStyle(.borderedProminent).padding()
            }
        } content: {
            Group {
                switch model.section {
                case .library: LibraryView()
                case .shoots: EntityListView(title: "Shoots", emptyText: "No shoots yet", names: model.shoots.map(\.name))
                case .projects: EntityListView(title: "Projects", emptyText: "No projects yet", names: model.projects.map(\.name))
                case .collections: EntityListView(title: "Collections", emptyText: "No collections yet", names: model.collections.map(\.name))
                case .storage: StorageView()
                case .activity: ActivityView()
                case .diagnostics: DiagnosticsView()
                }
            }
        } detail: {
            InspectorView()
        }
        .searchable(text: $model.query, prompt: "Search assets")
        .toolbar {
            Button { model.scan() } label: { Label("Rescan", systemImage: "arrow.clockwise") }
        }
    }

    func icon(_ s: SidebarSection) -> String {
        switch s {
        case .library: "photo.on.rectangle.angled"
        case .shoots: "camera"
        case .projects: "folder"
        case .collections: "rectangle.stack"
        case .storage: "externaldrive"
        case .activity: "clock.arrow.circlepath"
        case .diagnostics: "stethoscope"
        }
    }
}

struct EntityListView: View {
    let title: String, emptyText: String, names: [String]
    var body: some View {
        Group {
            if names.isEmpty {
                ContentUnavailableView(emptyText, systemImage: "tray")
            } else {
                List(names, id: \.self) { Text($0) }
            }
        }.navigationTitle(title)
    }
}
#endif
