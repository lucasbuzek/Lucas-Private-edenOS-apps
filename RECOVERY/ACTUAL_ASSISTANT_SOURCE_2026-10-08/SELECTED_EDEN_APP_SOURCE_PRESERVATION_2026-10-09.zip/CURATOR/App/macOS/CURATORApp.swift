#if os(macOS)
import SwiftUI
import CuratorCore

@main
struct CURATORApp: App {
    @StateObject private var model = AppModel()
    var body: some Scene {
        WindowGroup {
            ContentView().environmentObject(model)
                .frame(minWidth: 1050, minHeight: 680)
        }
        Settings { SettingsView().environmentObject(model) }
    }
}
#endif
