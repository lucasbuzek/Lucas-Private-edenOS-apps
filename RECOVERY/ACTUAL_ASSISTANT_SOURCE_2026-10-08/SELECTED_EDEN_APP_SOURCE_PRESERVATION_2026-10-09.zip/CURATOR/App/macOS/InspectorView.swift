#if os(macOS)
import SwiftUI
import CuratorCore

struct InspectorView: View {
    @EnvironmentObject var model: AppModel
    var selected: Asset? { model.assets.first { $0.id == model.selection } }

    var body: some View {
        if let a = selected {
            Form {
                Section("Asset") {
                    LabeledContent("Name", value: a.filename)
                    LabeledContent("Type", value: a.kind.rawValue.capitalized)
                    LabeledContent("Size", value: ByteCountFormatter.string(fromByteCount: Int64(a.fileSize), countStyle: .file))
                    LabeledContent("Hash", value: a.sha256 ?? a.hashState.rawValue.capitalized)
                }
                Section("Curation") {
                    Picker("Rating", selection: Binding(get: { a.rating }, set: { model.updateSelected(rating: $0) })) {
                        ForEach(0...5, id: \.self) { Text($0 == 0 ? "Unrated" : String(repeating: "★", count: $0)).tag($0) }
                    }
                    Picker("State", selection: Binding(get: { a.curationState }, set: { model.updateSelected(state: $0) })) {
                        ForEach(CurationState.allCases, id: \.self) { Text($0.rawValue).tag($0) }
                    }
                    LabeledContent("Label", value: a.label ?? "—")
                    if !a.keywords.isEmpty { Text(a.keywords.joined(separator: " • ")).font(.caption) }
                }
                Section("Relationships") {
                    LabeledContent("XMP Sidecar", value: RelationshipDetector.sidecarExists(for: a) ? "Found" : "None")
                    LabeledContent("Source", value: a.sourceAssetID?.uuidString ?? "Original / unknown")
                }
                Section("Actions") {
                    Button("Open in Bridge") { model.openInBridge(a) }
                    Button("Reveal in Finder") { NSWorkspace.shared.activateFileViewerSelecting([a.url]) }
                }
            }
            .formStyle(.grouped)
            .navigationTitle("Inspector")
        } else {
            ContentUnavailableView("No Selection", systemImage: "sidebar.right", description: Text("Select an asset to inspect it."))
        }
    }
}
#endif
