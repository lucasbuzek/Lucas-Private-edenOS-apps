#if os(macOS)
import SwiftUI
import AppKit
import CuratorCore

@MainActor
final class AppModel: ObservableObject {
    @Published var assets: [Asset] = []
    @Published var selection: UUID?
    @Published var query = ""
    @Published var section: SidebarSection = .library
    @Published var activity = "Choose a library to begin"
    @Published var libraryURL: URL?
    @Published var automationLevel: AutomationLevel = .guided
    @Published var shoots: [Shoot] = []
    @Published var projects: [Project] = []
    @Published var collections: [AssetCollection] = []
    @Published var actions: [ActionRecord] = []

    private let scanner = LibraryScanner()
    private let store = AssetStore()

    var filteredAssets: [Asset] {
        guard !query.isEmpty else { return assets }
        return assets.filter {
            $0.filename.localizedCaseInsensitiveContains(query) ||
            $0.keywords.contains { $0.localizedCaseInsensitiveContains(query) }
        }
    }

    func chooseLibrary() {
        let p = NSOpenPanel()
        p.canChooseDirectories = true; p.canChooseFiles = false; p.allowsMultipleSelection = false
        if p.runModal() == .OK, let url = p.url {
            libraryURL = url
            scan()
        }
    }

    func scan() {
        guard let url = libraryURL else { return }
        activity = "Scanning…"
        do {
            var found = try scanner.scan(url)
            for i in found.indices {
                let x = SidecarXMP.read(for: found[i].url)
                found[i].rating = x.rating ?? 0
                found[i].label = x.label
                found[i].keywords = x.keywords
            }
            assets = found
            Task {
                await store.replace(with: found)
                actions = await store.journal()
            }
            activity = "\(found.count) assets indexed"
        } catch {
            activity = "Scan failed: \(error.localizedDescription)"
        }
    }

    func updateSelected(rating: Int? = nil, state: CurationState? = nil) {
        guard let id = selection, let index = assets.firstIndex(where: { $0.id == id }) else { return }
        if let rating { assets[index].rating = max(0, min(5, rating)) }
        if let state { assets[index].curationState = state }
        let asset = assets[index]
        do {
            try SidecarXMP.write(for: asset.url, metadata: .init(rating: asset.rating, label: asset.label, keywords: asset.keywords))
            Task {
                await store.updateCuration(id: id, state: asset.curationState, rating: asset.rating, label: asset.label)
                actions = await store.journal()
            }
            activity = "Updated \(asset.filename)"
        } catch { activity = "Metadata update failed: \(error.localizedDescription)" }
    }

    func openInBridge(_ asset: Asset) {
        let bridge = URL(fileURLWithPath: "/Applications/Adobe Bridge 2026/Adobe Bridge 2026.app")
        if FileManager.default.fileExists(atPath: bridge.path) {
            NSWorkspace.shared.open([asset.url], withApplicationAt: bridge, configuration: NSWorkspace.OpenConfiguration())
        } else {
            NSWorkspace.shared.activateFileViewerSelecting([asset.url])
        }
    }
}

enum SidebarSection: String, CaseIterable, Identifiable {
    case library = "Library", shoots = "Shoots", projects = "Projects",
         collections = "Collections", storage = "Storage", activity = "Activity",
         diagnostics = "Diagnostics"
    var id: String { rawValue }
}
#endif
