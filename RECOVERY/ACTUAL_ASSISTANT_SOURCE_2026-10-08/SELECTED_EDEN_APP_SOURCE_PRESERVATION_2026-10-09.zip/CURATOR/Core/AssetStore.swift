import Foundation

public actor AssetStore {
    private var assets: [UUID: Asset] = [:]
    private var actions: [ActionRecord] = []

    public init() {}

    public func replace(with items: [Asset]) {
        assets = Dictionary(uniqueKeysWithValues: items.map { ($0.id, $0) })
        actions.append(ActionRecord(action: "library.scan", target: "\(items.count) assets", state: "confirmed"))
    }

    public func all() -> [Asset] {
        assets.values.sorted { $0.filename.localizedStandardCompare($1.filename) == .orderedAscending }
    }

    public func updateCuration(id: UUID, state: CurationState, rating: Int? = nil, label: String? = nil) {
        guard var a = assets[id] else { return }
        a.curationState = state
        if let rating { a.rating = max(0, min(5, rating)) }
        if let label { a.label = label }
        assets[id] = a
        actions.append(ActionRecord(action: "curation.update", target: a.filename, state: "confirmed"))
    }

    public func journal() -> [ActionRecord] { actions }
}
