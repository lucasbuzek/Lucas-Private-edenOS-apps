import Foundation

public struct VerifiedCopyResult: Sendable, Equatable { public var sha256: String; public var bytes: UInt64 }
public enum StorageVerifier {
    public static func copyThenVerify(source: URL, destination: URL) throws -> VerifiedCopyResult {
        let fm=FileManager.default; if fm.fileExists(atPath: destination.path) { throw CocoaError(.fileWriteFileExists) }
        try fm.createDirectory(at: destination.deletingLastPathComponent(), withIntermediateDirectories: true)
        let sourceHash=try SHA256Digest.file(source); try fm.copyItem(at: source, to: destination)
        let destHash=try SHA256Digest.file(destination)
        guard sourceHash == destHash else { try? fm.removeItem(at: destination); throw CocoaError(.fileReadCorruptFile) }
        let size=(try? source.resourceValues(forKeys:[.fileSizeKey]).fileSize).map(UInt64.init) ?? 0
        return .init(sha256: sourceHash, bytes: size)
    }
}
