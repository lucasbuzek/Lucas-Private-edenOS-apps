import Foundation
public enum SocialPlatform:String,Codable,CaseIterable,Sendable { case instagram, facebook, youtube, tiktok, linkedin, x, threads, pinterest, website }
public enum PublicationState:String,Codable,Sendable { case draft, proposed, approved, scheduled, publishing, published, failed, withdrawn }
public struct Campaign:Identifiable,Codable,Sendable { public var id=UUID(); public var name:String; public var objective:String; public var sourceAssetIDs:[UUID]; public var platforms:[SocialPlatform]; public var createdAt=Date() }
public struct PublicationRecord:Identifiable,Codable,Sendable {
    public var id=UUID(); public var campaignID:UUID?; public var sourceAssetID:UUID; public var derivativeAssetID:UUID?; public var platform:SocialPlatform; public var state:PublicationState; public var scheduledAt:Date?; public var publishedAt:Date?; public var externalID:String?; public var permalink:URL?; public var caption:String?; public var altText:String?; public var tags:[String]
}
public protocol DistributionProvider:Sendable { var providerID:String { get }; var platforms:Set<SocialPlatform> { get }; func publish(_ record:PublicationRecord) async throws -> PublicationRecord }
public struct MetaProviderContract:Sendable { public static let providerID="meta.graph"; public static let capabilities=["social.instagram.publish","social.facebook.publish","social.analytics.read"] }
