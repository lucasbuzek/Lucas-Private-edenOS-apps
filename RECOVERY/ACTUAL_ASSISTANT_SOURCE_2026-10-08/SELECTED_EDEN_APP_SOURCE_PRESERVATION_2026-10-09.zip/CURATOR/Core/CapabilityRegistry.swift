import Foundation
public struct Capability: Hashable, Sendable { public let id:String; public let title:String; public let milestone:Int }
public enum CuratorCapabilities {
    public static let all:[Capability] = [
        .init(id:"curator.asset.discover",title:"Discover photo/video assets",milestone:3),
        .init(id:"curator.metadata.xmp.read",title:"Read XMP sidecars",milestone:3),
        .init(id:"curator.metadata.xmp.write",title:"Write XMP sidecars",milestone:3),
        .init(id:"curator.curate.update",title:"Rate, label and curate",milestone:3),
        .init(id:"curator.processing.recipe",title:"Versioned processing recipes",milestone:3),
        .init(id:"curator.jobs.persist",title:"Persistent job contract",milestone:3),
        .init(id:"curator.storage.verifyCopy",title:"Verified storage copy",milestone:3),
        .init(id:"curator.asset.relate",title:"Asset relationships",milestone:3),
        .init(id:"curator.professional.handoff",title:"Professional application handoff",milestone:3),
        .init(id:"curator.bifrost.route",title:"BIFROST capability/data route",milestone:3),
        .init(id:"curator.conductor.route",title:"CONDUCTOR intelligence orchestration route",milestone:3),
        .init(id:"curator.social.assets",title:"Social derivative recipes",milestone:3),
        .init(id:"curator.social.meta",title:"Meta distribution contract",milestone:3),
        .init(id:"curator.helper.invoke",title:"Optional intelligence provider invocation",milestone:7),
        .init(id:"curator.automation.propose",title:"Explainable automation proposal",milestone:7)
    ]
}
