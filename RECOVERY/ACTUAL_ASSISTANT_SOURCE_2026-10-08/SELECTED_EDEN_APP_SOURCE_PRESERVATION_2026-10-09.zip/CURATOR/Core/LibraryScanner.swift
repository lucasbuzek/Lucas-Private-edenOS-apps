import Foundation

public struct LibraryScanner: Sendable {
    public init() {}

    public func scan(_ root: URL) throws -> [Asset] {
        let fm = FileManager.default
        guard let e = fm.enumerator(
            at: root,
            includingPropertiesForKeys: [.isRegularFileKey, .fileSizeKey, .contentModificationDateKey],
            options: [.skipsHiddenFiles, .skipsPackageDescendants]
        ) else { return [] }

        let photo = Set(["jpg","jpeg","png","heic","heif","tif","tiff","dng","cr2","cr3","nef","arw","orf","raf","rw2"])
        let video = Set(["mov","mp4","m4v","avi","mkv","mts","m2ts"])

        var assets: [Asset] = []
        for case let url as URL in e {
            let values = try? url.resourceValues(forKeys: [.isRegularFileKey, .fileSizeKey, .contentModificationDateKey])
            guard values?.isRegularFile == true else { continue }
            let ext = url.pathExtension.lowercased()
            let kind: AssetKind
            if photo.contains(ext) { kind = .photo }
            else if video.contains(ext) { kind = .video }
            else { continue }

            assets.append(Asset(
                url: url,
                kind: kind,
                filename: url.lastPathComponent,
                fileSize: UInt64(values?.fileSize ?? 0),
                modifiedAt: values?.contentModificationDate
            ))
        }
        return assets.sorted { $0.filename.localizedStandardCompare($1.filename) == .orderedAscending }
    }
}
