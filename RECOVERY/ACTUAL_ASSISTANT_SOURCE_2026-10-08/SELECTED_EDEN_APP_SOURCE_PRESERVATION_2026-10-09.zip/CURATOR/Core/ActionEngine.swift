import Foundation
public enum CuratorActionRisk: String, Codable, Sendable { case green, amber, red }
public struct CuratorAction: Identifiable, Codable, Sendable { public var id=UUID(); public var capabilityID:String; public var risk:CuratorActionRisk; public var targets:[URL]; public var explanation:String }
public enum ActionEngine {
    public static func requiresApproval(_ action: CuratorAction) -> Bool { action.risk != .green }
    public static func validate(_ action: CuratorAction) -> Bool { !action.capabilityID.isEmpty && !action.targets.isEmpty }
}
