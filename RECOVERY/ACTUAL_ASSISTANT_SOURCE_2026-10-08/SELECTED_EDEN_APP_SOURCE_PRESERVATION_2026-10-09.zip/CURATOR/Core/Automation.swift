import Foundation

public enum AutomationLevel: String, Codable, CaseIterable, Sendable {
    case manual = "Manual", assist = "Assist", guided = "Guided",
         automatic = "Automatic", autonomous = "Autonomous"
}

public struct AutomationProposal: Identifiable, Sendable {
    public var id = UUID()
    public var capabilityID: String
    public var explanation: String
    public var requiresApproval: Bool
}

public protocol CuratorHelperProvider: Sendable {
    var providerID: String { get }
    func propose(for assets: [Asset]) async throws -> [AutomationProposal]
}
