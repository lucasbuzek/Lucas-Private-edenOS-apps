import Foundation

public struct AssetRelationship: Identifiable, Codable, Hashable, Sendable {
    public enum Kind: String, Codable, Sendable {
        case sidecar, exactDuplicate, derivative, master, backup, workingCopy
    }
    public var id = UUID()
    public var from: UUID
    public var to: UUID
    public var kind: Kind
}

public enum RelationshipDetector {
    public static func sidecarExists(for asset: Asset) -> Bool {
        FileManager.default.fileExists(atPath: SidecarXMP.sidecarURL(for: asset.url).path)
    }
}
