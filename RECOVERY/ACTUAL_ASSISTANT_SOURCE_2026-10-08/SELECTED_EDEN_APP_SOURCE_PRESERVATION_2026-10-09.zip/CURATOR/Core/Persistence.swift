import Foundation

public struct CuratorSnapshot: Codable, Sendable {
    public var schemaVersion = 1
    public var assets: [Asset]
    public var projects: [Project]
    public var shoots: [Shoot]
    public var collections: [AssetCollection]
    public var relationships: [AssetRelationship]
    public var actions: [ActionRecord]
}

public enum CuratorPersistence {
    public static func save(_ snapshot: CuratorSnapshot, to url: URL) throws {
        let fm = FileManager.default; try fm.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
        let tmp = url.appendingPathExtension("staging")
        let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys]; encoder.dateEncodingStrategy = .iso8601
        try encoder.encode(snapshot).write(to: tmp, options: .atomic)
        _ = try JSONDecoder.curator.decode(CuratorSnapshot.self, from: Data(contentsOf: tmp))
        if fm.fileExists(atPath: url.path) { try fm.removeItem(at: url) }
        try fm.moveItem(at: tmp, to: url)
    }
    public static func load(from url: URL) throws -> CuratorSnapshot { try JSONDecoder.curator.decode(CuratorSnapshot.self, from: Data(contentsOf: url)) }
}

private extension JSONDecoder {
    static var curator: JSONDecoder { let d=JSONDecoder(); d.dateDecodingStrategy = .iso8601; return d }
}
