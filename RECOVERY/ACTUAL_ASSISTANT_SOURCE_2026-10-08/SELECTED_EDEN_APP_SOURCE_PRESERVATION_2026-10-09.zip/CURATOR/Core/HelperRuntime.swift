import Foundation
public actor HelperRuntime {
    private var providers:[String:any CuratorHelperProvider]=[:]
    public init() {}
    public func register(_ provider:any CuratorHelperProvider) { providers[provider.providerID]=provider }
    public func providerIDs()->[String] { providers.keys.sorted() }
    public func proposals(providerID:String, assets:[Asset], level:AutomationLevel) async throws -> [AutomationProposal] {
        guard level != .manual else { return [] }
        guard let provider=providers[providerID] else { throw CocoaError(.fileNoSuchFile) }
        return try await provider.propose(for: assets).map { p in var x=p; if level == .assist || level == .guided { x.requiresApproval=true }; return x }
    }
}
