import Foundation

public enum AssetKind: String, Codable, CaseIterable, Sendable {
    case photo, video, other
}

public enum CurationState: String, Codable, CaseIterable, Sendable {
    case none = "NONE"
    case select = "SELECT"
    case develop = "DEVELOP"
    case examine = "EXAMINE"
    case specialEdit = "SPECIAL EDIT"
    case reference = "REFERENCE"
    case reject = "REJECT"
}

public enum HashState: String, Codable, Sendable {
    case pending, hashing, verified, failed
}

public struct Asset: Identifiable, Codable, Hashable, Sendable {
    public var id: UUID
    public var url: URL
    public var kind: AssetKind
    public var filename: String
    public var fileSize: UInt64
    public var modifiedAt: Date?
    public var rating: Int
    public var label: String?
    public var keywords: [String]
    public var curationState: CurationState
    public var sha256: String?
    public var hashState: HashState
    public var sourceAssetID: UUID?
    public var projectIDs: [UUID]
    public var shootID: UUID?

    public init(
        id: UUID = UUID(), url: URL, kind: AssetKind, filename: String,
        fileSize: UInt64 = 0, modifiedAt: Date? = nil, rating: Int = 0,
        label: String? = nil, keywords: [String] = [],
        curationState: CurationState = .none, sha256: String? = nil,
        hashState: HashState = .pending, sourceAssetID: UUID? = nil,
        projectIDs: [UUID] = [], shootID: UUID? = nil
    ) {
        self.id = id; self.url = url; self.kind = kind; self.filename = filename
        self.fileSize = fileSize; self.modifiedAt = modifiedAt; self.rating = rating
        self.label = label; self.keywords = keywords; self.curationState = curationState
        self.sha256 = sha256; self.hashState = hashState; self.sourceAssetID = sourceAssetID
        self.projectIDs = projectIDs; self.shootID = shootID
    }
}

public struct Shoot: Identifiable, Codable, Hashable, Sendable {
    public var id = UUID()
    public var name: String
    public var date: Date?
    public var location: String?
}

public struct Project: Identifiable, Codable, Hashable, Sendable {
    public var id = UUID()
    public var name: String
    public var notes: String = ""
}

public enum StorageRole: String, Codable, CaseIterable, Sendable {
    case working = "WORKING", archive = "ARCHIVE", backup = "BACKUP",
         offsite = "OFFSITE", ingest = "INGEST", export = "EXPORT", temp = "TEMP"
}

public struct StorageLocation: Identifiable, Codable, Hashable, Sendable {
    public var id = UUID()
    public var name: String
    public var url: URL
    public var role: StorageRole
    public var online: Bool = true
}

public struct ActionRecord: Identifiable, Codable, Sendable {
    public var id = UUID()
    public var timestamp = Date()
    public var action: String
    public var target: String
    public var state: String
    public var detail: String?
}

public struct AssetCollection: Identifiable, Codable, Hashable, Sendable {
    public var id: UUID = UUID()
    public var name: String
    public var assetIDs: [UUID] = []
    public init(id: UUID = UUID(), name: String, assetIDs: [UUID] = []) { self.id=id; self.name=name; self.assetIDs=assetIDs }
}
