import Foundation

public struct SidecarMetadata: Equatable, Sendable {
    public var rating: Int?
    public var label: String?
    public var keywords: [String]
    public init(rating: Int? = nil, label: String? = nil, keywords: [String] = []) {
        self.rating = rating; self.label = label; self.keywords = keywords
    }
}

public enum SidecarXMP {
    public static func sidecarURL(for asset: URL) -> URL {
        asset.deletingPathExtension().appendingPathExtension("xmp")
    }

    public static func read(for asset: URL) -> SidecarMetadata {
        let sidecar = sidecarURL(for: asset)
        guard let text = try? String(contentsOf: sidecar, encoding: .utf8) else { return .init() }

        func capture(_ pattern: String) -> String? {
            guard let re = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]),
                  let m = re.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)),
                  m.numberOfRanges > 1,
                  let r = Range(m.range(at: 1), in: text) else { return nil }
            return String(text[r])
        }

        let rating = capture(#"xmp:Rating\s*=\s*"(-?\d+)""#).flatMap(Int.init)
        let label = capture(#"xmp:Label\s*=\s*"([^"]*)""#)

        var keywords: [String] = []
        if let re = try? NSRegularExpression(pattern: #"<rdf:li>(.*?)</rdf:li>"#, options: [.caseInsensitive, .dotMatchesLineSeparators]) {
            for m in re.matches(in: text, range: NSRange(text.startIndex..., in: text)) {
                if let r = Range(m.range(at: 1), in: text) {
                    keywords.append(String(text[r])
                        .replacingOccurrences(of: "&amp;", with: "&")
                        .replacingOccurrences(of: "&lt;", with: "<")
                        .replacingOccurrences(of: "&gt;", with: ">"))
                }
            }
        }
        return .init(rating: rating, label: label, keywords: keywords)
    }
}

public extension SidecarXMP {
    static func write(for asset: URL, metadata: SidecarMetadata) throws {
        func esc(_ s: String) -> String { s.replacingOccurrences(of:"&",with:"&amp;").replacingOccurrences(of:"\"",with:"&quot;").replacingOccurrences(of:"<",with:"&lt;").replacingOccurrences(of:">",with:"&gt;") }
        let rating = metadata.rating.map(String.init) ?? "0"; let label=esc(metadata.label ?? "")
        let subjects=metadata.keywords.map { "<rdf:li>\(esc($0))</rdf:li>" }.joined()
        let xml="""
<?xpacket begin="﻿" id="W5M0MpCehiHzreSzNTczkc9d"?>
<x:xmpmeta xmlns:x="adobe:ns:meta/"><rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"><rdf:Description xmlns:xmp="http://ns.adobe.com/xap/1.0/" xmlns:dc="http://purl.org/dc/elements/1.1/" xmp:Rating="\(rating)" xmp:Label="\(label)"><dc:subject><rdf:Bag>\(subjects)</rdf:Bag></dc:subject></rdf:Description></rdf:RDF></x:xmpmeta>
<?xpacket end="w"?>
"""
        try xml.write(to: sidecarURL(for: asset), atomically: true, encoding: .utf8)
    }
}
