import Foundation

public enum CuratorDomain: String, Codable, CaseIterable, Sendable { case photo, video, audio, graphicDesign, publishing, motionVFX, creative3D, generatedMedia, digitisation }
public enum DeploymentReadiness: String, Codable, Sendable { case ready, implemented, verified, deployable, productionReady }

public struct DomainDeployment: Codable, Hashable, Sendable {
    public var domain: CuratorDomain
    public var priority: Int
    public var readiness: DeploymentReadiness
    public var requiredCapabilities: [String]
    public init(domain: CuratorDomain, priority: Int, readiness: DeploymentReadiness, requiredCapabilities: [String]) { self.domain=domain; self.priority=priority; self.readiness=readiness; self.requiredCapabilities=requiredCapabilities }
}

public enum CuratorDeploymentPlan {
    public static let domains: [DomainDeployment] = [
        .init(domain:.photo, priority:0, readiness:.implemented, requiredCapabilities:["metadata.xmp.read","metadata.xmp.write","image.develop","image.edit","image.resize"]),
        .init(domain:.video, priority:0, readiness:.implemented, requiredCapabilities:["video.inspect","video.edit","video.proxy.generate","video.transcode"]),
        .init(domain:.audio, priority:1, readiness:.ready, requiredCapabilities:["audio.inspect","audio.edit"]),
        .init(domain:.graphicDesign, priority:1, readiness:.ready, requiredCapabilities:["design.edit"]),
        .init(domain:.publishing, priority:1, readiness:.ready, requiredCapabilities:["publishing.layout","document.pdf.optimize"]),
        .init(domain:.motionVFX, priority:2, readiness:.ready, requiredCapabilities:["motion.edit"]),
        .init(domain:.creative3D, priority:2, readiness:.ready, requiredCapabilities:["creative3d.edit"]),
        .init(domain:.generatedMedia, priority:2, readiness:.ready, requiredCapabilities:["visual.generate"]),
        .init(domain:.digitisation, priority:2, readiness:.ready, requiredCapabilities:["digitisation.restore"])
    ]
}

public struct CapabilityRequest: Identifiable, Codable, Sendable {
    public var id = UUID()
    public var capability: String
    public var requester: String
    public var assetIDs: [UUID]
    public var context: [String:String]
    public var constraints: [String:String]
    public var preferredProvider: String?
    public init(capability:String, requester:String="CURATOR", assetIDs:[UUID]=[], context:[String:String]=[:], constraints:[String:String]=[:], preferredProvider:String?=nil) { self.capability=capability; self.requester=requester; self.assetIDs=assetIDs; self.context=context; self.constraints=constraints; self.preferredProvider=preferredProvider }
}

public struct CapabilityResult: Identifiable, Codable, Sendable {
    public var id = UUID()
    public var requestID: UUID
    public var provider: String
    public var artifactURLs: [URL]
    public var summary: String
    public var warnings: [String]
    public var recommendedActions: [String]
    public var verified: Bool
}

public enum EdenServiceRole: String, Codable, Sendable { case bifrostDataFabric, conductorIntelligenceFabric, localFallback }
public struct ServiceRoute: Codable, Hashable, Sendable { public var role:EdenServiceRole; public var endpoint:String?; public var available:Bool }
