import Foundation
public struct ProfessionalProvider:Codable,Hashable,Sendable { public var id:String; public var title:String; public var capabilities:[String]; public var optional:Bool }
public enum ProfessionalProviders {
    public static let all:[ProfessionalProvider] = [
        .init(id:"adobe.bridge",title:"Adobe Bridge",capabilities:["metadata.xmp.read","metadata.xmp.write","asset.browse"],optional:true),
        .init(id:"adobe.lightroom",title:"Adobe Lightroom",capabilities:["image.develop","catalog.handoff"],optional:true),
        .init(id:"adobe.camera-raw",title:"Adobe Camera Raw",capabilities:["image.raw.develop"],optional:true),
        .init(id:"adobe.photoshop",title:"Adobe Photoshop",capabilities:["image.edit","image.composite"],optional:true),
        .init(id:"apple.final-cut-pro",title:"Final Cut Pro",capabilities:["video.edit","video.project.handoff"],optional:true),
        .init(id:"eden.frame",title:"FRAME",capabilities:["creative.frame.edit"],optional:true),
        .init(id:"eden.conductor",title:"CONDUCTOR",capabilities:["intelligence.orchestrate","specialist.route"],optional:true),
        .init(id:"eden.bifrost",title:"BIFROST",capabilities:["data.resolve","capability.resolve","provider.resolve"],optional:true),
        .init(id:"meta.graph",title:"Meta",capabilities:MetaProviderContract.capabilities,optional:true)
    ]
}
