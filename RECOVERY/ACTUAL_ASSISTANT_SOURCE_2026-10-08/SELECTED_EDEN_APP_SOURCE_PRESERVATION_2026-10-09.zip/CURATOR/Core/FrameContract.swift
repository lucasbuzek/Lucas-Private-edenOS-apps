import Foundation

public struct FrameHandoff: Codable, Sendable {
    public var assetID: UUID
    public var sourceURL: URL
    public var projectIDs: [UUID]
    public var requestedCapability: String
}

public struct FrameReturn: Codable, Sendable {
    public var sourceAssetID: UUID
    public var derivativeURL: URL
    public var provider: String
    public var operation: String
    public var createdAt: Date = Date()
}
