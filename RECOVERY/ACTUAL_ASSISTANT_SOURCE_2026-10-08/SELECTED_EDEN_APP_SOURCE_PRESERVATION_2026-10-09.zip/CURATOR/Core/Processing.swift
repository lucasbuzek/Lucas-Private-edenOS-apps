import Foundation
public enum RecipeDomain: String, Codable, Sendable { case photo, video, social }
public struct ProcessingRecipe: Identifiable, Codable, Hashable, Sendable {
    public var id: String; public var version:Int; public var title:String; public var domain:RecipeDomain; public var capability:String; public var parameters:[String:String]
    public init(id:String,version:Int=1,title:String,domain:RecipeDomain,capability:String,parameters:[String:String]=[:]) { self.id=id; self.version=version; self.title=title; self.domain=domain; self.capability=capability; self.parameters=parameters }
}
public enum BuiltInRecipes {
    public static let all:[ProcessingRecipe] = [
        .init(id:"photo.web",title:"Web Photo",domain:.photo,capability:"image.resize",parameters:["longEdge":"2048","format":"jpeg","quality":"85"]),
        .init(id:"photo.social.square",title:"Social Square",domain:.social,capability:"image.resize",parameters:["aspect":"1:1","size":"1080"]),
        .init(id:"photo.social.portrait",title:"Social Portrait",domain:.social,capability:"image.resize",parameters:["aspect":"4:5","width":"1080"]),
        .init(id:"video.proxy",title:"Video Proxy",domain:.video,capability:"video.proxy.generate",parameters:["codec":"prores_proxy"]),
        .init(id:"video.delivery.1080",title:"1080p Delivery",domain:.video,capability:"video.transcode",parameters:["height":"1080","codec":"h264"]),
        .init(id:"video.social.vertical",title:"Vertical Social Video",domain:.social,capability:"video.transcode",parameters:["aspect":"9:16","height":"1920"])
    ]
}
public enum JobState:String,Codable,Sendable { case queued, preparing, running, paused, interrupted, recovering, produced, verifying, verified, failed, cancelled }
public struct CuratorJob:Identifiable,Codable,Sendable { public var id=UUID(); public var capability:String; public var assetIDs:[UUID]; public var state:JobState = .queued; public var progress:Double?; public var createdAt=Date(); public var detail:String? }
