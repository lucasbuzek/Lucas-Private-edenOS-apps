import Foundation
public enum FrameIntegration {
    public static func register(_ returned: FrameReturn, source: Asset) throws -> (Asset, AssetRelationship) {
        let v=try returned.derivativeURL.resourceValues(forKeys:[.fileSizeKey,.contentModificationDateKey])
        let derivative=Asset(url:returned.derivativeURL, kind:source.kind, filename:returned.derivativeURL.lastPathComponent, fileSize:UInt64(v.fileSize ?? 0), modifiedAt:v.contentModificationDate, sourceAssetID:source.id, projectIDs:source.projectIDs, shootID:source.shootID)
        return (derivative, AssetRelationship(from:source.id,to:derivative.id,kind:.derivative))
    }
}
