// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "CURATOR",
    platforms: [.macOS(.v14)],
    products: [
        .library(name: "CuratorCore", targets: ["CuratorCore"])
    ],
    targets: [
        .target(
            name: "CuratorCore",
            path: "Core"
        ),
        .testTarget(
            name: "CuratorCoreTests",
            dependencies: ["CuratorCore"],
            path: "Tests/Core"
        )
    ]
)
