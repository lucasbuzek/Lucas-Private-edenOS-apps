import XCTest
@testable import CuratorCore

final class CuratorCoreTests: XCTestCase {
    func testSidecarURL() { XCTAssertEqual(SidecarXMP.sidecarURL(for: URL(fileURLWithPath:"/tmp/IMG_0001.CR3")).path,"/tmp/IMG_0001.xmp") }
    func testCapabilityMilestonesReachM7() { XCTAssertEqual(CuratorCapabilities.all.map(\.milestone).max(),7); XCTAssertTrue(CuratorCapabilities.all.contains{$0.id=="curator.professional.handoff"}); XCTAssertTrue(CuratorCapabilities.all.contains{$0.id=="curator.automation.propose"}) }
    func testScannerFiltersSupportedMedia() throws { let d=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString); try FileManager.default.createDirectory(at:d,withIntermediateDirectories:true); defer { try? FileManager.default.removeItem(at:d) }; try Data("x".utf8).write(to:d.appendingPathComponent("a.jpg")); try Data("x".utf8).write(to:d.appendingPathComponent("b.txt")); let r=try LibraryScanner().scan(d); XCTAssertEqual(r.count,1); XCTAssertEqual(r.first?.filename,"a.jpg") }
    func testSHA256KnownVector() { XCTAssertEqual(SHA256Digest.data(Data("abc".utf8)),"ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad") }
    func testXMPWriteReadRoundTrip() throws { let d=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString); try FileManager.default.createDirectory(at:d,withIntermediateDirectories:true); defer { try? FileManager.default.removeItem(at:d) }; let a=d.appendingPathComponent("a.CR3"); try Data().write(to:a); let m=SidecarMetadata(rating:4,label:"Green",keywords:["select","client"]); try SidecarXMP.write(for:a,metadata:m); XCTAssertEqual(SidecarXMP.read(for:a),m) }
    func testVerifiedCopyHash() throws { let d=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString); try FileManager.default.createDirectory(at:d,withIntermediateDirectories:true); defer { try? FileManager.default.removeItem(at:d) }; let s=d.appendingPathComponent("s.bin"), t=d.appendingPathComponent("out/t.bin"); try Data("verified".utf8).write(to:s); let r=try StorageVerifier.copyThenVerify(source:s,destination:t); XCTAssertEqual(r.sha256,try SHA256Digest.file(s)); XCTAssertTrue(FileManager.default.fileExists(atPath:t.path)) }
    func testSnapshotRoundTrip() throws {
        let d = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString).appendingPathExtension("json")
        defer { try? FileManager.default.removeItem(at: d) }
        let a = Asset(url: URL(fileURLWithPath: "/tmp/a.jpg"), kind: .photo, filename: "a.jpg", rating: 5, curationState: .select)
        let s = CuratorSnapshot(assets: [a], projects: [], shoots: [], collections: [], relationships: [], actions: [])
        try CuratorPersistence.save(s, to: d)
        let r = try CuratorPersistence.load(from: d)
        XCTAssertEqual(r.assets.first?.rating, 5)
        XCTAssertEqual(r.assets.first?.curationState, .select)
    }
    func testActionApprovalBoundary() { XCTAssertFalse(ActionEngine.requiresApproval(.init(capabilityID:"read",risk:.green,targets:[URL(fileURLWithPath:"/tmp/a")],explanation:"read"))); XCTAssertTrue(ActionEngine.requiresApproval(.init(capabilityID:"move",risk:.amber,targets:[URL(fileURLWithPath:"/tmp/a")],explanation:"move"))) }

    func testPhotoVideoArePriorityDomains() {
        let p0 = CuratorDeploymentPlan.domains.filter { $0.priority == 0 }.map(\.domain)
        XCTAssertTrue(p0.contains(.photo)); XCTAssertTrue(p0.contains(.video))
    }
    func testProfessionalProvidersIncludeAdobeAppleEdenAndMeta() {
        let ids = Set(ProfessionalProviders.all.map(\.id))
        XCTAssertTrue(ids.contains("adobe.bridge")); XCTAssertTrue(ids.contains("adobe.lightroom")); XCTAssertTrue(ids.contains("adobe.photoshop")); XCTAssertTrue(ids.contains("apple.final-cut-pro")); XCTAssertTrue(ids.contains("eden.conductor")); XCTAssertTrue(ids.contains("eden.bifrost")); XCTAssertTrue(ids.contains("meta.graph"))
    }
    func testSocialRecipesCoverPhotoAndVideo() {
        XCTAssertTrue(BuiltInRecipes.all.contains { $0.id == "photo.social.portrait" })
        XCTAssertTrue(BuiltInRecipes.all.contains { $0.id == "video.social.vertical" })
    }
    func testCapabilityRequestRoundTrip() throws {
        let r = CapabilityRequest(capability:"creative.analyze", assetIDs:[UUID()], preferredProvider:"eden.conductor")
        let d = try JSONEncoder().encode(r); let decoded = try JSONDecoder().decode(CapabilityRequest.self, from:d)
        XCTAssertEqual(decoded.capability,"creative.analyze"); XCTAssertEqual(decoded.preferredProvider,"eden.conductor")
    }
}
