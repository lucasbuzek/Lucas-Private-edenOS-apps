# PENELOPE — Project & Source Reconciliation

Private / Experimental. This is a new local baseline based on the recovered project requirements; it is not recovered v0.2.0 source.

## Current vertical slice

The CLI and loopback-only Web UI/API accept explicitly selected directories. They inventory regular files, record SHA-256 identities, inspect Git metadata when available, group likely families using project manifests or directory names, compare exact and divergent content, and emit a review-only staging plan plus an append-only run journal. English and Slovak UI labels are available.

The scanner does not follow symlinks. It never writes to selected source locations, moves files, or deletes files. Evidence output must be outside every selected directory. Family names, hashes, Git cleanliness, revision date, and inventory size are evidence signals; none alone establishes authority or a Last Known Good source. The generated staging plan is a proposal, not an executed consolidation.

## Run the verified package

Python 3.11+ is required. No third-party runtime dependencies are used.

```sh
python3 artifacts/penelope-0.1.0.pyz reconcile /path/to/project-v1 /path/to/project-v2 --evidence-dir /path/to/separate/evidence
python3 artifacts/penelope-0.1.0.pyz serve --evidence-dir /path/to/separate/evidence --language en
```

For source checkout development, use `PYTHONPATH=src python3 -m penelope` with the same command arguments.

The Web UI listens on `127.0.0.1` only. Its JSON endpoint is `POST /api/reconcile` with `{"locations":["/absolute/project/path"],"language":"en"}`; health is `GET /api/health`.

## Evidence outputs

Each reconciliation creates `reconciliation-<run-id>.json` and appends one record to `journal.jsonl` in the chosen evidence directory. Preserve both when retaining a run. Reports can contain selected absolute paths and Git subjects; store them accordingly.

## Current limits

- Family recognition is deliberately conservative and based on matching normalized project identity; unrelated projects with the same name can be grouped for review.
- Exact path/hash comparisons identify identical and divergent material. A bounded heuristic flags same-path UTF-8 near-duplicates up to 32 KiB at 0.90 similarity; it is review evidence only. Semantic equivalence, dependency resolution, broad branch graph analysis, and content-aware merge are not implemented.
- The staging plan identifies review candidates; it does not copy or consolidate files.
- No automatic canonical-source or LKG selection occurs.
