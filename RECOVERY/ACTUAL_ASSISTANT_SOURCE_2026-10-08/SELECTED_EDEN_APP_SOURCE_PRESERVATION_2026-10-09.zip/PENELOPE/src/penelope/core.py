"""Read-only source discovery and evidence generation."""

from __future__ import annotations

import hashlib
from difflib import SequenceMatcher
from itertools import combinations
import json
import os
import re
import subprocess
import tomllib
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


VERSION = "0.1.0"
CHUNK_SIZE = 1024 * 1024
NEAR_DUPLICATE_MAX_BYTES = 32 * 1024
NEAR_DUPLICATE_MIN_RATIO = 0.90
VERSION_SUFFIX = re.compile(
    r"(?:[._ -]+(?:v(?:ersion)?[._ -]?)?\d+(?:[._-]\d+){0,3}"
    r"(?:[-+][a-z0-9.-]+)?|[._ -]+(?:copy|backup|old|final)(?:[._ -]*\d+)?)$",
    re.IGNORECASE,
)

LABELS = {
    "en": {
        "title": "PENELOPE — Project & Source Reconciliation",
        "intro": "Inspect explicitly selected project/source locations. PENELOPE reads files and writes evidence only to the configured evidence directory.",
        "roots": "Project/source locations (one absolute path per line)",
        "run": "Analyze selected locations",
        "working": "Analyzing…",
        "done": "Reviewable reconciliation result",
        "error": "Could not complete analysis",
        "language": "Language",
        "safety": "Original locations are never modified. No files are moved or deleted.",
    },
    "sk": {
        "title": "PENELOPE — Zosúladenie projektov a zdrojov",
        "intro": "Preskúmajte výslovne vybrané umiestnenia projektov a zdrojov. PENELOPE iba číta súbory a dôkazy zapisuje do nastavenej zložky.",
        "roots": "Umiestnenia projektov a zdrojov (jedna úplná cesta na riadok)",
        "run": "Analyzovať vybrané umiestnenia",
        "working": "Prebieha analýza…",
        "done": "Výsledok na kontrolu",
        "error": "Analýzu sa nepodarilo dokončiť",
        "language": "Jazyk",
        "safety": "Pôvodné umiestnenia sa nemenia. Súbory sa nepresúvajú ani nemažú.",
    },
}


class ReconcileError(ValueError):
    """An input or safety constraint prevents an analysis run."""


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(CHUNK_SIZE):
            digest.update(chunk)
    return digest.hexdigest()


def _project_name(root: Path) -> str:
    pyproject = root / "pyproject.toml"
    if pyproject.is_file():
        try:
            project = tomllib.loads(pyproject.read_text("utf-8")).get("project", {})
            if isinstance(project.get("name"), str) and project["name"].strip():
                return project["name"].strip()
        except (OSError, UnicodeError, tomllib.TOMLDecodeError):
            pass
    package = root / "package.json"
    if package.is_file():
        try:
            name = json.loads(package.read_text("utf-8")).get("name")
            if isinstance(name, str) and name.strip():
                return name.strip()
        except (OSError, UnicodeError, json.JSONDecodeError, AttributeError):
            pass
    cargo = root / "Cargo.toml"
    if cargo.is_file():
        try:
            name = tomllib.loads(cargo.read_text("utf-8")).get("package", {}).get("name")
            if isinstance(name, str) and name.strip():
                return name.strip()
        except (OSError, UnicodeError, tomllib.TOMLDecodeError, AttributeError):
            pass
    return root.name


def _family_key(name: str) -> str:
    value = name.strip().lower()
    previous = None
    while value != previous:
        previous = value
        value = VERSION_SUFFIX.sub("", value).strip(" ._-")
    return re.sub(r"[^a-z0-9]+", "-", value).strip("-") or "unnamed"


def _artifact_kind(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix in {".py", ".swift", ".m", ".mm", ".c", ".h", ".cpp", ".rs", ".js", ".ts", ".go", ".java", ".kt", ".sh"}:
        return "source"
    if suffix in {".zip", ".tar", ".gz", ".dmg", ".pkg", ".app"}:
        return "package-or-archive"
    if path.name.lower() in {"pyproject.toml", "package.json", "cargo.toml", "package.swift", "makefile", "cmakelists.txt"}:
        return "project-manifest"
    if path.name.lower() in {"readme", "readme.md", "readme.txt", "agents.md"}:
        return "project-documentation"
    return "artifact"


def _git_evidence(root: Path) -> dict[str, Any] | None:
    def git(*args: str) -> str | None:
        try:
            environment = os.environ.copy()
            environment["GIT_OPTIONAL_LOCKS"] = "0"
            result = subprocess.run(
                ["git", "-c", "core.fsmonitor=false", "-c", "core.untrackedCache=false", "-C", str(root), *args],
                capture_output=True,
                text=True,
                timeout=8,
                check=False,
                env=environment,
            )
        except (OSError, subprocess.TimeoutExpired):
            return None
        return result.stdout.strip() if result.returncode == 0 else None

    top = git("rev-parse", "--show-toplevel")
    if not top:
        return None
    head = git("log", "-1", "--format=%H%x09%cs%x09%s")
    history = git("log", "-20", "--format=%H%x09%P%x09%cs%x09%s")
    branches = git("branch", "--list", "--format=%(refname:short)")
    branch = git("branch", "--show-current")
    status = git("status", "--short")
    commit = None
    if head:
        parts = head.split("\t", 2)
        commit = {"revision": parts[0], "date": parts[1] if len(parts) > 1 else None,
                  "subject": parts[2] if len(parts) > 2 else None}
    revisions = []
    if history:
        for line in history.splitlines():
            parts = line.split("\t", 3)
            if parts:
                revisions.append({
                    "revision": parts[0],
                    "parents": parts[1].split() if len(parts) > 1 else [],
                    "date": parts[2] if len(parts) > 2 else None,
                    "subject": parts[3] if len(parts) > 3 else None,
                })
    return {
        "repository_root": str(Path(top).resolve()),
        "branch": branch or None,
        "local_branches": branches.splitlines() if branches else [],
        "head": commit,
        "recent_revisions": revisions,
        "working_tree_clean": status == "",
    }


def _inventory(root: Path) -> tuple[list[dict[str, Any]], list[dict[str, str]]]:
    files: list[dict[str, Any]] = []
    errors: list[dict[str, str]] = []
    def record_walk_error(error: OSError) -> None:
        errors.append({"path": str(getattr(error, "filename", root)), "error": str(error)})

    for base, dirs, names in os.walk(root, topdown=True, onerror=record_walk_error, followlinks=False):
        base_path = Path(base)
        dirs.sort()
        names.sort()
        kept_dirs: list[str] = []
        for name in dirs:
            item = base_path / name
            if item.is_symlink():
                relative = item.relative_to(root).as_posix()
                try:
                    target = os.readlink(item)
                except OSError as exc:
                    target = f"unreadable: {exc}"
                files.append({"path": relative, "kind": "symlink", "target": target})
            else:
                kept_dirs.append(name)
        dirs[:] = kept_dirs
        for name in names:
            item = base_path / name
            relative = item.relative_to(root).as_posix()
            try:
                if item.is_symlink():
                    files.append({"path": relative, "kind": "symlink", "target": os.readlink(item)})
                elif item.is_file():
                    stat = item.stat()
                    files.append({
                        "path": relative,
                        "kind": _artifact_kind(item),
                        "size_bytes": stat.st_size,
                        "sha256": _sha256(item),
                    })
            except OSError as exc:
                errors.append({"path": relative, "error": str(exc)})
    files.sort(key=lambda entry: entry["path"])
    return files, errors


def _compare(families: list[dict[str, Any]]) -> list[dict[str, Any]]:
    for family in families:
        members = family["members"]
        member_locations = {member["id"]: Path(member["location"]) for member in members}
        by_path: dict[str, list[tuple[str, dict[str, Any]]]] = {}
        by_digest: dict[str, list[dict[str, str]]] = {}
        for member in members:
            for artifact in member["artifacts"]:
                by_path.setdefault(artifact["path"], []).append((member["id"], artifact))
                if artifact.get("sha256"):
                    by_digest.setdefault(artifact["sha256"], []).append(
                        {"source_id": member["id"], "path": artifact["path"]}
                    )
        identical = [
            {"sha256": digest, "instances": instances}
            for digest, instances in sorted(by_digest.items()) if len(instances) > 1
        ]
        divergent = []
        near_duplicates = []
        unique = []
        for path, instances in sorted(by_path.items()):
            source_ids = {source_id for source_id, _ in instances}
            hashes = {artifact.get("sha256") for _, artifact in instances}
            if len(source_ids) > 1 and len(hashes) > 1:
                divergent.append({"path": path, "versions": [
                    {"source_id": source_id, "sha256": artifact.get("sha256")}
                    for source_id, artifact in instances
                ]})
                for (left_id, left), (right_id, right) in combinations(instances, 2):
                    if left_id == right_id or left.get("sha256") == right.get("sha256"):
                        continue
                    if max(left.get("size_bytes", 0), right.get("size_bytes", 0)) > NEAR_DUPLICATE_MAX_BYTES:
                        continue
                    try:
                        left_text = (member_locations[left_id] / path).read_text("utf-8")
                        right_text = (member_locations[right_id] / path).read_text("utf-8")
                    except (OSError, UnicodeError):
                        continue
                    if "\0" in left_text or "\0" in right_text:
                        continue
                    ratio = SequenceMatcher(None, left_text, right_text).ratio()
                    if ratio >= NEAR_DUPLICATE_MIN_RATIO:
                        near_duplicates.append({
                            "path": path,
                            "source_ids": [left_id, right_id],
                            "similarity": round(ratio, 4),
                            "status": "heuristic candidate; review required",
                        })
            elif len(source_ids) == 1 and len(members) > 1:
                unique.append({"path": path, "source_ids": sorted(source_ids)})

        suggestions = []
        for member in members:
            git = member.get("git") or {}
            suggestions.append({
                "source_id": member["id"],
                "signals": {
                    "inventory_file_count": len(member["artifacts"]),
                    "git_working_tree_clean": git.get("working_tree_clean"),
                    "git_head_date": (git.get("head") or {}).get("date"),
                },
                "status": "candidate-only; requires human review",
            })
        suggestions.sort(key=lambda item: (
            item["signals"]["git_working_tree_clean"] is True,
            item["signals"]["git_head_date"] or "",
            item["signals"]["inventory_file_count"],
        ), reverse=True)
        family["analysis"] = {
            "identical_content": identical,
            "divergent_same_path": divergent,
            "near_duplicate_same_path": near_duplicates,
            "version_specific_or_orphan_candidates": unique,
            "canonical_or_lkg_candidates": suggestions,
            "ambiguity_policy": "preserve all alternatives; no automatic winner or deletion",
        }
    return families


def _global_duplicates(sources: list[dict[str, Any]]) -> list[dict[str, Any]]:
    by_digest: dict[str, list[dict[str, str]]] = {}
    for source in sources:
        for artifact in source["artifacts"]:
            if artifact.get("sha256"):
                by_digest.setdefault(artifact["sha256"], []).append({
                    "source_id": source["id"], "path": artifact["path"],
                })
    return [
        {"sha256": digest, "instances": instances}
        for digest, instances in sorted(by_digest.items()) if len(instances) > 1
    ]


def _ensure_separate(evidence_dir: Path, roots: list[Path]) -> None:
    for root in roots:
        if evidence_dir == root or root in evidence_dir.parents:
            raise ReconcileError(
                f"Evidence directory must be outside every selected source location: {root}"
            )


def reconcile(locations: list[str | Path], evidence_dir: str | Path, language: str = "en") -> dict[str, Any]:
    """Inventory selected source roots and persist a reviewable, non-destructive run."""
    if language not in LABELS:
        raise ReconcileError("Language must be 'en' or 'sk'.")
    if not locations:
        raise ReconcileError("Select at least one project/source location.")
    roots: list[Path] = []
    for value in locations:
        candidate = Path(value).expanduser()
        try:
            root = candidate.resolve(strict=True)
        except (OSError, RuntimeError) as exc:
            raise ReconcileError(f"Cannot resolve selected location {value!s}: {exc}") from exc
        if not root.is_dir():
            raise ReconcileError(f"Selected location is not a directory: {root}")
        if root not in roots:
            roots.append(root)
    roots.sort(key=lambda path: str(path).casefold())
    out = Path(evidence_dir).expanduser().resolve()
    _ensure_separate(out, roots)

    run_id = uuid.uuid4().hex
    created_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
    sources: list[dict[str, Any]] = []
    family_map: dict[str, list[dict[str, Any]]] = {}
    for index, root in enumerate(roots, 1):
        name = _project_name(root)
        artifacts, errors = _inventory(root)
        source = {
            "id": f"source-{index:03d}",
            "location": str(root),
            "project_identity": name,
            "family_key": _family_key(name),
            "artifacts": artifacts,
            "inventory_errors": errors,
            "git": _git_evidence(root),
        }
        sources.append(source)
        family_map.setdefault(source["family_key"], []).append(source)
    families = [
        {"family_key": key, "members": members}
        for key, members in sorted(family_map.items())
    ]
    _compare(families)

    stage_plan = {
        "policy": "review-only plan; no source files are copied, moved, overwritten, or deleted",
        "proposals": [
            {
                "family_key": family["family_key"],
                "candidate_sources": [item["source_id"] for item in family["analysis"]["canonical_or_lkg_candidates"]],
                "required_before_consolidation": [
                    "human selection of the intended canonical source",
                    "independent destination and backup selection",
                    "explicit authorization for each consequential change",
                    "post-change verification against this evidence",
                ],
            }
            for family in families
        ],
    }
    report: dict[str, Any] = {
        "schema_version": 1,
        "application": "PENELOPE — Project & Source Reconciliation",
        "application_version": VERSION,
        "run_id": run_id,
        "created_at": created_at,
        "language": language,
        "selected_locations": [str(root) for root in roots],
        "safety": {
            "source_locations_modified": False,
            "files_moved": False,
            "files_deleted": False,
            "symlinks_followed": False,
        },
        "sources": sources,
        "families": families,
        "global_identical_content": _global_duplicates(sources),
        "staging_plan": stage_plan,
        "limitations": [
            "Directory-name or manifest-name matching is a discovery signal, not proof of common ownership.",
            "A clean/newer/larger Git repository is only a candidate signal and is never automatically authoritative.",
            "Content identity is exact SHA-256 equality; semantic equivalence is not inferred.",
            "Near-duplicate candidates use UTF-8 same-path text similarity at or above 0.90 and are heuristic only; files above 32 KiB are not scored.",
        ],
    }

    out.mkdir(parents=True, exist_ok=True)
    report_path = out / f"reconciliation-{run_id}.json"
    payload = (json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode("utf-8")
    report_path.write_bytes(payload)
    journal_entry = {
        "run_id": run_id,
        "created_at": created_at,
        "report": report_path.name,
        "report_sha256": hashlib.sha256(payload).hexdigest(),
        "selected_locations": [str(root) for root in roots],
        "family_count": len(families),
        "source_count": len(sources),
        "safety": report["safety"],
    }
    with (out / "journal.jsonl").open("a", encoding="utf-8") as journal:
        journal.write(json.dumps(journal_entry, ensure_ascii=False, sort_keys=True) + "\n")
    report["evidence_file"] = str(report_path)
    report["journal_file"] = str(out / "journal.jsonl")
    return report
