"""Command-line and local web entry points."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from . import __version__
from .core import LABELS, ReconcileError, reconcile
from .web import serve


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="penelope",
        description="Inventory and compare explicitly selected project/source locations without changing them.",
    )
    parser.add_argument("--version", action="version", version=f"PENELOPE {__version__}")
    commands = parser.add_subparsers(dest="command", required=True)

    scan = commands.add_parser("reconcile", help="inventory and compare selected locations")
    scan.add_argument("locations", nargs="+", help="explicit project/source directories")
    scan.add_argument("--evidence-dir", required=True, help="separate directory for report and journal")
    scan.add_argument("--language", choices=("en", "sk"), default="en")

    web = commands.add_parser("serve", help="start the loopback-only lightweight Web UI/API")
    web.add_argument("--evidence-dir", required=True, help="separate directory for report and journal")
    web.add_argument("--language", choices=("en", "sk"), default="en")
    web.add_argument("--port", type=int, default=8765)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if args.command == "serve":
        try:
            serve(Path(args.evidence_dir), args.language, args.port)
        except (OSError, ValueError) as exc:
            print(f"Could not start PENELOPE: {exc}", file=sys.stderr)
            return 2
        return 0
    try:
        report = reconcile(args.locations, args.evidence_dir, args.language)
    except (ReconcileError, OSError) as exc:
        print(f"PENELOPE: {exc}", file=sys.stderr)
        return 2
    labels = LABELS[args.language]
    print(f"{labels['done']}: {report['evidence_file']}")
    print(f"Sources: {len(report['sources'])}; families: {len(report['families'])}")
    print("Original source locations were not modified.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
