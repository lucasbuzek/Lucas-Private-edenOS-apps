"""PENELOPE — Project & Source Reconciliation."""

__version__ = "0.1.0"
