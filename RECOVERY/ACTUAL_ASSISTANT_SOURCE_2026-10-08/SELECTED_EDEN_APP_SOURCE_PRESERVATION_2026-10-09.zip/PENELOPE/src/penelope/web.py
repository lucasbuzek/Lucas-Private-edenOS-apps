"""Small standard-library Web UI and JSON API bound to loopback only."""

from __future__ import annotations

import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from .core import LABELS, ReconcileError, reconcile


def _page(language: str) -> bytes:
    labels = json.dumps(LABELS, ensure_ascii=False).replace("</", "<\\/")
    document = """<!doctype html>
<html lang="__LANG__"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>PENELOPE</title>
<style>
:root{font:16px system-ui;color:#19231f;background:#f5f6f2}body{max-width:900px;margin:4rem auto;padding:0 1.2rem}
main{background:white;border:1px solid #d9dfd9;border-radius:14px;padding:2rem}h1{font-size:1.6rem}p{line-height:1.5}
textarea{box-sizing:border-box;width:100%;min-height:10rem;font:14px ui-monospace,monospace;padding:.8rem}
button,select{font:inherit;padding:.6rem .9rem;margin-top:.8rem}button{background:#145b46;color:white;border:0;border-radius:7px}
.safe{color:#225a45;background:#eef7f0;padding:.8rem;border-radius:7px}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f2f4f1;padding:1rem;border-radius:7px}
</style><main><h1 id="title"></h1><p id="intro"></p><form id="form"><label for="roots" id="roots-label"></label>
<textarea id="roots" required spellcheck="false" placeholder="/path/to/project-v1&#10;/path/to/project-v2"></textarea><br>
<label for="language" id="language-label"></label> <select id="language"><option value="en">English</option><option value="sk">Slovenčina</option></select>
<button id="run" type="submit"></button></form><p class="safe" id="safety"></p><h2 id="result-title" hidden></h2><pre id="result" hidden></pre></main>
<script>
const L=__LABELS__;const lang=document.getElementById('language');lang.value='__LANG__';
function translate(){document.documentElement.lang=lang.value;const x=L[lang.value];document.title=x.title;document.getElementById('title').textContent=x.title;document.getElementById('intro').textContent=x.intro;document.getElementById('roots-label').textContent=x.roots;document.getElementById('run').textContent=x.run;document.getElementById('language-label').textContent=x.language;document.getElementById('safety').textContent=x.safety;}
lang.addEventListener('change',translate);translate();
document.getElementById('form').addEventListener('submit',async e=>{e.preventDefault();const x=L[lang.value];const roots=document.getElementById('roots').value.split(/\\r?\\n/).map(s=>s.trim()).filter(Boolean);const out=document.getElementById('result');const title=document.getElementById('result-title');out.hidden=false;title.hidden=false;title.textContent=x.working;out.textContent='';try{const response=await fetch('/api/reconcile',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({locations:roots,language:lang.value})});const data=await response.json();if(!response.ok)throw new Error(data.error||response.statusText);title.textContent=x.done;out.textContent=JSON.stringify(data,null,2);}catch(err){title.textContent=x.error;out.textContent=String(err);}});
</script></html>"""
    return document.replace("__LANG__", language).replace("__LABELS__", labels).encode("utf-8")


def _handler(evidence_dir: Path, initial_language: str) -> type[BaseHTTPRequestHandler]:
    class Handler(BaseHTTPRequestHandler):
        server_version = "PENELOPE/0.1.0"

        def _send(self, status: int, body: bytes, content_type: str) -> None:
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'")
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self) -> None:  # noqa: N802 - stdlib handler API
            path = urlparse(self.path).path
            if path == "/":
                self._send(200, _page(initial_language), "text/html; charset=utf-8")
            elif path == "/api/health":
                self._send(200, b'{"status":"ready","version":"0.1.0"}', "application/json; charset=utf-8")
            else:
                self._send(404, b'{"error":"not found"}', "application/json; charset=utf-8")

        def do_POST(self) -> None:  # noqa: N802 - stdlib handler API
            if urlparse(self.path).path != "/api/reconcile":
                self._send(404, b'{"error":"not found"}', "application/json; charset=utf-8")
                return
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if length <= 0 or length > 65536:
                    raise ReconcileError("Request body must be between 1 and 65536 bytes.")
                request: Any = json.loads(self.rfile.read(length))
                if not isinstance(request, dict) or not isinstance(request.get("locations"), list):
                    raise ReconcileError("Request must contain a locations array.")
                locations = request["locations"]
                if not all(isinstance(item, str) for item in locations):
                    raise ReconcileError("Every selected location must be a string path.")
                language = request.get("language", initial_language)
                report = reconcile(locations, evidence_dir, language)
                self._send(200, json.dumps(report, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")
            except (ReconcileError, OSError, json.JSONDecodeError, UnicodeDecodeError, TypeError, ValueError) as exc:
                message = json.dumps({"error": str(exc)}, ensure_ascii=False).encode("utf-8")
                self._send(400, message, "application/json; charset=utf-8")

        def log_message(self, fmt: str, *args: Any) -> None:
            # Avoid emitting source paths to a shared terminal by default.
            return

    return Handler


def serve(evidence_dir: Path, language: str = "en", port: int = 8765) -> None:
    if language not in LABELS:
        raise ValueError("Language must be 'en' or 'sk'.")
    if not 1 <= port <= 65535:
        raise ValueError("Port must be between 1 and 65535.")
    evidence_dir = evidence_dir.expanduser().resolve()
    evidence_dir.mkdir(parents=True, exist_ok=True)
    server = ThreadingHTTPServer(("127.0.0.1", port), _handler(evidence_dir, language))
    print(f"PENELOPE local UI/API: http://127.0.0.1:{port}/")
    print(f"Evidence directory: {evidence_dir}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
