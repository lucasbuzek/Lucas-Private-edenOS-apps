# PENELOPE — Project & Source Reconciliation

Status: Private / Experimental. This file records recovered project authority and is not evidence that historical source has been recovered.

## Identity and role

**PENELOPE — Project & Source Reconciliation**

**UNDERSTAND · RECONCILE · PROTECT**

PENELOPE is EDEN's project/source bridge and source-family custodian. It turns fragmented project/source material into coherent, trustworthy, maintainable project families without destroying history.

## Ownership

PENELOPE owns project/source identity and authoritative source locations; source/version/revision discovery; branches and fragmented source families; project/artifact inventory and classification; duplicate and near-duplicate recognition; family/version comparison; lineage, provenance, conflicts, divergence and supersession; orphan and canonical-source candidates; project-family dependency/software reconciliation; Last Known Good and recovery relationships; non-destructive reconciliation; and consolidation staging/evidence.

PENELOPE does not own general implementation/build/test/package execution when FORGE is appropriate, generic shared runtime hosting owned by BIFROST, general orchestration owned by CONDUCTOR, or arbitrary file cleanup based only on apparent duplication.

## Safety and pipeline

**VERIFY BEFORE DESTRUCTIVE ACTION.** Preserve ambiguous material. Prefer COPY + VERIFY over MOVE + DELETE. Permanent deletion always requires separate explicit authorization. Duplicate, supersession, canonical-survivor, orphan and consolidation findings are proposals; preserve provenance and competing or ambiguous source families.

Reconciliation: DISCOVER → IDENTIFY → INVENTORY / CLASSIFY → RELATE / FAMILY → COMPARE → DEDUPLICATE ANALYSIS → LINEAGE → CONFLICT / ORPHAN ANALYSIS → RECONCILE → STAGE → VERIFY → AUTHORIZED CONSOLIDATION / CHANGE → VERIFY AGAIN → REGISTER → ARCHIVE / PRESERVE PROVENANCE.

Implementation recovery: RECOVER → DISCOVER → RECOGNIZE → REUSE → RECONCILE → IMPLEMENT ONLY THE GAP → VERIFY.

UNKNOWN != PASS. GENERATED != IMPLEMENTED != BUILT != TESTED != VERIFIED != RELEASED.

## Product target

Private / Experimental; macOS-primary; portable and local-first where practical; English and Slovak support required. Provide useful operation through the appropriate combination of CLI, lightweight Web UI and API/headless operation. Prefer OS-native and existing capabilities before custom infrastructure.

## Historical implementation evidence

Prior project work records a private experimental PENELOPE v0.2.0 with inventory, SHA-256 identification, Git reuse, source-family recognition, comparison, non-destructive reconciliation, provenance, LKG/rollback relationships, and CLI/Web/API/headless operation. This is historical capability evidence only. The source/package has not been recovered; do not represent the new implementation as that historical version.

## First baseline acceptance

Process explicitly selected project/source locations non-destructively; inventory and deterministically identify artifacts (including SHA-256 where appropriate); recognize related families; compare versions; expose lineage/provenance; identify exact duplicates, conflicts, divergent versions and orphan candidates; propose possible canonical/LKG candidates without deleting alternatives; produce a reviewable reconciliation/staging result; journal discoveries and conclusions; and leave the originals unchanged.

A controlled fixture with multiple related source versions must demonstrate discovery, inventory, family recognition, identical versus divergent material, comparison/lineage/provenance evidence, reconciliation candidates, preservation of ambiguity, reviewable results, and unchanged originals. Then run static, environment, regression, package and package-verification gates. A plan is not an executed consolidation; destructive changes require their own authorization.
