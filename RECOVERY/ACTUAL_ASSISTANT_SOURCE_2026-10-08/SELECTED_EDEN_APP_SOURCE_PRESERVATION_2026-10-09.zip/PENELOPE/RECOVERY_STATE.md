# PENELOPE recovery state — 2026-10-02

## Authority and provenance

- Project identity, ownership, safety, target and first-baseline acceptance: `PROJECT_BIBLE.md`, recovered from the user-provided authority on 2026-10-02.
- Global engineering authority: `~/edenOS/Projects/#appDev Bible/APPDEV_BIBLE.txt` and associated global canon.
- Historical evidence: prior project work records v0.2.0 capabilities. No historical source/package was found in the authorized AppDev/PENELOPE locations or available PENELOPE thread history.

## Implementation state

- Recovery classification: historical implementation evidence exists; historical source is unavailable; the current implementation is new source based on recovered requirements.
- Worktree: this PENELOPE project directory; new Git repository on `main`.
- Candidate: PENELOPE 0.1.0 source and `artifacts/penelope-0.1.0.pyz`.
- Evidence stage: STATIC VERIFY, FIXTURE / REGRESSION VERIFY, PACKAGE, PACKAGE VERIFY passed for the first functional baseline.
- Functional baseline: explicit local directory selection; inventory; SHA-256; symlink recording without following; Git branch/head/recent-parent evidence; family grouping; exact duplicate detection; bounded same-path UTF-8 near-duplicate candidates; divergent-path and version-specific/orphan candidates; review-only canonical/LKG signals; JSON report; append-only journal; CLI; loopback-only Web UI and JSON API; EN/SK labels.
- Safety evidence: controlled fixture source trees, including Git metadata, matched before/after snapshots; no selected source material changed, moved, or deleted.
- LKG: 0.1.0 is the first fixture-verified local baseline. It does not establish historical v0.2.0 recovery or released status.

## Known limits

- Family recognition uses normalized project/manifest names and requires human confirmation; same-name unrelated projects can be grouped.
- Near-duplicate checks only compare same-path UTF-8 files up to 32 KiB using a 0.90 similarity threshold; this is heuristic evidence.
- Semantic equivalence, broad branch graph comparison, dependency resolution, content-aware merging, and actual copy/consolidation staging are not implemented. Staging output is a review-only plan.
- Package is a portable Python zipapp, not a signed/notarized macOS `.app` bundle. Platform installation/signing and physical gates are unverified and are not part of the first fixture acceptance.
- A conventional wheel/installer was not built; the verified package entry point is the standard-library zipapp.
- Evidence reports include selected paths and Git subjects; protect them as local project data.

## Next gate

Extend real source-family reconciliation only against additional recovered requirements; keep candidate/LKG distinctions and require explicit authorization for any future file-changing operation.
