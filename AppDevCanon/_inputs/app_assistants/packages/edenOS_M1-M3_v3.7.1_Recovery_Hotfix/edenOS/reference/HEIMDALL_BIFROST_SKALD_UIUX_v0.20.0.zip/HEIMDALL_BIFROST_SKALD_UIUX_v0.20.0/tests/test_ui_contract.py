from pathlib import Path
import json
R=Path(__file__).resolve().parents[1]
c=json.loads((R/'contracts/ui_experience_v1.json').read_text())
h=(R/'preview/index.html').read_text()
assert c['default_shell']=='desktop'
assert c['files_modes']==['files','explore']
assert c['external_downloads'] is False
for x in ['Desktop','Workspace','Files','Explore','Search','SKALD Custom','Settings','BIFROST']:
    assert x in h
print('PASS UI/UX V1 preview contract')
