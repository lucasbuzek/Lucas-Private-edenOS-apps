import os, tempfile, unittest, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from core.bifrost_core import BifrostCore
class T(unittest.TestCase):
 def test_identity_relationship_search(self):
  with tempfile.TemporaryDirectory() as d:
   b=BifrostCore(os.path.join(d,'bifrost.db'))
   p=b.register('Project','gardenOS Core',{'area':'engineering'})
   f=b.register('Document','Wiring Diagram',{'format':'pdf'})
   b.add_location(f,'filesystem','file:///Projects/gardenOS/wiring.pdf','online')
   b.relate(p,'contains',f,{'source':'user'})
   self.assertEqual(b.explore(p)['relationships'][0]['target_id'],f)
   self.assertEqual(b.search('Wiring')[0]['id'],f)
   b.set_feature('skald',False)
if __name__=='__main__': unittest.main()
