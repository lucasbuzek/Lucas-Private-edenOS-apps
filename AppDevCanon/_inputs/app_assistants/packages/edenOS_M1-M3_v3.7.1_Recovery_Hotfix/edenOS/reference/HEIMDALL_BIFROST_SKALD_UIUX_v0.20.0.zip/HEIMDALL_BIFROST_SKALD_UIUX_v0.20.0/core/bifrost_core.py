from __future__ import annotations
import sqlite3, json, uuid
from pathlib import Path

SCHEMA = '''
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS objects(
 id TEXT PRIMARY KEY, type TEXT NOT NULL, title TEXT NOT NULL,
 metadata TEXT NOT NULL DEFAULT '{}', created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS locations(
 id TEXT PRIMARY KEY, object_id TEXT NOT NULL REFERENCES objects(id) ON DELETE CASCADE,
 provider TEXT NOT NULL, uri TEXT NOT NULL, availability TEXT DEFAULT 'unknown', UNIQUE(provider,uri));
CREATE TABLE IF NOT EXISTS representations(
 id TEXT PRIMARY KEY, object_id TEXT NOT NULL REFERENCES objects(id) ON DELETE CASCADE,
 kind TEXT NOT NULL, format TEXT, location_id TEXT REFERENCES locations(id),
 source_representation_id TEXT REFERENCES representations(id), generator TEXT, parameters TEXT DEFAULT '{}',
 validation TEXT DEFAULT '{}', provenance TEXT DEFAULT '{}');
CREATE TABLE IF NOT EXISTS relationships(
 id TEXT PRIMARY KEY, source_id TEXT NOT NULL REFERENCES objects(id) ON DELETE CASCADE,
 predicate TEXT NOT NULL, target_id TEXT NOT NULL REFERENCES objects(id) ON DELETE CASCADE,
 provenance TEXT DEFAULT '{}', UNIQUE(source_id,predicate,target_id));
CREATE TABLE IF NOT EXISTS collections(
 id TEXT PRIMARY KEY, title TEXT NOT NULL, smart_query TEXT, metadata TEXT DEFAULT '{}');
CREATE TABLE IF NOT EXISTS collection_members(
 collection_id TEXT REFERENCES collections(id) ON DELETE CASCADE,
 object_id TEXT REFERENCES objects(id) ON DELETE CASCADE, PRIMARY KEY(collection_id,object_id));
CREATE TABLE IF NOT EXISTS features(name TEXT PRIMARY KEY, enabled INTEGER NOT NULL DEFAULT 0, config TEXT DEFAULT '{}');
CREATE VIRTUAL TABLE IF NOT EXISTS search_index USING fts5(object_id UNINDEXED, title, body);
'''

def uid(prefix='obj'): return f"{prefix}_{uuid.uuid4().hex}"

class BifrostCore:
    def __init__(self, db='heimdall.db'):
        self.db=sqlite3.connect(db)
        self.db.row_factory=sqlite3.Row
        self.db.executescript(SCHEMA)
    def register(self, type_, title, metadata=None, object_id=None):
        oid=object_id or uid(type_.lower())
        md=metadata or {}
        self.db.execute('INSERT INTO objects(id,type,title,metadata) VALUES(?,?,?,?)',(oid,type_,title,json.dumps(md)))
        self.db.execute('INSERT INTO search_index(object_id,title,body) VALUES(?,?,?)',(oid,title,json.dumps(md)))
        self.db.commit(); return oid
    def add_location(self, object_id, provider, uri, availability='unknown'):
        lid=uid('loc'); self.db.execute('INSERT INTO locations VALUES(?,?,?,?,?)',(lid,object_id,provider,uri,availability)); self.db.commit(); return lid
    def relate(self, source, predicate, target, provenance=None):
        rid=uid('rel'); self.db.execute('INSERT OR IGNORE INTO relationships VALUES(?,?,?,?,?)',(rid,source,predicate,target,json.dumps(provenance or {}))); self.db.commit(); return rid
    def search(self, query, limit=50):
        return [dict(r) for r in self.db.execute('SELECT o.* FROM search_index s JOIN objects o ON o.id=s.object_id WHERE search_index MATCH ? LIMIT ?',(query,limit))]
    def set_feature(self,name,enabled,config=None):
        self.db.execute('INSERT INTO features(name,enabled,config) VALUES(?,?,?) ON CONFLICT(name) DO UPDATE SET enabled=excluded.enabled,config=excluded.config',(name,int(enabled),json.dumps(config or {}))); self.db.commit()
    def explore(self, object_id):
        obj=self.db.execute('SELECT * FROM objects WHERE id=?',(object_id,)).fetchone()
        if not obj: return None
        rel=[dict(r) for r in self.db.execute('SELECT predicate,target_id FROM relationships WHERE source_id=? UNION ALL SELECT predicate,source_id FROM relationships WHERE target_id=?',(object_id,object_id))]
        loc=[dict(r) for r in self.db.execute('SELECT provider,uri,availability FROM locations WHERE object_id=?',(object_id,))]
        return {'object':dict(obj),'relationships':rel,'locations':loc}
