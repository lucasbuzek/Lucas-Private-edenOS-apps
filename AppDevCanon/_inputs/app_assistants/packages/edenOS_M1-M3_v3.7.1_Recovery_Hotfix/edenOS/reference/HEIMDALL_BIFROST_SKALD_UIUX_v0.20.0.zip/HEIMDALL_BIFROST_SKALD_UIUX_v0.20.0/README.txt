HEIMDALL / BIFROST / SKALD UI/UX v0.20.0 — PRE-BUILD PREVIEW

Open preview/index.html.
No installation and no external downloads are required.
No Jellyfin, calibre, Transmission, FFmpeg or other provider is contacted.

This package implements the complete pre-build UI/UX interaction baseline, not a production native application. See docs/UI_UX_V1_BASELINE.txt.
