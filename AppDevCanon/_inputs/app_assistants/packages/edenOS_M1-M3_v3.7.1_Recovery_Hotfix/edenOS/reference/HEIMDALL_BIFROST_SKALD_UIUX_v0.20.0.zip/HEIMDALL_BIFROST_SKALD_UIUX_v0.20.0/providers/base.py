from abc import ABC, abstractmethod
class Provider(ABC):
    provider_id='provider.base'
    @abstractmethod
    def capabilities(self): ...
    def search(self, query): return []
    def ingest(self, source): raise NotImplementedError
    def preview(self, ref): return None
